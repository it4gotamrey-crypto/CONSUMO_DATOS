import { issuesFor, normalize, round } from './domain.js';

export const employeeKey = record => normalize(record.employee);

function scopedRecords(records, options) {
  const query = normalize(options.query);
  return records.filter(r => /^\d{4}-(0[1-9]|1[0-2])$/.test(r.period) && (!options.department || r.department === options.department) && (!query || normalize([r.user, r.employee, r.device, r.deviceDescription, r.brand, r.model, r.serial, r.imei1, r.imei2, r.department, ...r.apps.map(a => a.name)].join(' ')).includes(query)));
}

export function calendarMonths(from, to) {
  const valid = /^\d{4}-(0[1-9]|1[0-2])$/;
  if (!valid.test(from || '') || !valid.test(to || '')) return [];
  const index = value => Number(value.slice(0, 4)) * 12 + Number(value.slice(5)) - 1;
  const start = index(from), end = index(to);
  if (end < start) throw new Error('El mes inicial debe ser anterior o igual al mes final.');
  if (end - start >= 120) throw new Error('Selecciona un intervalo de hasta 120 meses.');
  return Array.from({ length: end - start + 1 }, (_, i) => `${Math.floor((start + i) / 12)}-${String((start + i) % 12 + 1).padStart(2, '0')}`);
}

export function buildHistory(records, options = {}) {
  const scope = scopedRecords(records, options);
  const observed = [...new Set(scope.map(r => r.period))].sort();
  const from = options.from || observed[0] || '', to = options.to || observed.at(-1) || '';
  const months = calendarMonths(from, to), metric = options.metric || 'total';
  const entries = scope.filter(r => (!from || r.period >= from) && (!to || r.period <= to)).map(record => ({ record, valid: issuesFor(record, records).length === 0 }));
  const catalogMap = new Map();
  for (const { record, valid } of entries) {
    const id = employeeKey(record);
    if (!id) continue;
    let user = catalogMap.get(id);
    if (!user) { user = { id, name: record.user, employee: record.employee, latest: record.period, total: 0 }; catalogMap.set(id, user); }
    if (record.period >= user.latest) { user.name = record.user; user.employee = record.employee; user.latest = record.period; }
    if (valid) user.total = round(user.total + record.totalGb);
  }
  const catalog = [...catalogMap.values()].sort((a, b) => b.total - a.total || a.name.localeCompare(b.name, 'es'));
  const ids = Array.isArray(options.users) ? [...new Set(options.users)].slice(0, 6) : catalog.filter(u => u.total > 0).slice(0, 3).map(u => u.id);
  const series = ids.flatMap(id => {
    const user = catalogMap.get(id);
    if (!user) return [];
    const points = months.map(period => {
      const monthly = entries.filter(e => employeeKey(e.record) === id && e.record.period === period);
      const good = monthly.filter(e => e.valid);
      const readings = metric === 'total' ? good.map(e => e.record.totalGb) : good.flatMap(e => e.record.apps.filter(a => a.name === metric).map(a => a.gb));
      return { period, value: readings.length ? round(readings.reduce((sum, n) => sum + n, 0)) : null, readings: readings.length, pending: monthly.length - good.length, unlisted: metric === 'total' ? 0 : good.filter(e => !e.record.apps.some(a => a.name === metric)).length };
    });
    const known = points.filter(p => p.value !== null), first = known[0], last = known.at(-1);
    return [{ ...user, points, total: round(known.reduce((sum, p) => sum + p.value, 0)), change: known.length > 1 ? round(last.value - first.value) : null, first, last }];
  });
  return { from, to, months, observed, metric, catalog, series, validCount: entries.filter(e => e.valid).length, pendingCount: entries.filter(e => !e.valid).length };
}

export function buildAggregateHistory(records, options = {}) {
  const scope = scopedRecords(records, options);
  const observed = [...new Set(scope.map(r => r.period))].sort();
  const from = options.from || observed[0] || '', to = options.to || observed.at(-1) || '';
  const months = calendarMonths(from, to);
  const entries = scope.filter(r => (!from || r.period >= from) && (!to || r.period <= to)).map(record => ({ record, valid: issuesFor(record, records).length === 0 }));
  const catalogMap = new Map();
  for (const { record, valid } of entries) if (valid) for (const app of record.apps) catalogMap.set(app.name, round((catalogMap.get(app.name) || 0) + app.gb));
  const catalog = [...catalogMap].map(([name, total]) => ({ name, total })).sort((a, b) => b.total - a.total || a.name.localeCompare(b.name, 'es'));
  const mode = options.mode === 'apps' ? 'apps' : 'total';
  const names = mode === 'total' ? ['Consumo total'] : Array.isArray(options.apps) ? [...new Set(options.apps)].filter(n => typeof n === 'string').slice(0, 6) : catalog.slice(0, 3).map(a => a.name);
  const series = names.map(name => {
    const points = months.map(period => {
      const monthly = entries.filter(e => e.record.period === period), good = monthly.filter(e => e.valid);
      const readings = mode === 'total' ? good.map(e => e.record.totalGb) : good.flatMap(e => e.record.apps.filter(a => a.name === name).map(a => a.gb));
      return { period, value: readings.length ? round(readings.reduce((sum, n) => sum + n, 0)) : null, readings: readings.length, pending: monthly.length - good.length, unlisted: mode === 'total' ? 0 : good.filter(e => !e.record.apps.some(a => a.name === name)).length };
    });
    const known = points.filter(p => p.value !== null), first = known[0], last = known.at(-1);
    return { id: mode === 'total' ? 'period-total' : name, name, points, first, last, total: round(known.reduce((sum, p) => sum + p.value, 0)), change: known.length > 1 ? round(last.value - first.value) : null };
  });
  return { mode, from, to, months, observed, catalog, series, validCount: entries.filter(e => e.valid).length, pendingCount: entries.filter(e => !e.valid).length };
}
