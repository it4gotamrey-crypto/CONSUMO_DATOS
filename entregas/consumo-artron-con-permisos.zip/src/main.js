import './style.css';
import './report.css';
import { serverMode, auth, roleNames, canAdmin, canCapture, api } from './access.js';
import readXlsxFile from 'read-excel-file/browser';
import { STATES, DEVICE_TYPES, APPS, DEPARTMENTS, HIGH_GB, round, normalize, parseUsage, canonicalApp, canonicalDeviceType, deviceLabel, issuesFor, sameDevice, summarize, rowsToRecords, validateBackup, csvReport } from './domain.js';
import { STORAGE_KEY, loadStore, saveStore } from './storage.js';
import { excelReport } from './excel-report.js';
import { openPrintDesigner } from './print-report.js';
import { icon } from './icons.js';
import { buildHistory, buildAggregateHistory } from './history.js';
import { SERIES_COLORS, drawHistory } from './history-chart.js';
import { LAYOUT_KEY, HISTORY_KEY, ANALYTICS_KEY, CHART_IDS, DEFAULT_VISIBLE, loadLayout, normalizeLayout, loadHistoryPreferences, loadAnalyticsPreferences, isHistoricalChart, bindReportEditor, minimumHeight } from './report-layout.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const number = value => new Intl.NumberFormat('es-MX', { maximumFractionDigits: 6 }).format(value);
const monthName = value => value ? new Date(value + '-02T12:00:00').toLocaleDateString('es-MX', { month: 'long', year: 'numeric' }) : 'Todos los períodos';
const thisMonth = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const initials = name => name.trim().split(/\s+/).slice(0, 2).map(n => n[0]).join('').toUpperCase();
let records = [], savedAt = null, period = '', department = '', search = '', tab = 'dashboard', fatal = null;
let reportLayout = loadLayout(), editingReport = false, historyPreferences = loadHistoryPreferences(), historyData = null, cleanupHistoryPlots = [];
let analyticsPreferences = loadAnalyticsPreferences(), aggregateData = {};
let importSheets = [], importCandidates = [], revision = 0, saving = false;
const colors = ['#2563eb', '#4d8ff3', '#12a5cd', '#7380e8', '#85b9ff', '#8c9ebf', '#b6cff1'];
const stateColors = { Nuevo: '#60a5fa', Bueno: '#2563eb', Desgaste: '#e9a23b', Dañado: '#e56a73', Reparado: '#8074d8', Descompuesto: '#ba4156', Disponible: '#38bdf8', 'Sin estado': '#9aabc4' };
const chartDescriptions = {
  'period-total': ['Consumo total por período', 'Suma validada de los equipos por mes.'],
  'app-history': ['Histórico por aplicación', 'Compara hasta 6 apps sumando los equipos.'],
  history: ['Histórico por usuario', 'Compara usuarios por consumo total o una app.'],
  applications: ['Consumo por aplicación', 'Aplicaciones con mayor consumo en la selección.'],
  users: ['Usuarios con mayor consumo', 'Clasificación del consumo por usuario.'],
  departments: ['Consumo por departamento', 'Distribución del consumo entre departamentos.'],
  states: ['Condiciones de los equipos', 'Estado de las capturas de equipos.'],
};

function toast(message, error = false) {
  const el = $('#toast'); el.textContent = message; el.className = error ? 'show error' : 'show';
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.className = '', 5500);
}
async function commit(next, message, options = {}) {
  if (serverMode) {
    if (!canCapture() || saving) { toast('No tienes permiso o hay un guardado en curso.', true); return false; }
    saving = true;
    try {
      const state = await api('records', { method: 'PUT', data: { schemaVersion: 1, revision, records: next, allowPending: options.allowPending === true } });
      records = state.records; revision = state.revision; savedAt = state.savedAt; render();
      if (message) toast(message.replace('en este navegador', 'en el servidor').replace('del almacenamiento local', 'del servidor'));
      return true;
    } catch (e) {
      if (e.status === 409) { try { await refreshOfficial(); } catch {} }
      if (e.status === 401) showLogin('Tu sesión terminó. Inicia sesión de nuevo.');
      else toast(e.message, true);
      return false;
    } finally { saving = false; }
  }
  if (fatal) { toast('Resuelve el problema de almacenamiento antes de guardar.', true); return false; }
  try {
    const latest = loadStore();
    if ((latest?.savedAt || null) !== savedAt) {
      records = latest?.records || []; savedAt = latest?.savedAt || null; render();
      toast('Los datos cambiaron en otra pestaña. Cierra esta ventana y revisa la captura actual antes de guardar.', true);
      return false;
    }
    savedAt = saveStore(next); records = next; render(); if (message) toast(message); return true;
  }
  catch { toast('No se pudo guardar. Revisa el permiso o espacio del navegador y exporta un respaldo.', true); return false; }
}
function filtered() {
  const query = normalize(search);
  return records.filter(r => (!period || r.period === period) && (!department || r.department === department) && (!query || normalize([r.user, r.employee, r.device, r.deviceDescription, r.brand, r.model, r.serial, r.imei1, r.imei2, r.department, ...r.apps.map(a => a.name)].join(' ')).includes(query)));
}
function download(content, filename, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a'); a.href = url; a.download = filename;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
let exportingExcel = false;
async function exportExcel() {
  if (serverMode && !canAdmin()) return;
  if (exportingExcel) return;
  exportingExcel = true;
  const buttons = $$('[data-action="excel"], #download-excel');
  buttons.forEach(button => button.disabled = true);
  try {
    const blob = await excelReport(filtered(), records, { period, department, search });
    download(blob, `consumo-${period || 'todos'}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    toast('Se solicitó la descarga del Excel. Busca el archivo .xlsx en Descargas.');
  } catch (e) { toast(`No se pudo generar el Excel: ${e.message}`, true); }
  finally { exportingExcel = false; buttons.forEach(button => button.disabled = false); }
}
function option(value, selected = '', label = value) { return `<option value="${esc(value)}" ${value === selected ? 'selected' : ''}>${esc(label)}</option>`; }
function empty(title, body, action = '') { return `<div class="empty">${icon('bars')}<h3>${title}</h3><p>${body}</p>${action}</div>`; }
function bars(items, type = 'app', limit = 7) {
  if (!items.length) return empty('Aún no hay consumo validado', 'Las capturas pendientes se revisan antes de entrar al reporte.');
  const visible = items.slice(0, limit), max = Math.max(...visible.map(i => i.value), 1);
  return `<div class="bars">${visible.map((item, i) => `<div class="bar-row"><div class="bar-label">${type === 'user' ? `<span class="mini-avatar">${esc(initials(item.name))}</span>` : `<span class="rank">${String(i + 1).padStart(2, '0')}</span>`}<span title="${esc(item.name)}">${esc(item.name)}</span><strong>${number(item.value)} <small>GB</small></strong></div><div class="bar-track"><span style="width:${Math.max(item.value / max * 100, 0.4)}%;background:${type === 'app' ? colors[i % colors.length] : '#2563eb'}"></span></div></div>`).join('')}</div>`;
}
function statesChart(states, total) {
  let start = 0;
  const gradient = states.map(s => { const end = start + s.value / (total || 1) * 100; const val = `${stateColors[s.name] || '#9aabc4'} ${start}% ${end}%`; start = end; return val; }).join(',');
  return `<div class="state-layout"><div class="donut" role="img" aria-label="Estado de ${total} equipos" style="background:${total ? `conic-gradient(${gradient})` : '#e9eef7'}"><div><strong>${total}</strong><span>equipos</span></div></div><div class="legend">${states.map(s => `<div><span class="dot" style="background:${stateColors[s.name] || '#9aabc4'}"></span><span>${esc(s.name)}</span><strong>${s.value}</strong><small>${Math.round(s.value / (total || 1) * 100)}%</small></div>`).join('')}</div></div>`;
}
function dashboard(rows, summary) {
  const count = summary.valid.length;
  return `<section class="metrics">
    <article class="metric"><div class="metric-top">Consumo validado ${icon('bars')}</div><div class="metric-value">${number(summary.total)} <span>GB</span></div><p><span class="small-dot"></span>${count} capturas incluidas en el reporte</p></article>
    <article class="metric"><div class="metric-top">Promedio por equipo ${icon('phone')}</div><div class="metric-value">${number(count ? Math.round(summary.total / count * 1000) / 1000 : 0)} <span>GB</span></div><p>Sobre equipos con lectura validada</p></article>
    <article class="metric"><div class="metric-top">Equipos registrados ${icon('users')}</div><div class="metric-value">${rows.length} <span>capturas</span></div><p>${new Set(rows.map(r => r.employee).filter(Boolean)).size} usuarios en la selección</p></article>
    <article class="metric ${summary.pending.length ? 'warning-metric' : ''}"><div class="metric-top">Por revisar ${icon('shield')}</div><div class="metric-value">${summary.pending.length} <span>registros</span></div><button class="text-link" data-action="quality">${summary.pending.length ? 'Revisar antes de reportar' : 'Todas las capturas validadas'} ${icon('arrow')}</button></article>
  </section>
  ${summary.pending.length ? `<div class="notice">${icon('shield')}<div><strong>Un reporte confiable empieza con datos revisados.</strong><span>${summary.pending.length} capturas están fuera de los indicadores de consumo. Revisa su lectura, unidad o información faltante.</span></div><button data-action="quality">Revisar capturas ${icon('arrow')}</button></div>` : ''}
  ${reportCharts(rows, summary)}
  <section class="card overview-table"><div class="card-title"><div><span class="eyebrow">DETALLE MENSUAL</span><h2>Capturas de consumo</h2></div><button class="text-link" data-action="records">Ver todos los registros ${icon('arrow')}</button></div>${table(rows.slice(0, 6))}</section>
  <section class="print-details"><h2>Detalle completo de la selección</h2><p>Los registros pendientes se muestran para revisión; su consumo está excluido de los indicadores.</p>${table(rows)}<h2>Consumo completo por aplicación y usuario</h2><div class="print-lists"><div>${summary.applications.map(a => `<p>${esc(a.name)}: ${number(a.value)} GB</p>`).join('')}</div><div>${summary.users.map(u => `<p>${esc(u.name)}: ${number(u.value)} GB</p>`).join('')}</div></div></section>`;
}

function chartCard(id, kicker, title, badge, body, foot = '') {
  const visibleOrder = reportLayout.order.filter(chart => reportLayout.visible.includes(chart));
  const size = reportLayout.sizes[id], index = visibleOrder.indexOf(id);
  const heights = [...new Set([minimumHeight(id), id === 'history' ? 560 : 420, 680, size.height])].sort((a, b) => a - b);
  return `<article class="card report-card" data-chart="${id}" style="--chart-span:${size.span};--chart-height:${size.height}px">
    <div class="card-title"><button type="button" class="drag-handle icon-button" aria-label="Arrastrar gráfica: ${esc(title)}" title="Arrastra para cambiar el orden">${icon('grip')}</button><div><span class="eyebrow">${kicker}</span><h2>${title}</h2></div><span class="unit-tag">${badge}</span></div>
    <div class="chart-edit-controls"><div class="move-controls"><button class="icon-button" data-move="${id}" data-step="-1" ${index === 0 ? 'disabled' : ''} title="Mover antes" aria-label="Mover ${esc(title)} antes">${icon('up')}</button><button class="icon-button" data-move="${id}" data-step="1" ${index === visibleOrder.length - 1 ? 'disabled' : ''} title="Mover después" aria-label="Mover ${esc(title)} después">${icon('down')}</button></div><label>Ancho <select data-width="${id}" aria-label="Ancho de ${esc(title)}">${option('6', String(size.span), 'Mitad')}${option('12', String(size.span), 'Completo')}</select></label><label>Alto <select data-height="${id}" aria-label="Alto de ${esc(title)}">${heights.map(h => option(String(h), String(size.height), `${h} px`)).join('')}</select></label></div>
    <div class="report-chart-body ${isHistoricalChart(id) ? 'history-content' : ''} ${id !== 'history' && isHistoricalChart(id) ? 'aggregate-history' : ''}">${body}</div>${foot ? `<div class="card-foot">${foot}</div>` : ''}<button class="resize-handle" aria-label="Cambiar tamaño de ${esc(title)}" title="Arrastra la esquina para ajustar el tamaño. Las flechas del teclado también funcionan.">${icon('resize')}</button>
  </article>`;
}
function historyCard() {
  let error = '';
  try { historyData = buildHistory(records, { ...historyPreferences, department, query: search }); }
  catch (e) { historyData = null; error = e.message; }
  const data = historyData;
  const appNames = [...new Set([...records.flatMap(r => r.apps.map(a => a.name)), historyPreferences.metric !== 'total' ? historyPreferences.metric : ''].filter(Boolean))].sort();
  const metrics = `<option value="total" ${historyPreferences.metric === 'total' ? 'selected' : ''}>Consumo total del usuario</option>${appNames.map(a => option(a, historyPreferences.metric, a)).join('')}`;
  const context = data ? `${monthName(data.from)} — ${monthName(data.to)} · ${data.metric === 'total' ? 'Consumo total' : data.metric} · ${data.pendingCount} capturas pendientes excluidas` : '';
  const measuredMonths = data?.months.filter(m => data.series.some(s => s.points.some(p => p.period === m && p.value !== null))).length || 0;
  const body = `<div class="history-controls"><label>Desde<input type="month" id="history-from" value="${historyPreferences.from || data?.from || ''}" /></label><label>Hasta<input type="month" id="history-to" value="${historyPreferences.to || data?.to || ''}" /></label><label class="history-metric-label">Comparar<select id="history-metric">${metrics}</select></label><button class="button" data-action="compare-users">${icon('users')} Usuarios <span class="selection-count">${data?.series.length || 0}</span></button></div>
    <p class="history-context">${esc(context)}</p><p class="history-scope">El histórico usa su propio intervalo. Departamento y búsqueda también filtran esta comparación.</p>
    ${error ? `<div class="form-errors">${esc(error)}</div>` : !data?.months.length ? empty('Comienza tu historial mensual', 'Captura o importa lecturas mensuales para comparar a tus usuarios.') : !data.series.length ? empty('Selecciona usuarios para comparar', 'Usa el botón Usuarios para elegir hasta 6 personas.') : `<div id="history-plot" class="history-plot"></div><div class="history-summaries">${data.series.map((s, i) => `<div class="history-user-summary"><span class="series-dot" style="background:${SERIES_COLORS[i]}"></span><div><strong title="${esc(s.name)}">${esc(s.name)}</strong><small>#${esc(s.employee)} · ${s.last ? esc(s.last.period) : 'Sin lectura'}</small></div><div class="history-user-value"><strong>${s.last ? number(s.last.value) + ' <small>GB</small>' : '—'}</strong><small class="${s.change !== null && s.change > 0 ? 'increase' : ''}">${s.change === null ? 'Sin comparación previa' : `${s.change > 0 ? '+' : ''}${number(s.change)} GB desde ${s.first.period}`}</small></div></div>`).join('')}</div>
    <details class="history-details"><summary>Ver valores por mes ${icon('down')}</summary><div class="table-wrap"><table><thead><tr><th>Mes</th>${data.series.map(s => `<th>${esc(s.name)} · #${esc(s.employee)}</th>`).join('')}</tr></thead><tbody>${data.months.map((m, i) => `<tr><td>${esc(m)}</td>${data.series.map(s => { const p = s.points[i]; return `<td>${p.value === null ? 'Sin lectura' : `${number(p.value)} GB`}${p.pending || p.unlisted ? '<small class="partial-reading">Desglose parcial / pendientes excluidos</small>' : ''}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div></details>`}`;
  return chartCard('history', 'EVOLUCIÓN MENSUAL', 'Histórico por usuario', `${data?.series.length || 0} USUARIOS`, body, `${measuredMonths === 1 ? '<span class="single-month-note">Solo hay un mes con lectura para esta selección. Carga otros meses para ver la evolución.</span>' : measuredMonths === 0 ? 'Sin lecturas validadas en la selección.' : 'Líneas y puntos de lecturas validadas. Pasa el cursor por un punto para ver el detalle.'}<span>Sin lectura ≠ consumo cero</span>`);
}
function aggregateHistoryCard(kind) {
  const id = kind === 'total' ? 'period-total' : 'app-history', preferences = analyticsPreferences[kind];
  let data, error = '';
  try { data = buildAggregateHistory(records, { ...preferences, mode: kind, department, query: search }); }
  catch (e) { error = e.message; }
  aggregateData[kind] = data;
  const measured = data?.months.filter(m => data.series.some(s => s.points.some(p => p.period === m && p.value !== null))).length || 0;
  const context = data ? `${monthName(data.from)} — ${monthName(data.to)} · ${data.validCount} lecturas validadas · ${data.pendingCount} pendientes excluidas` : '';
  const controls = `<div class="history-controls aggregate-controls"><label>Desde<input type="month" data-aggregate="${kind}" data-field="from" value="${preferences.from || data?.from || ''}"/></label><label>Hasta<input type="month" data-aggregate="${kind}" data-field="to" value="${preferences.to || data?.to || ''}"/></label>${kind === 'apps' ? `<button class="button" data-action="compare-apps">${icon('grid')} Aplicaciones <span class="selection-count">${data?.series.length || 0}</span></button>` : ''}</div>`;
  const body = `${controls}<p class="history-context">${esc(context)}</p><p class="history-scope">Intervalo propio · respeta departamento y búsqueda.${kind === 'apps' ? ' Se muestra el consumo registrado; las apps ausentes del desglose quedan sin lectura.' : ' Las aplicaciones son un desglose y no se suman otra vez al total.'}</p>
    ${error ? `<div class="form-errors">${esc(error)}</div>` : !data?.months.length ? empty('Todavía no hay períodos capturados', 'Importa o captura las lecturas de cada mes.') : !data.series.length ? empty('Selecciona aplicaciones', 'Elige hasta 6 aplicaciones con el botón Aplicaciones.') : `<div id="${id}-plot" class="history-plot"></div><div class="history-summaries aggregate-summaries">${data.series.map((s, i) => `<div class="history-user-summary"><span class="series-dot" style="background:${SERIES_COLORS[i]}"></span><div><strong>${esc(s.name)}</strong><small>${s.last ? esc(s.last.period) : 'Sin lectura'}</small></div><div class="history-user-value"><strong>${s.last ? number(s.last.value) + ' <small>GB</small>' : '—'}</strong><small>${s.change === null ? 'Sin comparación previa' : `${s.change > 0 ? '+' : ''}${number(s.change)} GB desde ${s.first.period}`}</small></div></div>`).join('')}</div><details class="history-details"><summary>Ver valores por período ${icon('down')}</summary><div class="table-wrap"><table><thead><tr><th>Período</th>${data.series.map(s => `<th>${esc(s.name)}</th>`).join('')}</tr></thead><tbody>${data.months.map((m, i) => `<tr><td>${m}</td>${data.series.map(s => { const p = s.points[i]; return `<td>${p.value === null ? 'Sin lectura' : `${number(p.value)} GB`}${p.pending || p.unlisted ? `<small class="partial-reading">${p.pending ? `${p.pending} pendientes excluidos. ` : ''}${p.unlisted ? `${p.unlisted} equipos sin desglose de esta app.` : ''}</small>` : ''}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div></details>`}`;
  return chartCard(id, kind === 'total' ? 'TOTAL MENSUAL' : 'EVOLUCIÓN DE APLICACIONES', chartDescriptions[id][0], kind === 'total' ? 'GB / MES' : `${data?.series.length || 0} APPS`, body, `${measured === 1 ? '<span class="single-month-note">Solo hay un mes con lectura. Carga más períodos para comparar.</span>' : 'Solo lecturas validadas. Los meses sin lectura quedan vacíos.'}<span>Sin lectura ≠ cero</span>`);
}
function chartFactories(rows, summary) {
  return {
    history: () => historyCard(),
    'period-total': () => aggregateHistoryCard('total'),
    'app-history': () => aggregateHistoryCard('apps'),
    applications: () => chartCard('applications', 'APLICACIONES', 'Consumo por aplicación', 'TOP 7 · GB', bars(summary.applications), `Aplicaciones: <strong>${number(summary.identified)} GB</strong><span>Sin desglose: <strong>${number(summary.unattributed)} GB</strong></span>`),
    users: () => chartCard('users', 'USUARIOS', 'Usuarios con mayor consumo', 'TOP 7', bars(summary.users, 'user'), 'Consumo total por usuario · lecturas validadas'),
    departments: () => chartCard('departments', 'DEPARTAMENTOS', 'Consumo por departamento', 'GB', bars(summary.departments, 'department', 20)),
    states: () => chartCard('states', 'INVENTARIO', 'Condiciones de los equipos', `${rows.length} CAPTURAS`, statesChart(summary.states, rows.length), 'Incluye capturas pendientes de revisión.'),
  };
}

function reportCharts(rows, summary) {
  aggregateData = {}; historyData = null;
  const cards = chartFactories(rows, summary);
  const shown = reportLayout.order.filter(id => reportLayout.visible.includes(id));
  return `<div class="report-toolbar"><div><span class="section-marker"></span><div><h2>Analítica de consumo</h2><p>${editingReport ? 'Arrastra el asa de puntos o la esquina inferior. Los ajustes se guardan automáticamente.' : 'Elige las gráficas que necesitas para tu reporte.'}</p></div></div><div class="report-toolbar-actions">${editingReport ? `<button class="button" data-action="reset-layout">${icon('reset')} Restablecer</button>` : ''}<button class="button ${editingReport ? 'primary' : ''}" data-action="edit-layout" aria-pressed="${editingReport}">${icon(editingReport ? 'check' : 'settings')}${editingReport ? 'Terminar ajustes' : 'Personalizar reporte'}</button><button class="button primary" data-action="print" title="Imprimir las gráficas seleccionadas o guardar como PDF">${icon('print')} Imprimir reporte</button></div></div>
  <div class="chart-visibility-bar"><span><strong>${shown.length}</strong> de ${CHART_IDS.length} gráficas</span><div class="visibility-presets" role="group" aria-label="Cantidad de gráficas">${[['one', 'Una'], ['two', 'Dos'], ['all', 'Todas']].map(([preset, label]) => `<button data-visibility="${preset}" aria-pressed="${preset === 'one' ? shown.length === 1 : preset === 'two' ? shown.length === 2 : shown.length === CHART_IDS.length}">${label}</button>`).join('')}</div><button class="button" data-action="choose-charts">${icon('grid')} Elegir gráficas</button><small>Esta selección se carga al preparar el reporte.</small></div><p class="print-chart-selection">Gráficas del reporte: ${shown.map(id => esc(chartDescriptions[id][0])).join(' · ')}</p>
  <section id="report-grid" class="chart-grid report-grid ${editingReport ? 'editing' : ''}">${shown.map(id => cards[id]()).join('')}</section><div id="layout-status" class="sr-only" role="status" aria-live="polite"></div>`;
}

function chooseChartsModal() {
  const selected = new Set(reportLayout.visible);
  const el = modal('Elegir gráficas del reporte', 'Marca una, dos o las que necesites. Esta selección se carga al abrir la vista previa de impresión.', `<form id="choose-charts-form"><div class="modal-body"><div class="chart-picker-list">${Object.entries(chartDescriptions).map(([id, [name, description]]) => `<label class="chart-picker-item"><input type="checkbox" name="chart-choice" value="${id}" ${selected.has(id) ? 'checked' : ''}/><span><strong>${name}</strong><small>${description}</small></span></label>`).join('')}</div><div id="chart-choice-error" class="form-errors" role="alert"></div></div><div class="modal-footer"><span>Se guarda en este navegador.</span><button type="submit" class="button primary">Aplicar selección</button></div></form>`);
  $('#choose-charts-form', el).onsubmit = event => {
    event.preventDefault(); const visible = [...new FormData(event.target).getAll('chart-choice')];
    if (!visible.length) { $('#chart-choice-error', el).textContent = 'Selecciona al menos una gráfica.'; return; }
    updateLayout({ ...reportLayout, visible }); el.close();
  };
}
function updateAnalytics(kind, value) {
  const next = { ...analyticsPreferences, [kind]: value };
  try { localStorage.setItem(ANALYTICS_KEY, JSON.stringify(next)); analyticsPreferences = next; const y = scrollY; render(); window.scrollTo(0, y); }
  catch { toast('No se pudo guardar la configuración de análisis.', true); }
}
function compareAppsModal() {
  const data = aggregateData.apps;
  if (!data?.catalog.length) { toast('No hay aplicaciones validadas en el intervalo actual. Revisa los datos y las fechas.'); return; }
  const selected = new Set((analyticsPreferences.apps.apps ?? data.series.map(s => s.name)).filter(name => data.catalog.some(app => app.name === name)));
  const el = modal('Comparar aplicaciones', 'Elige hasta 6 aplicaciones. Se suma su consumo registrado en los equipos por mes.', `<form id="compare-apps-form"><div class="modal-body"><label class="field"><span>Buscar aplicación</span><input id="compare-app-search" type="search" placeholder="Nombre de la aplicación" /></label><div class="user-picker">${data.catalog.map(app => `<label class="user-picker-item" data-name="${esc(normalize(app.name))}"><input type="checkbox" name="compare-app" value="${esc(app.name)}" ${selected.has(app.name) ? 'checked' : ''}/><span><strong>${esc(app.name)}</strong><small>Consumo registrado en el intervalo</small></span><span class="picker-usage">${number(app.total)} GB</span></label>`).join('')}</div><div id="compare-app-error" class="form-errors" role="alert"></div></div><div class="modal-footer"><span id="compare-app-count">${selected.size} de 6 seleccionadas</span><button class="button primary" type="submit">Aplicar comparación</button></div></form>`);
  $('#compare-app-search', el).oninput = e => $$('.user-picker-item', el).forEach(label => { label.hidden = !label.dataset.name.includes(normalize(e.target.value)); });
  $$('[name="compare-app"]', el).forEach(input => input.onchange = () => {
    if (input.checked && selected.size >= 6) { input.checked = false; $('#compare-app-error', el).textContent = 'Puedes comparar hasta 6 aplicaciones.'; return; }
    if (input.checked) selected.add(input.value); else selected.delete(input.value);
    $('#compare-app-error', el).textContent = ''; $('#compare-app-count', el).textContent = `${selected.size} de 6 seleccionadas`;
  });
  $('#compare-apps-form', el).onsubmit = e => { e.preventDefault(); updateAnalytics('apps', { ...analyticsPreferences.apps, apps: [...selected] }); el.close(); };
}
function updateLayout(next) {
  const active = document.activeElement, chart = active?.closest('[data-chart]')?.dataset.chart;
  const control = active?.matches('.resize-handle') ? '.resize-handle' : active?.matches('[data-width]') ? '[data-width]' : active?.matches('[data-height]') ? '[data-height]' : active?.matches('[data-move]') ? `[data-move][data-step="${active.dataset.step}"]` : null;
  try {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(next)); reportLayout = next;
    const y = window.scrollY; render(); window.scrollTo(0, y);
    if (chart && control) $(`[data-chart="${chart}"] ${control}`)?.focus({ preventScroll: true });
    $('#layout-status').textContent = 'Distribución del reporte guardada.';
  }
  catch { render(); toast('No se pudo guardar la distribución. Revisa el almacenamiento del navegador.', true); }
}
function updateHistory(next) {
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(next)); historyPreferences = next; const y = window.scrollY; render(); window.scrollTo(0, y); }
  catch { toast('No se pudo guardar la configuración del histórico.', true); }
}
function compareUsersModal() {
  if (!historyData?.catalog.length) { toast('No hay usuarios en el intervalo actual. Revisa las fechas y los filtros.'); return; }
  const selected = new Set(historyPreferences.users ?? historyData.series.map(s => s.id));
  const el = modal('Comparar usuarios', 'Selecciona hasta 6 usuarios. La identidad se conserva por número de empleado.', `<form id="compare-users-form"><div class="modal-body"><label class="field"><span>Buscar usuario o empleado</span><input id="compare-user-search" type="search" placeholder="Nombre o número de empleado" /></label><div class="user-picker">${historyData.catalog.map(u => `<label class="user-picker-item" data-name="${esc(normalize(u.name + ' ' + u.employee))}"><input type="checkbox" name="compare-user" value="${esc(u.id)}" ${selected.has(u.id) ? 'checked' : ''}/><span class="avatar">${esc(initials(u.name))}</span><span><strong>${esc(u.name)}</strong><small>Empleado #${esc(u.employee)}</small></span><span class="picker-usage">${number(u.total)} GB</span></label>`).join('')}</div><div id="compare-error" class="form-errors" role="alert"></div></div><div class="modal-footer"><span id="compare-count">${selected.size} de 6 seleccionados</span><button class="button primary" type="submit">Aplicar comparación</button></div></form>`);
  $('#compare-user-search', el).oninput = event => $$('.user-picker-item', el).forEach(label => { label.hidden = !label.dataset.name.includes(normalize(event.target.value)); });
  $$('[name="compare-user"]', el).forEach(input => input.onchange = () => {
    if (input.checked) { if (selected.size >= 6) { input.checked = false; $('#compare-error', el).textContent = 'Puedes comparar hasta 6 usuarios a la vez.'; return; } selected.add(input.value); } else selected.delete(input.value);
    $('#compare-error', el).textContent = ''; $('#compare-count', el).textContent = `${selected.size} de 6 seleccionados`;
  });
  $('#compare-users-form', el).onsubmit = event => { event.preventDefault(); updateHistory({ ...historyPreferences, users: [...selected] }); el.close(); };
}
function table(rows) {
  if (!rows.length) return empty('Tu próximo reporte comienza aquí', 'Importa la pestaña mensual de Excel o registra una nueva captura.', `<button class="button primary" data-action="new">${icon('plus')} Nueva captura</button>`);
  return `<div class="table-wrap"><table><thead><tr><th>Usuario / equipo</th><th>Departamento</th><th>Identificación</th><th>Período</th><th>Estado del equipo</th><th class="right">Consumo total</th><th>Revisión</th><th class="action-column"><span class="sr-only">Acciones</span></th></tr></thead><tbody>${rows.map(r => {
    const issues = issuesFor(r, records);
    return `<tr><td><div class="table-user"><span class="avatar">${esc(initials(r.user))}</span><div><strong>${esc(r.user)}</strong><small>${esc(deviceLabel(r))} · #${esc(r.employee)}</small></div></div></td><td>${esc(r.department) || '—'}</td><td class="device-identification">${[['Serie',r.serial],['IMEI 1',r.imei1],['IMEI 2',r.imei2]].filter(([,v])=>v).map(([label,v])=>`<span><b>${label}:</b> ${esc(v)}</span>`).join('') || '—'}</td><td class="nowrap">${esc(r.period)}</td><td><span class="status-pill ${r.status === 'Dañado' || r.status === 'Descompuesto' ? 'danger' : r.status === 'Desgaste' ? 'amber' : ''}">${esc(r.status) || 'Sin estado'}</span></td><td class="right usage">${r.totalGb === null ? 'Sin lectura' : `${number(r.totalGb)} <small>GB</small>`}</td><td><span class="review-status ${issues.length ? 'pending' : ''}" title="${esc(issues.join(' '))}"><span></span>${issues.length ? 'Por revisar' : 'Validado'}</span></td><td class="action-column"><button class="icon-button" data-edit="${esc(r.id)}" title="Editar captura de ${esc(r.user)}" aria-label="Editar captura de ${esc(r.user)}">${icon('edit')}</button></td></tr>`;
  }).join('')}</tbody></table></div>`;
}
function qualityView(rows) {
  const pending = rows.filter(r => issuesFor(r, records).length);
  return `<div class="notice">${icon('shield')}<div><strong>Los datos pendientes se conservan, pero no se suman al consumo.</strong><span>Corrige con la lectura del dispositivo. Un total mayor que las aplicaciones puede ser válido: el resto se muestra como “Sin desglose”.</span></div></div>
  ${pending.length ? `<div class="quality-grid">${pending.map(r => `<article class="card quality-card"><div class="quality-header"><span class="avatar">${esc(initials(r.user))}</span><div><h3>${esc(r.user)}</h3><p>${esc(deviceLabel(r))} · ${esc(r.period)} · ${esc(r.department)}</p></div></div><ul>${issuesFor(r, records).map(i => `<li>${esc(i)}</li>`).join('')}</ul><div class="quality-bottom"><span>${r.source ? `Excel · ${esc(r.source.sheet)} · fila ${esc(r.source.row)}` : 'Captura manual'}</span><button class="button" data-edit="${esc(r.id)}">${icon('edit')} Revisar</button></div></article>`).join('')}</div>` : `<article class="card">${empty('Todo en orden', 'Las capturas de esta selección cumplen las reglas de validación.')}</article>`}`;
}
function render() {
  if (serverMode && !auth.user) { showLogin(); return; }
  cleanupHistoryPlots.forEach(cleanup => cleanup?.()); cleanupHistoryPlots = [];
  const rows = filtered(), summary = summarize(rows, records), months = [...new Set(records.map(r => r.period))].sort().reverse();
  const departments = [...new Set(records.map(r => r.department).filter(Boolean))].sort();
  const titles = { dashboard: ['Resumen de consumo', 'Visibilidad mensual para tomar mejores decisiones.'], records: ['Capturas mensuales', 'Usuarios, equipos y aplicaciones en un solo lugar.'], quality: ['Calidad de datos', 'Revisa las lecturas antes de incluirlas en tus reportes.'] };
  const pendingTotal = records.filter(r => issuesFor(r, records).length).length;
  $('#app').innerHTML = `<aside class="sidebar"><a class="brand" href="#" data-action="dashboard"><span class="brand-mark">${icon('bars')}</span><span>consumo<span class="brand-sub">CONTROL DE DISPOSITIVOS</span></span></a><div class="workspace"><span class="workspace-icon">A</span><div><strong>Artron</strong><small>${serverMode ? 'Datos oficiales compartidos' : 'Espacio de trabajo local'}</small></div><span class="local-dot"></span></div><span class="nav-label">PRINCIPAL</span><nav>${[['dashboard', 'grid', 'Resumen'], ['records', 'phone', 'Capturas mensuales'], ['quality', 'shield', 'Calidad de datos']].map(([value, glyph, label]) => `<button data-action="${value}" class="nav-item ${tab === value ? 'active' : ''}">${icon(glyph)}<span>${label}</span>${value === 'quality' && pendingTotal ? `<span class="nav-count">${pendingTotal}</span>` : ''}</button>`).join('')}</nav><span class="nav-label secondary-nav">HERRAMIENTAS</span><nav>${serverMode && canAdmin() ? `<button class="nav-item" data-action="users">${icon('users')}<span>Usuarios y permisos</span></button><button class="nav-item" data-action="audit">${icon('shield')}<span>Registro de cambios</span></button>` : ''}<button class="nav-item" data-action="import">${icon('upload')}<span>Importar Excel</span></button><button class="nav-item" data-action="backup">${icon('database')}<span>Respaldo y exportación</span></button><button class="nav-item" data-action="print">${icon('print')}<span>Imprimir reporte</span></button></nav><div class="sidebar-bottom"><div class="storage-note">${icon('database')}<strong>${serverMode ? 'Datos oficiales en el servidor' : 'Tus datos, en este navegador'}</strong><p>${serverMode ? 'Los permisos protegen las capturas compartidas. Cada cambio queda registrado.' : 'Exporta un respaldo para conservar o trasladar tus capturas.'}</p><button data-action="backup">Crear respaldo ${icon('arrow')}</button></div><div class="sidebar-footer"><span class="version-dot"></span>${serverMode ? 'Acceso controlado' : 'Almacenamiento local'}<span>v1.7</span></div></div></aside>
  <main><header class="topbar"><div class="breadcrumb">Operaciones ${icon('chevron')} <strong>Consumo de datos</strong></div><div class="topbar-right"><span class="saved-indicator"><span></span>${fatal ? 'Almacenamiento por revisar' : serverMode ? 'Datos del servidor' : savedAt ? 'Guardado localmente' : 'Modo local'}</span><span class="profile" title="${serverMode ? esc(auth.user.name) : 'Artron'}">${serverMode ? esc(initials(auth.user.name)) : 'A'}</span>${serverMode ? `<span class="role-badge">${roleNames[auth.user.role]}</span><button class="button" data-action="refresh">Actualizar</button><button class="button" data-action="logout">Salir</button>` : ''}</div></header><div class="content"><div class="page-heading"><div><span class="eyebrow">CONTROL MENSUAL · EQUIPOS Y CONSUMO</span><h1>${titles[tab][0]}</h1><p>${titles[tab][1]}</p></div><div class="heading-actions"><button class="button" data-action="print">${icon('print')}<span>Imprimir reporte</span></button><button class="button primary" data-action="new">${icon('plus')} Nueva captura</button></div></div>
  ${tab === 'dashboard' ? `<section class="quick-actions" aria-label="Acciones de consumo"><button data-action="import"><span class="quick-icon">${icon('upload')}</span><span><strong>Importar Excel</strong><small>Cargar tus lecturas mensuales</small></span>${icon('chevron')}</button><button data-action="quality"><span class="quick-icon">${icon('shield')}</span><span><strong>Revisar capturas${summary.pending.length ? ` <span class="quick-count">${summary.pending.length}</span>` : ''}</strong><small>Verificar lecturas y unidades</small></span>${icon('chevron')}</button><button data-action="backup"><span class="quick-icon">${icon('download')}</span><span><strong>Respaldar y exportar</strong><small>Guardar una copia del reporte</small></span>${icon('chevron')}</button></section>` : `<div class="mobile-tools"><button class="button" data-action="import">${icon('upload')} Importar Excel</button><button class="button" data-action="backup">${icon('database')} Respaldos</button></div>`}
  ${fatal ? `<div class="notice error-notice">${icon('alert')}<div><strong>No se pudo leer el almacenamiento.</strong><span>Los datos originales permanecen intactos. Descarga una copia para recuperarlos; la escritura está bloqueada.</span></div><button data-action="raw">Descargar original</button></div>` : ''}
  <section class="filters"><div class="filter-group"><label class="filter-label" for="period">${icon('calendar')}<span class="sr-only">Período</span></label><select id="period" aria-label="Período">${option('', period, 'Todos los períodos')}${months.map(m => option(m, period, monthName(m))).join('')}</select></div><div class="filter-group department-filter"><label class="sr-only" for="department">Departamento</label><select id="department" aria-label="Departamento">${option('', department, 'Todos los departamentos')}${departments.map(d => option(d, department)).join('')}</select></div><div class="search-filter">${icon('search')}<input id="search" placeholder="Buscar usuario, equipo o aplicación…" value="${esc(search)}" aria-label="Buscar usuario, equipo o aplicación" /></div><button class="icon-button clear-filters" data-action="clear" title="Limpiar filtros" aria-label="Limpiar filtros">${icon('close')}</button></section>
  <div class="report-context"><span><span class="small-dot"></span>${esc(monthName(period))} ${department ? '· ' + esc(department) : ''} ${search ? '· Búsqueda: ' + esc(search) : ''}</span><span>${rows.length} registros en la selección</span></div>
  ${tab === 'dashboard' ? dashboard(rows, summary) : tab === 'quality' ? qualityView(rows) : `<section class="card"><div class="card-title"><h2>${rows.length} capturas mensuales</h2><div class="heading-actions"><button class="button primary" data-action="excel">${icon('download')} Descargar Excel</button><button class="button" data-action="csv">${icon('download')} CSV</button></div></div>${table(rows)}</section>`}
  <footer class="page-footer"><span>Consumo · Artron <span class="footer-separator">/</span> ${esc(monthName(period))}</span><span>1 GB = 1,000 MB · Solo lecturas validadas en indicadores</span></footer></div></main>`;
  applyAccess();
  $$('[data-action]').forEach(button => button.addEventListener('click', event => { event.preventDefault(); action(button.dataset.action); }));
  $$('[data-edit]').forEach(button => button.addEventListener('click', () => recordModal(records.find(r => r.id === button.dataset.edit))));
  $('#period').addEventListener('change', e => { period = e.target.value; render(); });
  $('#department').addEventListener('change', e => { department = e.target.value; render(); });
  $('#search').addEventListener('input', e => {
    const pos = e.target.selectionStart; search = e.target.value; render(); const input = $('#search'); input.focus(); input.setSelectionRange(pos, pos);
  });
  if (tab === 'dashboard') {
    if (historyData) cleanupHistoryPlots.push(drawHistory($('#history-plot'), historyData));
    if (aggregateData.total) cleanupHistoryPlots.push(drawHistory($('#period-total-plot'), aggregateData.total, { type: 'bars' }));
    if (aggregateData.apps) cleanupHistoryPlots.push(drawHistory($('#app-history-plot'), aggregateData.apps));
    if (editingReport) bindReportEditor($('#report-grid'), reportLayout, updateLayout);
    for (const field of ['from', 'to', 'metric']) $(`#history-${field}`)?.addEventListener('change', event => updateHistory({ ...historyPreferences, [field]: event.target.value }));
    $$('[data-aggregate]').forEach(input => input.onchange = () => updateAnalytics(input.dataset.aggregate, { ...analyticsPreferences[input.dataset.aggregate], [input.dataset.field]: input.value }));
    $$('[data-visibility]').forEach(button => button.onclick = () => updateLayout({ ...reportLayout, visible: button.dataset.visibility === 'one' ? ['period-total'] : button.dataset.visibility === 'two' ? [...DEFAULT_VISIBLE] : [...CHART_IDS] }));
  }
}
function action(name) {
  if (serverMode) {
    if (name === 'raw') return;
    if (['import', 'backup', 'csv', 'excel', 'users', 'audit'].includes(name) && !canAdmin()) return;
    if (name === 'new' && !canCapture()) return;
    if (name === 'logout') { logout(); return; }
    if (name === 'refresh') { refreshOfficial().catch(handleAccessError); return; }
    if (name === 'users') { usersModal().catch(handleAccessError); return; }
    if (name === 'audit') { auditModal().catch(handleAccessError); return; }
  }
  if (name === 'edit-layout') { editingReport = !editingReport; render(); }
  if (name === 'reset-layout') { updateLayout({ ...normalizeLayout(), visible: reportLayout.visible }); toast('Distribución original restaurada.'); }
  if (name === 'compare-users') compareUsersModal();
  if (name === 'compare-apps') compareAppsModal();
  if (name === 'choose-charts') chooseChartsModal();
  if (['dashboard', 'records', 'quality'].includes(name)) { tab = name; render(); }
  if (name === 'new') recordModal();
  if (name === 'import') importModal();
  if (name === 'backup') backupModal();
  if (name === 'excel') exportExcel();
  if (name === 'csv') download(csvReport(filtered(), records), `consumo-${period || 'todos'}.csv`, 'text/csv;charset=utf-8');
  if (name === 'raw') download(localStorage.getItem(STORAGE_KEY) || '', 'consumo-almacenamiento-original.json', 'application/json');
  if (name === 'clear') { period = ''; department = ''; search = ''; render(); }
  if (name === 'print') printReport();
}
function printReport() {
  if ($('#print-designer')) return;
  $('#dialog')?.remove();
  tab = 'dashboard'; editingReport = false; render();
  const rows = filtered(), summary = summarize(rows, records), factories = chartFactories(rows, summary);
  const oldHistory = historyData, oldAggregate = aggregateData;
  const pairs = items => ({ headers: ['Concepto', 'Consumo (GB)'], rows: items.map(item => [item.name, number(item.value)]) });
  const tables = { applications: pairs(summary.applications), users: pairs(summary.users), departments: pairs(summary.departments), states: { headers: ['Estado del equipo', 'Capturas'], rows: summary.states.map(s => [s.name, s.value]) } };
  const charts = CHART_IDS.map(id => {
    const html = factories[id](), source = document.createElement('div'); source.innerHTML = html;
    const table = source.querySelector('.history-details table');
    const history = id === 'history' ? historyData : id === 'period-total' ? aggregateData.total : id === 'app-history' ? aggregateData.apps : null;
    return { id, title: chartDescriptions[id][0], badge: source.querySelector('.unit-tag')?.textContent, html, history, table: tables[id] || { headers: table ? [...table.querySelectorAll('thead th')].map(cell => cell.textContent.trim()) : ['Período', 'Consumo (GB)'], rows: table ? [...table.querySelectorAll('tbody tr')].map(row => [...row.cells].map(cell => [...cell.childNodes].map(node => node.textContent).join(' ').trim())) : [] } };
  });
  historyData = oldHistory; aggregateData = oldAggregate;
  openPrintDesigner({ charts, selected: reportLayout.order.filter(id => reportLayout.visible.includes(id)), summary, rowCount: rows.length,
    context: [monthName(period), department || 'Todos los departamentos', search ? 'Búsqueda: ' + search : ''].filter(Boolean).join(' · '),
    note: `${summary.valid.length} capturas validadas · ${summary.pending.length} pendientes excluidos. Los históricos conservan el intervalo indicado en cada gráfica.`,
    captures: { headers: ['Período', 'Usuario / empleado', 'Departamento', 'Equipo', 'Serie', 'IMEI 1 / IMEI 2', 'Consumo (GB)', 'Revisión'], rows: rows.map(r => [r.period, `${r.user} · #${r.employee}`, r.department, deviceLabel(r), r.serial || '—', [r.imei1, r.imei2].filter(Boolean).join(' / ') || '—', r.totalGb === null ? 'Sin lectura' : number(r.totalGb), issuesFor(r, records).length ? 'Pendiente · excluido de indicadores' : 'Validado']) },
  });
}
window.addEventListener('beforeprint', () => { if (!$('#print-designer') && (!serverMode || auth.user)) printReport(); });

let lastFocus;
function modal(title, subtitle, html, wide = false) {
  lastFocus = document.activeElement;
  $('#dialog')?.remove();
  const el = document.createElement('dialog'); el.id = 'dialog'; el.className = wide ? 'wide' : '';
  el.innerHTML = `<div class="modal-header"><div><h2>${title}</h2><p>${subtitle}</p></div><button class="icon-button" data-close aria-label="Cerrar">${icon('close')}</button></div>${html}`;
  document.body.append(el); el.showModal();
  $('[data-close]', el).addEventListener('click', () => el.close());
  el.addEventListener('close', () => { el.remove(); lastFocus?.focus(); });
  el.addEventListener('click', e => { if (e.target === el) { const bounds = el.getBoundingClientRect(); if (e.clientX < bounds.left || e.clientX > bounds.right || e.clientY < bounds.top || e.clientY > bounds.bottom) el.close(); } });
  return el;
}
function field(label, name, value = '', extra = '') { return `<label class="field"><span>${label}</span><input name="${name}" value="${esc(value)}" ${extra}/></label>`; }
function selectField(label, name, list, value = '', required = false) { return `<label class="field"><span>${label}</span><select name="${name}" ${required ? 'required' : ''}><option value="">Seleccionar…</option>${list.map(v => option(v, value)).join('')}</select></label>`; }
function appRow(app = { name: '', gb: '' }) {
  return `<div class="app-input-row"><label class="field"><span>Aplicación</span><select name="appName"><option value="">Seleccionar aplicación…</option>${[...new Set([...APPS, ...records.flatMap(r => r.apps.map(a => a.name)), app.name].filter(Boolean))].sort().map(a => option(a, app.name)).join('')}</select></label><label class="field"><span>Consumo</span><input name="appAmount" inputmode="decimal" placeholder="0.000" value="${esc(app.gb ?? '')}" /></label><label class="field unit-field"><span>Unidad</span><select name="appUnit"><option value="">Elegir…</option>${option('MB', typeof app.gb === 'number' ? 'GB' : '')}${option('GB', typeof app.gb === 'number' ? 'GB' : '')}</select></label><button type="button" class="icon-button remove-app" aria-label="Quitar aplicación">${icon('trash')}</button></div>`;
}
function recordModal(original) {
  if (!canCapture() || (original && !canAdmin())) { toast('Esta acción requiere otro permiso.', true); return; }
  const existing = Boolean(original), r = original || { period: period || thisMonth(), apps: [{ name: '', gb: '' }], status: 'Bueno' };
  const departments = [...new Set([...DEPARTMENTS, ...records.map(i => i.department)].filter(Boolean))];
  const el = modal(existing ? 'Revisar captura' : 'Nueva captura mensual', 'Registra la lectura del dispositivo. Los consumos se guardan en GB.', `<form id="capture-form"><div class="modal-body">
    ${r.source ? `<div class="source-note">${icon('file')} Origen: ${esc(r.source.sheet)} · fila ${esc(r.source.row)} · período ${esc(r.period)}${r.source.capturedAt ? `<small>Fecha de captura original: ${esc(r.source.capturedAt)}</small>` : ''}</div>` : ''}
    ${r.source?.rawReadings ? `<details class="extra-fields"><summary>Ver lecturas originales del Excel ${icon('down')}</summary><p>Total original: ${esc(r.source.rawReadings.total) || 'Sin lectura'} ${esc(r.source.unit)}</p>${r.source.rawReadings.apps.filter(a => a.name || a.amount).map(a => `<p>${esc(a.name)}: ${esc(a.amount) || 'Sin lectura'} ${esc(a.unit || r.source.unit)}</p>`).join('')}</details>` : ''}
    ${existing && issuesFor(r, records).length ? `<div class="form-notice"><strong>Esta captura necesita revisión</strong><ul>${issuesFor(r, records).map(i => `<li>${esc(i)}</li>`).join('')}</ul></div>` : ''}
    <h3 class="form-section">01 <span>Usuario y equipo</span></h3><div class="form-grid">${field('Período de consumo *', 'period', r.period, 'type="month" required')}${field('Número de empleado *', 'employee', r.employee, 'required maxlength="80"')}${field('Nombre del usuario *', 'user', r.user, 'required maxlength="150" list="known-users"')}${selectField('Departamento *', 'department', departments, r.department, true)}${selectField('Equipo *', 'device', DEVICE_TYPES, canonicalDeviceType(r.device), true)}${selectField('Estado del equipo *', 'status', STATES, r.status, true)}${field('Marca', 'brand', r.brand, 'maxlength="100"')}${field('Modelo', 'model', r.model, 'maxlength="100"')}${field('Número de serie del equipo', 'serial', r.serial, 'maxlength="150"')}${field('Teléfono', 'phone', r.phone, 'type="tel" maxlength="30"')}
    </div>${!canonicalDeviceType(r.device) && r.device ? `<p class="helper legacy-equipment">Equipo registrado anteriormente: <strong>${esc(r.device)}</strong>. Selecciona Móvil, Laptop o PC; verifica la marca y el modelo.</p>` : r.deviceDescription ? `<p class="helper legacy-equipment">Nombre original del equipo: ${esc(r.deviceDescription)}</p>` : ''}
    <div class="equipment-imei"><div class="equipment-imei-heading"><strong>Identificación celular</strong><span>Opcional · uno o dos IMEI</span></div><div class="form-grid">${field('IMEI 1 (opcional)', 'imei1', r.imei1, 'inputmode="numeric" pattern="[0-9]{15}" maxlength="15" placeholder="15 dígitos" title="Escribe los 15 dígitos del IMEI, sin espacios ni guiones."')}${field('IMEI 2 (opcional)', 'imei2', r.imei2, 'inputmode="numeric" pattern="[0-9]{15}" maxlength="15" placeholder="Segundo IMEI, si aplica" title="Escribe los 15 dígitos del segundo IMEI, sin espacios ni guiones."')}</div><p class="helper">Para equipos con conexión celular. Si usa un solo chip, puedes dejar IMEI 2 vacío. La serie del equipo se registra por separado.</p></div><details class="extra-fields"><summary>Más información del equipo ${icon('down')}</summary><div class="form-grid">${field('Empresa', 'company', r.company)}${field('Sede', 'site', r.site)}${field('Puesto', 'position', r.position)}${field('MAC', 'mac', r.mac)}${field('IP', 'ip', r.ip)}</div></details>
    <h3 class="form-section">02 <span>Lectura de consumo</span></h3><div class="total-input"><label class="field"><span>Consumo total del dispositivo *</span><input name="total" inputmode="decimal" value="${esc(r.totalGb ?? '')}" placeholder="0.000" required /></label><label class="field unit-field"><span>Unidad</span><select name="totalUnit" required><option value="">Elegir…</option>${option('MB', typeof r.totalGb === 'number' ? 'GB' : '')}${option('GB', typeof r.totalGb === 'number' ? 'GB' : '')}</select></label><div class="conversion-note" id="total-conversion">Elige MB o GB según la pantalla del equipo.<br>825 MB = 0.825 GB · 1.23 GB = 1.23 GB</div></div>
    <div class="application-heading"><h4>Consumo por aplicación</h4><button type="button" class="text-link" id="new-app-catalog">${icon('plus')} Nueva aplicación</button></div><div id="app-inputs">${(r.apps.length ? r.apps : [{ name: '', gb: '' }]).map(appRow).join('')}</div><button type="button" class="button subtle" id="add-app">${icon('plus')} Agregar aplicación</button><div class="calculation" id="calculation" aria-live="polite"></div><p class="helper">Registra las aplicaciones visibles en el equipo. El consumo restante se reporta como “Sin desglose”. No sumamos las aplicaciones al total del dispositivo.</p>
    <h3 class="form-section">03 <span>Observaciones y revisión</span></h3><label class="field"><span>Comentarios sobre el equipo</span><textarea name="comments" rows="2" maxlength="2000">${esc(r.comments)}</textarea></label><label class="field"><span>Nota de revisión / motivo de la corrección</span><textarea name="reviewNote" rows="2" maxlength="2000" placeholder="Ej. Verifiqué la lectura y convertí 628 MB a 0.628 GB.">${esc(r.reviewNote)}</textarea></label><label class="checkbox"><input type="checkbox" name="reviewedHigh" ${r.reviewedHigh ? 'checked' : ''}/> Verifiqué una lectura superior a ${HIGH_GB} GB o un aumento mayor a 3 veces el mes anterior.</label><div id="form-errors" class="form-errors" role="alert"></div>
    <datalist id="known-users">${[...new Set(records.map(i => i.user))].map(u => `<option value="${esc(u)}"></option>`).join('')}</datalist>
    </div><div class="modal-footer">${existing ? `<button class="button danger-button" type="button" id="delete-record">${icon('trash')} Eliminar</button>` : '<span class="required-note">* Campos obligatorios</span>'}<div><button type="button" class="button" id="cancel-capture">Cancelar</button><button type="submit" class="button primary">${icon('check')} Guardar captura</button></div></div></form>`, true);
  if (serverMode && !canAdmin()) { $('[name=reviewNote]', el).closest('label').remove(); $('[name=reviewedHigh]', el).closest('label').remove(); }
  $('#cancel-capture', el).onclick = () => el.close();
  const bindRemove = () => $$('.remove-app', el).forEach(button => button.onclick = () => { button.closest('.app-input-row').remove(); calculate(); });
  $('#add-app', el).onclick = () => { $('#app-inputs', el).insertAdjacentHTML('beforeend', appRow()); bindRemove(); calculate(); };
  $('#new-app-catalog', el).onclick = () => {
    const name = window.prompt('Nombre de la aplicación que quieres registrar:');
    if (!name?.trim()) return;
    const canonical = canonicalApp(name.slice(0, 100));
    $$('.app-input-row select[name="appName"]', el).forEach(select => { if (![...select.options].some(o => o.value === canonical)) select.insertAdjacentHTML('beforeend', option(canonical)); });
    $('#app-inputs', el).insertAdjacentHTML('beforeend', appRow({ name: canonical, gb: '' })); bindRemove(); calculate();
  };
  function calculate() {
    const totalInput = $('[name="total"]', el), totalUnit = $('[name="totalUnit"]', el);
    try {
      if (totalInput.value && totalUnit.value) {
        const converted = parseUsage(totalInput.value, totalUnit.value);
        $('#total-conversion', el).textContent = `${totalInput.value} ${totalUnit.value} = ${number(converted)} GB${totalUnit.value === 'GB' && converted > HIGH_GB ? ' · ¿La pantalla indica MB? Revisa la unidad.' : ''}`;
      } else $('#total-conversion', el).textContent = 'Elige MB o GB según la pantalla del equipo. 825 MB = 0.825 GB.';
    } catch { $('#total-conversion', el).textContent = 'Revisa el formato de la lectura.'; }
    $$('.app-input-row', el).forEach(row => {
      const amount = $('[name="appAmount"]', row), unit = $('[name="appUnit"]', row);
      let preview = $('.unit-preview', row);
      if (!preview) { preview = document.createElement('small'); preview.className = 'unit-preview'; amount.parentElement.append(preview); }
      try { preview.textContent = amount.value && unit.value ? `${number(parseUsage(amount.value, unit.value))} GB${unit.value === 'GB' && parseUsage(amount.value, unit.value) > HIGH_GB ? ' · revisar unidad' : ''}` : amount.value ? 'Elige MB o GB' : ''; }
      catch { preview.textContent = 'Revisa la lectura'; }
    });
    try {
      const sum = round($$('.app-input-row', el).reduce((s, row) => s + ($('[name="appAmount"]', row).value ? parseUsage($('[name="appAmount"]', row).value, $('[name="appUnit"]', row).value) : 0), 0));
      const totalValue = $('[name="total"]', el).value;
      const total = totalValue ? parseUsage(totalValue, $('[name="totalUnit"]', el).value) : null;
      const invalid = total !== null && sum > total + 0.001;
      $('#calculation', el).className = `calculation ${invalid ? 'invalid' : ''}`;
      $('#calculation', el).innerHTML = `<span>Aplicaciones: <strong>${number(sum)} GB</strong></span><span>${total !== null ? invalid ? 'Las aplicaciones superan el total' : `Sin desglose: <strong>${number(round(total - sum))} GB</strong>` : 'Completa el consumo total'}</span>`;
    } catch { $('#calculation', el).textContent = 'Selecciona MB o GB para cada lectura y usa hasta 3 decimales, sin separadores de miles.'; }
  }
  bindRemove(); calculate(); el.addEventListener('input', calculate); el.addEventListener('change', calculate);
  $('[name="user"]', el).addEventListener('change', e => {
    if (existing) return;
    const match = records.filter(i => i.user === e.target.value).sort((a, b) => b.period.localeCompare(a.period))[0];
    if (!match) return;
    for (const field of ['employee', 'department', 'device', 'serial', 'imei1', 'imei2', 'phone', 'company', 'site', 'position', 'brand', 'model', 'mac', 'ip', 'status']) if (!$( `[name="${field}"]`, el).value || field === 'status') $('[name="' + field + '"]', el).value = field === 'device' ? canonicalDeviceType(match.device) : match[field] || '';
  });
  if (existing) $('#delete-record', el).onclick = async () => {
    if (window.confirm(`¿Eliminar la captura de ${r.user} del período ${r.period}? Exporta un respaldo si quieres conservarla.`)) {
      if (await commit(records.filter(i => i.id !== r.id), 'Captura eliminada del almacenamiento local.')) el.close();
    }
  };
  $('#capture-form', el).onsubmit = async event => {
    event.preventDefault();
    const data = new FormData(event.target), errors = [];
    const next = { ...(original || {}), id: original?.id || crypto.randomUUID(), apps: [], importErrors: [], createdAt: original?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
    for (const field of ['period', 'employee', 'user', 'department', 'device', 'status', 'serial', 'imei1', 'imei2', 'phone', 'company', 'site', 'position', 'brand', 'model', 'mac', 'ip', 'comments', 'reviewNote']) next[field] = String(data.get(field) || '').trim();
    next.deviceDescription = original?.deviceDescription || (original?.device && !canonicalDeviceType(original.device) ? original.device : '');
    if (!DEVICE_TYPES.includes(next.device)) errors.push('Selecciona Móvil, Laptop o PC en Equipo.');
    next.reviewedHigh = data.has('reviewedHigh');
    try { next.totalGb = parseUsage(data.get('total'), data.get('totalUnit')); } catch (e) { errors.push(`Total: ${e.message}`); next.totalGb = null; }
    $$('.app-input-row', el).forEach(row => {
      const name = $('[name="appName"]', row).value, amount = $('[name="appAmount"]', row).value;
      if (!name && !amount) return;
      try { next.apps.push({ name: canonicalApp(name), gb: parseUsage(amount, $('[name="appUnit"]', row).value) }); } catch (e) { errors.push(`${name || 'Aplicación'}: ${e.message}`); }
    });
    errors.push(...issuesFor(next, records));
    if (existing && !next.reviewNote) errors.push('Agrega una nota que explique la revisión o corrección.');
    if (errors.length) { $('#form-errors', el).innerHTML = `<strong>Revisa antes de guardar</strong><ul>${[...new Set(errors)].map(e => `<li>${esc(e)}</li>`).join('')}</ul>`; $('#form-errors', el).scrollIntoView({ block: 'nearest' }); return; }
    if (next.reviewNote) next.reviewHistory = [...(original?.reviewHistory || []), { at: next.updatedAt, note: next.reviewNote, previousTotalGb: original?.totalGb ?? null }].slice(-30);
    const list = existing ? records.map(i => i.id === next.id ? next : i) : [...records, next];
    if (await commit(list, 'Captura validada y guardada en este navegador.')) el.close();
  };
}

function importModal() {
  importSheets = []; importCandidates = [];
  const el = modal('Importar capturas de Excel', 'Selecciona una sola pestaña y el mes que representan sus lecturas.', `<div class="modal-body"><label class="upload-zone">${icon('upload')}<strong>Seleccionar archivo Excel</strong><span>Formato .xlsx · archivo de AppSheet · máximo 10 MB</span><input type="file" id="excel-file" accept=".xlsx" /></label><div id="import-options" hidden><div class="form-grid"><label class="field"><span>Pestaña de datos</span><select id="import-sheet"></select></label><label class="field"><span>Período de consumo</span><input type="month" id="import-period" value="${period || thisMonth()}" required /></label><label class="field"><span>Unidad de los números de la hoja</span><select id="import-unit"><option value="">Mixtas o no especificadas · revisar</option><option value="GB">Toda la hoja está en GB · confirmado</option><option value="MB">Toda la hoja está en MB · confirmado</option></select></label></div><p class="helper">El mes es el período reportado, aunque la fecha de captura sea posterior. Si hay unidades mezcladas, usa columnas APP1 UNIDAD, APP2 UNIDAD, APP3 UNIDAD y TOTAL UNIDAD (MB/GB), o celdas como “825 MB”. Sin unidad quedan por revisar. La selección global solo es válida si toda la hoja usa esa unidad.</p><button class="button" id="preview-import">Previsualizar importación ${icon('arrow')}</button></div><div id="import-error" class="form-errors" role="alert"></div><div id="import-preview"></div></div><div class="modal-footer"><span>Los registros existentes se conservan.</span><button class="button primary" id="confirm-import" disabled>${icon('check')} Importar capturas</button></div>`, true);
  $('#excel-file', el).onchange = async event => {
    const file = event.target.files[0];
    $('#confirm-import', el).disabled = true; $('#import-preview', el).innerHTML = ''; $('#import-options', el).hidden = true;
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) { $('#import-error', el).textContent = 'El archivo supera 10 MB.'; return; }
    $('#import-error', el).textContent = 'Leyendo las pestañas…';
    try {
      importSheets = await readXlsxFile(file);
      $('#import-sheet', el).innerHTML = importSheets.map(s => option(s.sheet, '', s.sheet)).join('');
      const july = importSheets.find(s => normalize(s.sheet) === 'julio');
      if (july) $('#import-sheet', el).value = july.sheet;
      $('#import-options', el).hidden = false; $('#import-error', el).textContent = '';
    } catch { $('#import-error', el).textContent = 'No se pudo leer el archivo. Usa un libro .xlsx válido y sin contraseña.'; }
  };
  $$('#import-options select, #import-options input', el).forEach(input => input.onchange = () => { $('#confirm-import', el).disabled = true; $('#import-preview', el).innerHTML = ''; });
  $('#preview-import', el).onclick = () => {
    try {
      const selected = importSheets.find(s => s.sheet === $('#import-sheet', el).value);
      const selectedPeriod = $('#import-period', el).value;
      if (!selectedPeriod) throw new Error('Selecciona el período de consumo.');
      importCandidates = rowsToRecords(selected.data, selectedPeriod, selected.sheet, $('#import-unit', el).value);
      if (importCandidates.length > 10000 || records.length + importCandidates.length > 10000) throw new Error('El almacenamiento admite hasta 10,000 registros.');
      $('#import-error', el).textContent = '';
      previewCandidates(el);
    } catch (e) { $('#import-error', el).textContent = e.message; $('#confirm-import', el).disabled = true; }
  };
  $('#confirm-import', el).onclick = () => finishImport(el);
}
function eligibleCandidates() {
  const accepted = [...records], ids = new Set(records.map(r => r.id));
  return importCandidates.filter(r => {
    if (ids.has(r.id) || accepted.some(other => other.period === r.period && sameDevice(other, r))) return false;
    accepted.push(r); ids.add(r.id); return true;
  });
}
function previewCandidates(el) {
  const eligible = eligibleCandidates(), skipped = importCandidates.length - eligible.length;
  const all = [...records, ...eligible], pending = eligible.filter(r => issuesFor(r, all).length).length;
  $('#import-preview', el).innerHTML = `<div class="import-summary"><div><strong>${eligible.length}</strong><span>capturas nuevas</span></div><div><strong>${pending}</strong><span>por revisar</span></div><div><strong>${skipped}</strong><span>duplicados omitidos</span></div></div><p class="helper">Los duplicados se omiten sin sobrescribir capturas. Los registros con errores se guardan para revisión y quedan fuera de los indicadores.</p><div class="table-wrap"><table><thead><tr><th>Usuario</th><th>Equipo / período</th><th>Total GB</th><th>Resultado de validación</th></tr></thead><tbody>${eligible.slice(0, 20).map(r => `<tr><td>${esc(r.user)}</td><td>${esc(deviceLabel(r))}<br>${esc(r.period)}</td><td>${r.totalGb === null ? 'Sin lectura' : number(r.totalGb)}</td><td>${issuesFor(r, all).map(i => esc(i)).join('<br>') || '<span class="review-status">Validado</span>'}</td></tr>`).join('')}</tbody></table></div>${eligible.length > 20 ? `<p class="helper">Previsualización de 20 de ${eligible.length} registros.</p>` : ''}`;
  $('#confirm-import', el).disabled = !eligible.length || Boolean(fatal);
}
async function finishImport(el) {
  const eligible = eligibleCandidates();
  if (!eligible.length) return;
  if (await commit([...records, ...eligible], `${eligible.length} capturas importadas. Los datos pendientes requieren revisión.`, { allowPending: true })) {
    period = eligible[0].period; tab = 'dashboard'; render(); el.close();
  }
}
function backupModal() {
  const el = modal('Respaldo y exportación', 'Los datos se guardan en este navegador. Un respaldo permite trasladarlos a otro equipo.', `<div class="modal-body"><div class="export-card">${icon('database')}<div><h3>Respaldo completo · JSON</h3><p>${records.length} registros, aplicaciones, origen y notas de revisión. Para restaurar o integrar a Artron.</p></div><button class="button primary" id="download-backup">${icon('download')} Descargar</button></div><div class="export-card">${icon('file')}<div><h3>Reporte completo · Excel (.xlsx)</h3><p>${filtered().length} capturas de la selección, detalle de apps y resúmenes. Los pendientes quedan identificados y excluidos de los totales.</p></div><button class="button primary" id="download-excel">${icon('download')} Descargar Excel</button></div><div class="export-card">${icon('file')}<div><h3>Reporte de la selección · CSV</h3><p>${filtered().length} registros. Incluye el estado de revisión; los pendientes aparecen señalados.</p></div><button class="button" id="download-csv">${icon('download')} Exportar</button></div><div class="local-explanation">${icon('database')}<p>Las capturas permanecen en este perfil de navegador y en el dominio donde abras el panel. Otros usuarios o equipos tienen su propio almacenamiento. Limpiar los datos del sitio elimina la copia local.</p></div><hr><h3>Restaurar un respaldo</h3><p class="helper">Agrega registros nuevos sin sustituir los existentes. Podrás revisar la importación antes de guardarla.</p><label class="field"><span>Archivo JSON de Consumo v1</span><input type="file" id="backup-file" accept=".json,application/json" /></label><div id="import-error" class="form-errors" role="alert"></div><div id="import-preview"></div></div><div class="modal-footer"><span>Exporta periódicamente una copia.</span><button class="button primary" id="confirm-import" disabled>Restaurar capturas</button></div>`, true);
  $('#download-backup', el).onclick = () => download(JSON.stringify({ schemaVersion: 1, exportedAt: new Date().toISOString(), records }, null, 2), `consumo-respaldo-${new Date().toISOString().slice(0, 10)}.json`, 'application/json');
  $('#download-excel', el).onclick = () => exportExcel();
  $('#download-csv', el).onclick = () => action('csv');
  $('#backup-file', el).onchange = async event => {
    $('#import-preview', el).innerHTML = ''; $('#confirm-import', el).disabled = true;
    const file = event.target.files[0]; if (!file) return;
    try {
      if (file.size > 10 * 1024 * 1024) throw new Error('El respaldo supera 10 MB.');
      importCandidates = validateBackup(JSON.parse(await file.text()));
      $('#import-error', el).textContent = ''; previewCandidates(el);
    } catch (e) { $('#import-error', el).textContent = `No se pudo restaurar: ${e.message}`; }
  };
  $('#confirm-import', el).onclick = () => finishImport(el);
}

function applyAccess() {
  if (!serverMode) return;
  $$('[data-action="raw"]').forEach(el => el.remove());
  if (!canAdmin()) {
    $$('[data-action="import"], [data-action="backup"], [data-action="csv"], [data-action="excel"], [data-edit], .action-column').forEach(el => el.remove());
  }
  if (!canCapture()) $$('[data-action="new"]').forEach(el => el.remove());
  const notice = document.createElement('div'); notice.className = 'access-note';
  notice.textContent = `${auth.user.name} · ${roleNames[auth.user.role]} · ${auth.user.role === 'admin' ? 'Puedes administrar usuarios y corregir capturas.' : auth.user.role === 'capture' ? 'Puedes crear capturas. Las correcciones las realiza un administrador.' : 'Puedes consultar las gráficas e imprimir el reporte.'}`;
  $('.filters').before(notice);
}
function handleAccessError(error) {
  if (error.status === 401) showLogin('Tu sesión terminó. Inicia sesión de nuevo.');
  else toast(error.message, true);
}
async function refreshOfficial() {
  const state = await api('records');
  records = state.records; savedAt = state.savedAt; revision = state.revision;
  if (!period || !records.some(r => r.period === period)) period = [...new Set(records.map(r => r.period))].sort().at(-1) || '';
  render();
}
function showLogin(message = '') {
  cleanupHistoryPlots.forEach(cleanup => cleanup?.()); cleanupHistoryPlots = [];
  $('#dialog')?.remove(); records = []; savedAt = null; revision = 0; auth.user = null; auth.csrf = null;
  $('#app').innerHTML = `<section class="login-screen"><div class="login-card"><span class="login-mark">${icon('shield')}</span><span class="eyebrow">ARTRON · CONSUMO</span><h1>Inicia sesión</h1><p>Consulta y captura los consumos según tu permiso de acceso.</p><form id="login-form">${field('Usuario', 'username', '', 'autocomplete="username" required maxlength="64"')}${field('Contraseña', 'password', '', 'type="password" autocomplete="current-password" required maxlength="256"')}<div id="login-error" class="form-errors" role="alert">${esc(message)}</div><button class="button primary" type="submit">Entrar al panel ${icon('arrow')}</button></form><small>Las capturas oficiales se guardan en el servidor.</small></div></section>`;
  $('#login-form').onsubmit = async event => {
    event.preventDefault(); const button = $('button[type=submit]', event.target); button.disabled = true;
    const data = new FormData(event.target);
    try {
      Object.assign(auth, await api('login', { method: 'POST', data: { username: data.get('username'), password: data.get('password') } }));
      await refreshOfficial();
    } catch (e) { showLogin(e.message); }
    finally { button.disabled = false; }
  };
}
async function logout() {
  try { await api('logout', { method: 'POST', data: {} }); tab = 'dashboard'; period = ''; department = ''; search = ''; showLogin(); }
  catch (e) { handleAccessError(e); }
}
async function usersModal() {
  const { users } = await api('users');
  const el = modal('Usuarios y permisos', 'Define quién puede consultar, capturar o administrar los datos oficiales.', `<div class="modal-body"><div class="role-guide"><p><strong>Administrador</strong> · usuarios, importaciones, correcciones y eliminaciones.</p><p><strong>Capturista</strong> · nuevas capturas validadas. Solicita correcciones al administrador.</p><p><strong>Consulta</strong> · gráficas, filtros y reporte imprimible.</p></div><div class="table-wrap"><table><thead><tr><th>Usuario</th><th>Nombre</th><th>Permiso</th><th>Estado</th><th></th></tr></thead><tbody>${users.map(user => `<tr><td>${esc(user.username)}</td><td>${esc(user.name)}</td><td>${roleNames[user.role]}</td><td>${user.active ? 'Activo' : 'Desactivado'}</td><td><button class="button" data-user-edit="${esc(user.id)}">Editar acceso</button></td></tr>`).join('')}</tbody></table></div></div><div class="modal-footer"><span>Al cambiar un acceso se cierran sus sesiones.</span><button class="button primary" id="new-access-user">${icon('plus')} Nuevo usuario</button></div>`, true);
  $('#new-access-user', el).onclick = () => userModal();
  $$('[data-user-edit]', el).forEach(button => button.onclick = () => userModal(users.find(user => user.id === button.dataset.userEdit)));
}
function userModal(original) {
  const user = original || { role: 'viewer', active: true };
  const el = modal(original ? 'Editar acceso' : 'Nuevo usuario', 'Las contraseñas no se pueden consultar. Puedes restablecerlas cuando sea necesario.', `<form id="access-user-form"><div class="modal-body"><div class="form-grid">${field('Usuario *', 'username', user.username, `${original ? 'readonly' : 'required'} autocomplete="off" minlength="3" maxlength="64"`)}${field('Nombre *', 'name', user.name, 'required maxlength="120"')}<label class="field"><span>Permiso *</span><select name="role">${Object.entries(roleNames).map(([role, name]) => option(role, user.role, name)).join('')}</select></label>${field(original ? 'Nueva contraseña (opcional)' : 'Contraseña *', 'password', '', `type="password" autocomplete="new-password" minlength="12" maxlength="256" ${original ? '' : 'required'}`)}</div>${original ? `<label class="checkbox"><input name="active" type="checkbox" ${user.active ? 'checked' : ''}/> Usuario activo</label>` : ''}<p class="helper">Usa al menos 12 caracteres. Si cambias tu propio acceso tendrás que iniciar sesión otra vez.</p><div id="access-user-error" class="form-errors" role="alert"></div></div><div class="modal-footer"><span>Los cambios quedan registrados.</span><button type="submit" class="button primary">Guardar acceso</button></div></form>`);
  $('#access-user-form', el).onsubmit = async event => {
    event.preventDefault(); const button = $('button[type=submit]', event.target); button.disabled = true;
    const data = Object.fromEntries(new FormData(event.target));
    if (!data.password) delete data.password;
    if (original) data.active = Boolean($('[name=active]', el).checked);
    try {
      await api(original ? `users/${original.id}` : 'users', { method: original ? 'PATCH' : 'POST', data });
      if (original?.id === auth.user.id) showLogin('Acceso actualizado. Inicia sesión con tu contraseña actual.');
      else await usersModal();
    } catch (e) { if (e.status === 401) handleAccessError(e); else $('#access-user-error', el).textContent = e.message; }
    finally { button.disabled = false; }
  };
}
async function auditModal() {
  const { entries } = await api('audit');
  const labels = { 'record.create': 'Captura creada', 'record.update': 'Captura corregida', 'record.delete': 'Captura eliminada', 'user.create': 'Usuario creado', 'user.update': 'Acceso actualizado', 'session.login': 'Inicio de sesión' };
  modal('Registro de cambios', 'Últimos 200 eventos, registrados por el servidor.', `<div class="modal-body"><div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Referencia</th></tr></thead><tbody>${entries.map(entry => `<tr><td>${esc(new Date(entry.at).toLocaleString('es-MX', { timeZone: 'America/Matamoros' }))}</td><td>${esc(entry.actor_name)}</td><td>${esc(labels[entry.action] || entry.action)}</td><td>${esc(entry.target)}</td></tr>`).join('')}</tbody></table></div></div>`, true);
}

async function init() {
  if (serverMode) {
    try { Object.assign(auth, await api('session')); await refreshOfficial(); }
    catch (e) { showLogin(e.status === 401 ? '' : 'No se pudo conectar con el servidor. Reintenta en unos momentos.'); }
    return;
  }
  let stored = false;
  try {
    const store = loadStore();
    if (store) { records = store.records; savedAt = store.savedAt; stored = true; }
  } catch (e) { fatal = e.message; }
  if (!stored && !fatal) {
    try {
      // Optional private reference file generated locally; absent in a clean checkout.
      const embedded = document.getElementById('consumo-reference');
      const response = embedded ? new Response(embedded.textContent, { headers: { 'content-type': 'application/json' } }) : await fetch(`${import.meta.env.BASE_URL}reference.json`);
      if (response.ok && response.headers.get('content-type')?.includes('application/json')) {
        const data = await response.json(); const initial = validateBackup(data); savedAt = saveStore(initial); records = initial;
      }
    } catch { toast('La referencia inicial no está disponible. Puedes importar Excel o capturar manualmente.', true); }
  }
  period = [...new Set(records.map(r => r.period))].sort().at(-1) || '';
  render();
}
init();
