export const PRINT_KEY = 'artron.consumo.print.v1';
export function printSettings(value, ids, selected = ids.slice(0, 2)) {
  const known = list => Array.isArray(list) ? [...new Set(list)].filter(id => ids.includes(id)) : [];
  const order = [...new Set([...known(value?.order), ...known(selected), ...ids])];
  const visible = Array.isArray(value?.visible) ? known(value.visible) : known(selected);
  return {
    version: 1, orientation: value?.orientation === 'portrait' ? 'portrait' : 'landscape',
    mode: ['charts', 'tables', 'both'].includes(value?.mode) ? value.mode : 'charts',
    summary: value?.summary !== false, captures: value?.captures === true,
    title: typeof value?.title === 'string' ? value.title.slice(0, 120) : 'Reporte de consumo',
    order, visible,
    sizes: Object.fromEntries(ids.map(id => [id, {
      span: value?.sizes?.[id]?.span === 12 ? 12 : 6,
      height: Math.max(240, Math.min(500, Number(value?.sizes?.[id]?.height) || 320)),
      mode: ['charts', 'tables', 'both'].includes(value?.sizes?.[id]?.mode) ? value.sizes[id].mode : 'inherit',
    }])),
  };
}
export function movePrintItem(settings, id, target) {
  const order = [...settings.order], from = order.indexOf(id);
  if (from < 0) return settings;
  order.splice(from, 1); order.splice(Math.max(0, Math.min(order.length, target)), 0, id);
  return { ...settings, order };
}
