export const SERIES_COLORS = ['#2563eb', '#089bbf', '#7763d6', '#d9912d', '#5976a3', '#cc658e'];
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const format = value => new Intl.NumberFormat('es-MX', { maximumFractionDigits: 6 }).format(value);
const month = value => new Date(`${value}-02T12:00:00`).toLocaleDateString('es-MX', { month: 'short', year: '2-digit' });

export function drawHistory(container, data, options = {}) {
  if (!container) return;
  const paint = () => {
    const width = Math.max(280, container.clientWidth), height = Math.max(170, container.clientHeight);
    const margin = { top: 26, left: 48, bottom: 36, right: 22 };
    const plotW = width - margin.left - margin.right, plotH = height - margin.top - margin.bottom;
    const maximum = Math.max(...data.series.flatMap(s => s.points.map(p => p.value ?? 0)), 0);
    const rough = maximum ? maximum * 1.15 / 4 : 1;
    const power = Math.pow(10, Math.floor(Math.log10(rough)));
    const step = [1, 2, 2.5, 5, 10].map(n => n * power).find(n => n >= rough) || power * 10;
    const top = Math.max(step, Math.ceil(maximum * 1.15 / step) * step);
    const x = index => margin.left + (data.months.length === 1 ? plotW / 2 : plotW * index / Math.max(data.months.length - 1, 1));
    const y = value => margin.top + plotH - value / top * plotH;
    const stride = Math.max(1, Math.ceil(data.months.length / Math.max(2, Math.floor(plotW / 76))));
    const ticks = Array.from({ length: Math.round(top / step) + 1 }, (_, i) => `<g><line x1="${margin.left}" x2="${width - margin.right}" y1="${y(step * i)}" y2="${y(step * i)}" stroke="#e7edf1" stroke-dasharray="3 4"/><text x="${margin.left - 12}" y="${y(step * i) + 4}" text-anchor="end">${format(step * i)}</text></g>`).join('');
    const labels = data.months.map((m, i) => i % stride === 0 || i === data.months.length - 1 ? `<text x="${x(i)}" y="${height - 10}" text-anchor="middle">${escape(month(m))}</text>` : '').join('');
    const paths = data.series.map((series, colorIndex) => {
      let drawing = false;
      const path = series.points.map((p, i) => { if (p.value === null) { drawing = false; return ''; } const command = drawing ? 'L' : 'M'; drawing = true; return `${command}${x(i)},${y(p.value)}`; }).join(' ');
      return `<g data-series="${escape(series.id)}">${options.type === 'bars' ? '' : `<path d="${path}" fill="none" stroke="${SERIES_COLORS[colorIndex]}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>`}${series.points.map((p, i) => {
        if (p.value === null) return '';
        const partial = `${p.pending ? ` · ${p.pending} captura(s) pendiente(s) excluida(s)` : ''}${p.unlisted ? ` · ${p.unlisted} equipo(s) sin desglose de esta aplicación` : ''}`;
        const detail = `${series.name}${series.employee ? ' · #' + series.employee : ''} · ${month(p.period)}: ${format(p.value)} GB${partial}`;
        const attributes = `class="history-point" fill="${SERIES_COLORS[colorIndex]}" stroke="white" stroke-width="2" tabindex="0" role="img" aria-label="${escape(detail)}" data-detail="${escape(detail)}" data-value="${p.value}" data-period="${p.period}" data-user="${escape(series.id)}" data-x="${x(i)}" data-y="${y(p.value)}"`;
        const barWidth = Math.max(4, Math.min(56, plotW / Math.max(data.months.length, 1) * .55));
        return options.type === 'bars' && p.value > 0 ? `<rect ${attributes} x="${x(i) - barWidth / 2}" y="${y(p.value)}" width="${barWidth}" height="${plotH * p.value / top}" rx="5"><title>${escape(detail)}</title></rect>` : `<circle ${attributes} cx="${x(i)}" cy="${y(p.value)}" r="5"><title>${escape(detail)}</title></circle>`;
      }).join('')}</g>`;
    }).join('');
    container.innerHTML = `<svg viewBox="0 0 ${width} ${height}" width="100%" height="100%" role="group" aria-label="Histórico de consumo mensual en GB. Los meses sin lectura no tienen punto."><text x="${margin.left}" y="13" class="axis-unit">GB</text>${ticks}${labels}${paths}</svg><div class="chart-tooltip" role="status"></div>`;
    const tooltip = container.querySelector('.chart-tooltip');
    const hide = () => tooltip.classList.remove('visible');
    container.querySelectorAll('.history-point').forEach(point => {
      const show = () => {
        tooltip.textContent = point.dataset.detail; tooltip.classList.add('visible');
        tooltip.style.left = `${Math.min(Math.max(8, Number(point.dataset.x) - 100), Math.max(8, width - 290))}px`;
        tooltip.style.top = `${Math.max(5, Number(point.dataset.y) - 58)}px`;
      };
      point.addEventListener('pointerenter', show); point.addEventListener('focus', show);
      point.addEventListener('pointerleave', hide); point.addEventListener('blur', hide);
    });
  };
  const observer = new ResizeObserver(paint); observer.observe(container); paint();
  return () => observer.disconnect();
}
