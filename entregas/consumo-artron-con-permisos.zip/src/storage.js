import { validateBackup } from './domain.js';

export const STORAGE_KEY = 'artron.consumo.v1';
export function loadStore() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return null;
  const data = JSON.parse(raw);
  return { records: validateBackup(data), savedAt: data.savedAt || null };
}
export function saveStore(records) {
  const savedAt = new Date().toISOString();
  // Write before changing UI state: quota / permission failures must not appear saved.
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, savedAt, records }));
  return savedAt;
}
