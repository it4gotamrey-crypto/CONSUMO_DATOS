export const STATES = ['Nuevo', 'Bueno', 'Desgaste', 'Dañado', 'Reparado', 'Descompuesto', 'Disponible'];
export const DEVICE_TYPES = ['Móvil', 'Laptop', 'PC'];
export const APPS = ['WhatsApp', 'Facebook', 'Facebook Lite', 'Instagram', 'TikTok', 'Telegram', 'Chrome', 'YouTube', 'Spotify', 'GDE', 'Aplicaciones del sistema', 'Puntos de acceso / Hotspot', 'Aplicaciones eliminadas', 'Servicios de Google', 'Google Play Store', 'Actualización de software', 'Carrusel de fondos de pantalla'];
export const DEPARTMENTS = ['Ventas', 'Operaciones', 'Contabilidad', 'Compras', 'Almacén', 'RH', 'Obra eléctrica', 'Proyectos'];
export const HIGH_GB = 100;
export const round = n => Math.round((n + Number.EPSILON) * 1000000) / 1000000;
export const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase().replace(/\s+/g, ' ');
export const text = value => String(value ?? '').trim();

// Accept decimal separators, never silently treat thousands as decimals or remove text.
export function parseUsage(value, unit = 'GB') {
  if (!['GB', 'MB'].includes(unit)) throw new Error('Elige MB o GB según la unidad que muestra el dispositivo.');
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || value < 0 || value > 1000000000) throw new Error('El consumo debe ser un número positivo o cero, dentro de rango.');
    return round(unit === 'MB' ? value / 1000 : value);
  }
  const raw = text(value);
  if (!/^(?:\d+(?:[.,]\d{1,3})?|[.,]\d{1,3})$/.test(raw)) throw new Error('Usa un número con hasta 3 decimales, sin separadores de miles ni texto.');
  const number = Number(raw.replace(',', '.'));
  if (!Number.isFinite(number) || number > 1000000000) throw new Error('Consumo fuera de rango.');
  return round(unit === 'MB' ? number / 1000 : number);
}

export function canonicalApp(value) {
  const n = normalize(value);
  const aliases = {
    'whatsapp': 'WhatsApp', 'whats app': 'WhatsApp', 'facebook lite': 'Facebook Lite',
    'facebook lite ': 'Facebook Lite', 'facebook lit': 'Facebook Lite',
    'puntos de acceso moviles': 'Puntos de acceso / Hotspot', 'puntos de acceso / hotspot': 'Puntos de acceso / Hotspot',
    'app eliminadas': 'Aplicaciones eliminadas', 'aplicaciones eliminadas': 'Aplicaciones eliminadas',
    'actualizacion sofware': 'Actualización de software', 'actualizacion software': 'Actualización de software',
    'aplicaciones del sistema': 'Aplicaciones del sistema', 'servicios de google': 'Servicios de Google',
    'google play store': 'Google Play Store', 'tiktok': 'TikTok', 'carrusel de fondos de pantalla': 'Carrusel de fondos de pantalla',
  };
  return aliases[n] || APPS.find(app => normalize(app) === n) || text(value);
}

export function canonicalState(value) {
  return STATES.find(state => normalize(state) === normalize(value)) || text(value);
}

export function canonicalDeviceType(value) {
  const aliases = { movil: 'Móvil', celular: 'Móvil', telefono: 'Móvil', laptop: 'Laptop', portatil: 'Laptop', pc: 'PC', computadora: 'PC', 'computadora de escritorio': 'PC' };
  return aliases[normalize(value)] || '';
}

export function deviceLabel(record) {
  const details = [record.brand, record.model].filter(Boolean).join(' ') || record.deviceDescription || '';
  return canonicalDeviceType(record.device) ? [canonicalDeviceType(record.device), details].filter(Boolean).join(' · ') : record.device;
}

function identityTokens(record) {
  return [record.serial && `serial:${normalize(record.serial)}`, ...[record.imei1, record.imei2].filter(v => /^\d{15}$/.test(v || '')).map(v => `imei:${v}`)].filter(Boolean);
}

export function sameDevice(a, b) {
  const first = identityTokens(a), second = identityTokens(b);
  if (first.length || second.length) return first.some(token => second.includes(token));
  const typeA = canonicalDeviceType(a.device), typeB = canonicalDeviceType(b.device);
  if (typeA && typeB && typeA !== typeB) return false;
  const description = r => normalize([r.brand, r.model].filter(Boolean).join(' ') || r.deviceDescription || r.device);
  return normalize(a.employee) === normalize(b.employee) && description(a) === description(b);
}

export function deviceKey(record) {
  const imei = [record.imei1, record.imei2].filter(v => /^\d{15}$/.test(v || '')).sort()[0];
  return `${record.period}|${record.serial ? 'serial:' + normalize(record.serial) : imei ? 'imei:' + imei : 'employee:' + normalize(record.employee) + '|device:' + normalize([record.brand, record.model].filter(Boolean).join(' ') || record.deviceDescription || record.device)}`;
}

export function issuesFor(record, all = []) {
  const issues = [];
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(record.period || '')) issues.push('Falta un período mensual válido.');
  if (!text(record.user)) issues.push('Falta el nombre del usuario.');
  if (!text(record.employee)) issues.push('Falta el número de empleado.');
  if (!text(record.device)) issues.push('Falta el equipo.');
  if (!text(record.department)) issues.push('Falta el departamento.');
  if (!STATES.includes(record.status)) issues.push('Falta un estado válido del equipo.');
  for (const [field, label] of [['imei1', 'IMEI 1'], ['imei2', 'IMEI 2']]) if (text(record[field]) && !/^\d{15}$/.test(record[field])) issues.push(`${label} debe contener exactamente 15 dígitos, sin espacios ni guiones.`);
  if (record.imei1 && record.imei1 === record.imei2) issues.push('IMEI 1 e IMEI 2 deben ser diferentes.');
  const totalValid = typeof record.totalGb === 'number' && Number.isFinite(record.totalGb) && record.totalGb >= 0;
  if (!totalValid) issues.push('Falta una lectura válida del consumo total.');
  const apps = Array.isArray(record.apps) ? record.apps : [];
  const seen = new Set();
  for (const app of apps) {
    if (!text(app.name)) issues.push('Una aplicación no tiene nombre.');
    if (seen.has(normalize(app.name))) issues.push(`Aplicación repetida: ${app.name}.`);
    seen.add(normalize(app.name));
    if (typeof app.gb !== 'number' || !Number.isFinite(app.gb) || app.gb < 0) issues.push(`Consumo no válido en ${app.name || 'aplicación'}.`);
  }
  const appSum = round(apps.reduce((sum, app) => sum + (Number.isFinite(app.gb) ? app.gb : 0), 0));
  if (totalValid && appSum > record.totalGb + 0.001) issues.push(`Las aplicaciones suman ${appSum} GB y superan el total de ${record.totalGb} GB.`);
  if (totalValid && record.totalGb > HIGH_GB && !(record.reviewedHigh === true && text(record.reviewNote).length >= 10)) issues.push(`Consumo superior a ${HIGH_GB} GB: confirma la lectura con una nota de revisión.`);
  if (all.some(other => other.id !== record.id && other.period === record.period && sameDevice(other, record))) issues.push('Este equipo ya tiene una captura en el mismo mes (serie o IMEI coincidente).');
  const previous = all.filter(other => other.period < record.period && sameDevice(other, record) && typeof other.totalGb === 'number' && Number.isFinite(other.totalGb) && other.totalGb > 0).sort((a, b) => b.period.localeCompare(a.period))[0];
  if (totalValid && previous && record.totalGb > Math.max(5, previous.totalGb * 3) && !(record.reviewedHigh === true && text(record.reviewNote).length >= 10)) issues.push('El consumo supera 3 veces la lectura anterior: confirma con una nota de revisión.');
  if (Array.isArray(record.importErrors)) issues.push(...record.importErrors);
  return [...new Set(issues)];
}

export function summarize(records, all = records) {
  const valid = records.filter(record => issuesFor(record, all).length === 0);
  const group = (items, key, value) => {
    const result = new Map();
    for (const item of items) result.set(key(item), round((result.get(key(item)) || 0) + value(item)));
    return [...result].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  };
  const total = round(valid.reduce((sum, record) => sum + record.totalGb, 0));
  const applications = group(valid.flatMap(record => record.apps), app => app.name, app => app.gb);
  const identified = round(applications.reduce((sum, app) => sum + app.value, 0));
  return {
    valid, pending: records.filter(record => issuesFor(record, all).length > 0), total, identified,
    unattributed: round(Math.max(0, total - identified)),
    users: group(valid, record => `${record.user} · ${record.employee}`, record => record.totalGb),
    departments: group(valid, record => record.department, record => record.totalGb),
    applications, states: group(records, record => record.status || 'Sin estado', () => 1),
  };
}

export function rowsToRecords(rows, period, sheet, unit = '') {
  const headers = (rows[0] || []).map(normalize);
  const index = name => headers.indexOf(normalize(name));
  for (const name of ['NOMBRE', 'N. EMPLEADO', 'EQUIPO', 'TOTAL CONSUMO']) {
    if (index(name) < 0) throw new Error(`La hoja ${sheet} no tiene la columna ${name}. Selecciona una hoja de capturas.`);
  }
  const fields = { user: 'NOMBRE', employee: 'N. EMPLEADO', company: 'EMPRESA', site: 'SEDE', department: 'DEPARTAMENTO', position: 'PUESTO', device: 'EQUIPO', phone: 'NUMERO TEL', brand: 'MARCA', model: 'MODELO', serial: 'N. SERIE', status: 'ESTADO', comments: 'COMENTARIOS', mac: 'MAC', ip: 'IP' };
  return rows.slice(1).flatMap((row, i) => {
    if (!text(row[index('NOMBRE')])) return [];
    const record = { id: crypto.randomUUID(), period, apps: [], totalGb: null, importErrors: [], reviewNote: '', reviewedHigh: false };
    for (const [field, header] of Object.entries(fields)) record[field] = text(row[index(header)]);
    const getColumn = names => names.map(name => index(name)).find(i => i >= 0);
    record.imei1 = text(row[getColumn(['IMEI 1', 'IMEI1', 'IMEI'])]);
    record.imei2 = text(row[getColumn(['IMEI 2', 'IMEI2'])]);
    const typeIndex = getColumn(['TIPO EQUIPO', 'TIPO DE EQUIPO']);
    const explicitType = typeIndex !== undefined ? text(row[typeIndex]) : '';
    const canonical = canonicalDeviceType(explicitType || record.device);
    record.deviceDescription = canonical && record.device !== canonical && !canonicalDeviceType(record.device) ? record.device : '';
    if (canonical) record.device = canonical;
    if (explicitType && !canonical) record.importErrors.push(`Tipo de equipo «${explicitType}» no válido. Usa Móvil, Laptop o PC.`);
    record.status = canonicalState(record.status);
    record.department = DEPARTMENTS.find(d => normalize(d) === normalize(record.department)) || record.department;
    const read = (value, label, columnUnit) => {
      if (value === null || value === undefined || value === '') return null;
      const withUnit = typeof value === 'string' && value.trim().match(/^((?:\d+(?:[.,]\d{1,3})?|[.,]\d{1,3}))\s*(MB|GB)$/i);
      const actualUnit = withUnit ? withUnit[2].toUpperCase() : text(columnUnit || unit).toUpperCase();
      const amount = withUnit ? withUnit[1] : value;
      if (!['MB', 'GB'].includes(actualUnit)) { record.importErrors.push(`${label}: confirma la unidad del valor original «${text(value)}».`); return null; }
      try { return parseUsage(amount, actualUnit); } catch { record.importErrors.push(`${label}: valor original «${text(value)}» no válido.`); return null; }
    };
    for (let n = 1; n <= 3; n++) {
      const name = canonicalApp(row[index(`APP${n}`)]);
      const raw = row[index(`APP${n} CONSUMO`)];
      if (name || (raw !== null && raw !== undefined && raw !== '')) record.apps.push({ name, gb: read(raw, name || `APP${n}`, row[index(`APP${n} UNIDAD`)]) });
    }
    record.totalGb = read(row[index('TOTAL CONSUMO')], 'Total', row[index('TOTAL UNIDAD')]);
    const date = row[index('FECHA HORA')];
    record.source = { sheet, row: i + 2, capturedAt: date instanceof Date ? date.toISOString() : text(date), originalId: text(row[index('ID')]), unit, rawReadings: { total: text(row[index('TOTAL CONSUMO')]), apps: [1,2,3].map(n => ({ name: text(row[index(`APP${n}`)]), amount: text(row[index(`APP${n} CONSUMO`)]), unit: text(row[index(`APP${n} UNIDAD`)]) })) } };
    record.createdAt = new Date().toISOString(); record.updatedAt = record.createdAt;
    return [record];
  });
}

export function validateBackup(data) {
  if (!data || data.schemaVersion !== 1 || !Array.isArray(data.records) || data.records.length > 10000) throw new Error('Respaldo incompatible. Se requiere formato Consumo v1, hasta 10,000 registros.');
  const ids = new Set();
  const fields = ['id', 'period', 'user', 'employee', 'company', 'site', 'department', 'position', 'device', 'deviceDescription', 'phone', 'brand', 'model', 'serial', 'imei1', 'imei2', 'status', 'comments', 'mac', 'ip', 'reviewNote', 'createdAt', 'updatedAt'];
  return data.records.map(raw => {
    if (!raw || typeof raw !== 'object' || !raw.id || ids.has(raw.id) || !Array.isArray(raw.apps) || raw.apps.length > 100) throw new Error('El respaldo tiene registros o identificadores no válidos.');
    ids.add(raw.id);
    const result = {};
    for (const field of fields) {
      if (raw[field] != null && typeof raw[field] !== 'string') throw new Error(`Campo no válido: ${field}.`);
      result[field] = text(raw[field]).slice(0, 4000);
    }
    if (raw.totalGb !== null && (typeof raw.totalGb !== 'number' || !Number.isFinite(raw.totalGb) || raw.totalGb < 0)) throw new Error('Consumo total no válido en respaldo.');
    result.totalGb = raw.totalGb;
    result.apps = raw.apps.map(app => {
      if (!app || typeof app.name !== 'string' || (app.gb !== null && (typeof app.gb !== 'number' || !Number.isFinite(app.gb) || app.gb < 0))) throw new Error('Aplicación no válida en respaldo.');
      return { name: canonicalApp(app.name).slice(0, 200), gb: app.gb };
    });
    result.reviewedHigh = raw.reviewedHigh === true;
    result.importErrors = Array.isArray(raw.importErrors) ? raw.importErrors.map(e => text(e).slice(0, 500)) : [];
    if (raw.source && typeof raw.source === 'object') {
      result.source = { sheet: text(raw.source.sheet), row: text(raw.source.row), capturedAt: text(raw.source.capturedAt), originalId: text(raw.source.originalId), unit: text(raw.source.unit) };
      if (raw.source.rawReadings && typeof raw.source.rawReadings === 'object') result.source.rawReadings = { total: text(raw.source.rawReadings.total).slice(0, 200), apps: (Array.isArray(raw.source.rawReadings.apps) ? raw.source.rawReadings.apps : []).slice(0, 100).map(app => ({ name: text(app?.name).slice(0, 200), amount: text(app?.amount).slice(0, 200), unit: text(app?.unit).slice(0, 20) })) };
    }
    result.reviewHistory = (Array.isArray(raw.reviewHistory) ? raw.reviewHistory : []).slice(-30).map(entry => ({ at: text(entry?.at).slice(0, 100), note: text(entry?.note).slice(0, 2000), previousTotalGb: typeof entry?.previousTotalGb === 'number' && Number.isFinite(entry.previousTotalGb) ? entry.previousTotalGb : null }));
    return result;
  });
}

export function csvReport(records, all = records) {
  const columns = ['Período', 'Usuario', 'Empleado', 'Departamento', 'Equipo', 'Descripción original del equipo', 'Marca', 'Modelo', 'Serie', 'IMEI 1', 'IMEI 2', 'Estado', 'Total GB', 'Revisión', 'Aplicaciones (GB)'];
  const escape = value => {
    let str = String(value ?? '');
    if (/^[\s]*[=+@-]/.test(str)) str = "'" + str;
    return '"' + str.replaceAll('"', '""') + '"';
  };
  return '\ufeff' + [columns, ...records.map(r => [r.period, r.user, r.employee, r.department, r.device, r.deviceDescription, r.brand, r.model, r.serial, r.imei1, r.imei2, r.status, r.totalGb, issuesFor(r, all).join(' | ') || 'Validado', r.apps.map(a => `${a.name}: ${a.gb ?? 'sin lectura'}`).join(' | ')])].map(row => row.map(escape).join(',')).join('\r\n');
}
