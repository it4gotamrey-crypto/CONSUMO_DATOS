export const serverMode = document.querySelector('meta[name="consumo-mode"]')?.content === 'server';
export const auth = { user: null, csrf: null };
export const roleNames = { admin: 'Administrador', capture: 'Capturista', viewer: 'Consulta' };
export const canAdmin = () => !serverMode || auth.user?.role === 'admin';
export const canCapture = () => !serverMode || ['admin', 'capture'].includes(auth.user?.role);
export async function api(path, { method = 'GET', data } = {}) {
  const response = await fetch(new URL(`api/${path}`, document.baseURI), {
    method, credentials: 'same-origin', cache: 'no-store',
    headers: method === 'GET' ? {} : { 'Content-Type': 'application/json', 'X-CSRF-Token': auth.csrf || '' },
    ...(data !== undefined ? { body: JSON.stringify(data) } : {}),
  });
  const result = await response.json();
  if (!response.ok) { const error = new Error(result.error || 'No se pudo completar la operación.'); error.status = response.status; throw error; }
  return result;
}
