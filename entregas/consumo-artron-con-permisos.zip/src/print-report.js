import './print-report.css';
import { drawHistory, SERIES_COLORS } from './history-chart.js';
import { PRINT_KEY, printSettings, movePrintItem } from './print-settings.js';
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const number = value => new Intl.NumberFormat('es-MX', { maximumFractionDigits: 6 }).format(value);
const option = (value, selected, label) => `<option value="${value}" ${value === selected ? 'selected' : ''}>${label}</option>`;
export function openPrintDesigner(model) {
  if (document.getElementById('print-designer')) return;
  const ids = model.charts.map(c => c.id), byId = Object.fromEntries(model.charts.map(c => [c.id, c]));
  let saved; try { saved = JSON.parse(localStorage.getItem(PRINT_KEY)); } catch {}
  let settings = printSettings(saved, ids, model.selected), cleanups = [], scale = 1, closed = false;
  const focus = document.activeElement, app = document.getElementById('app'), appWasInert = app?.inert;
  if (app) app.inert = true;
  const root = document.createElement('section'); root.id = 'print-designer'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-label', 'Vista previa del reporte');
  root.innerHTML = `<div class="pd-top"><div><h2>Vista previa del reporte</h2><p id="pd-status" role="status">Acomoda el contenido antes de imprimir.</p></div><div class="pd-top-actions"><button class="button" data-print-close>Volver al panel</button><button class="button primary" data-print-confirm>Imprimir / Guardar PDF</button></div></div><aside class="pd-options"></aside><div class="pd-stage"><div class="pd-pages"></div></div>`;
  document.body.append(root); document.body.classList.add('pd-printing');
  const style = document.createElement('style'); style.id = 'pd-page-size'; root.append(style);
  const sidebar = root.querySelector('.pd-options'), stage = root.querySelector('.pd-stage'), pages = root.querySelector('.pd-pages');
  function remember() { try { localStorage.setItem(PRINT_KEY, JSON.stringify(settings)); } catch {} }
  function update(next) { settings = printSettings(next, ids, model.selected); remember(); render(); }
  function reorder(id, delta) {
    const shown = settings.order.filter(id => settings.visible.includes(id)), target = shown[shown.indexOf(id) + delta];
    if (target) update(movePrintItem(settings, id, settings.order.indexOf(target)));
  }
  function controls() {
    const scroll = sidebar.scrollTop;
    sidebar.innerHTML = `<label>Título del reporte<input data-pd-option="title" maxlength="120" value="${esc(settings.title)}"></label><label>Contenido<select data-pd-option="mode">${option('charts', settings.mode, 'Solo gráficas')}${option('tables', settings.mode, 'Solo tablas')}${option('both', settings.mode, 'Gráficas y tablas')}</select></label><label>Orientación<select data-pd-option="orientation">${option('landscape', settings.orientation, 'A4 horizontal')}${option('portrait', settings.orientation, 'A4 vertical')}</select></label><p class="pd-help">Al imprimir: elige el mismo tamaño A4 y orientación de esta vista, escala 100% y desactiva los encabezados y pies de página del navegador.</p><label class="pd-check"><input type="checkbox" data-pd-option="summary" ${settings.summary ? 'checked' : ''}> Incluir indicadores de resumen</label><label class="pd-check"><input type="checkbox" data-pd-option="captures" ${settings.captures ? 'checked' : ''}> Incluir tabla de capturas</label><h3>Qué mostrar</h3><div class="pd-move-buttons"><button class="button" data-pd-preset="current">Selección actual</button><button class="button" data-pd-preset="all">Todas</button></div>${settings.order.map(id => {
      const size = settings.sizes[id], checked = settings.visible.includes(id);
      return `<div class="pd-item-settings"><label><input type="checkbox" data-pd-select="${id}" ${checked ? 'checked' : ''}>${esc(byId[id].title)}</label>${checked ? `<div class="pd-size-options"><label>Mostrar<select data-pd-mode="${id}">${option('inherit', size.mode, 'Usar selección general')}${option('charts', size.mode, 'Solo gráfica')}${option('tables', size.mode, 'Solo tabla')}${option('both', size.mode, 'Gráfica y tabla')}</select></label><label>Ancho<select data-pd-width="${id}">${option('6', String(size.span), 'Mitad de página')}${option('12', String(size.span), 'Página completa')}</select></label><label>Alto de gráfica · ${size.height} px<input type="range" min="240" max="500" step="10" value="${size.height}" data-pd-height="${id}"></label><div class="pd-move-buttons"><button class="button" data-pd-move="${id}" data-step="-1" aria-label="Mover ${esc(byId[id].title)} antes">↑ Antes</button><button class="button" data-pd-move="${id}" data-step="1" aria-label="Mover ${esc(byId[id].title)} después">↓ Después</button></div></div>` : ''}</div>`;
    }).join('')}<p class="pd-help">También puedes arrastrar el asa de una gráfica para moverla y su esquina para ajustar el tamaño. Los ajustes se guardan en este navegador. Los filtros e intervalos se eligen en el panel antes de abrir esta vista.</p><div class="pd-error" role="alert"></div>`;
    sidebar.scrollTop = scroll;
    sidebar.querySelectorAll('[data-pd-option]').forEach(input => input.onchange = () => update({ ...settings, [input.dataset.pdOption]: input.type === 'checkbox' ? input.checked : input.value }));
    sidebar.querySelectorAll('[data-pd-select]').forEach(input => input.onchange = () => update({ ...settings, visible: input.checked ? [...settings.visible, input.dataset.pdSelect] : settings.visible.filter(id => id !== input.dataset.pdSelect) }));
    for (const [attr, prop, convert] of [['width', 'span', Number], ['height', 'height', Number], ['mode', 'mode', String]]) sidebar.querySelectorAll(`[data-pd-${attr}]`).forEach(input => input.onchange = () => {
      const id = input.dataset['pd' + attr[0].toUpperCase() + attr.slice(1)];
      update({ ...settings, sizes: { ...settings.sizes, [id]: { ...settings.sizes[id], [prop]: convert(input.value) } } });
    });
    sidebar.querySelectorAll('[data-pd-move]').forEach(button => button.onclick = () => reorder(button.dataset.pdMove, Number(button.dataset.step)));
    sidebar.querySelectorAll('[data-pd-preset]').forEach(button => button.onclick = () => update({ ...settings, visible: button.dataset.pdPreset === 'all' ? ids : model.selected }));
  }
  function card(id) {
    const chart = byId[id], size = settings.sizes[id], source = document.createElement('div'); source.innerHTML = chart.html;
    const body = source.querySelector('.report-chart-body');
    body.querySelectorAll('[id]').forEach(el => el.removeAttribute('id'));
    body.querySelectorAll('.history-controls,.history-scope,.history-summaries,.history-details,.chart-tooltip,button').forEach(el => el.remove());
    const el = document.createElement('article'); el.className = 'pd-chart'; el.dataset.reportId = id;
    el.style.setProperty('--pd-span', size.span); el.style.setProperty('--pd-card-height', size.height + 'px');
    el.innerHTML = `<h3>${esc(chart.title)}</h3><div class="pd-tools"><button class="pd-grip" aria-label="Arrastrar ${esc(chart.title)}">⠿</button><button data-pd-before aria-label="Mover antes">↑</button><button data-pd-after aria-label="Mover después">↓</button></div><div class="pd-chart-body">${!chart.history && chart.badge ? `<p class="pd-chart-caption">${esc(chart.badge)}</p>` : ''}${body.innerHTML}</div>${chart.history ? `<div class="pd-series">${chart.history.series.map((s, i) => `<span><i style="background:${SERIES_COLORS[i]}"></i>${esc(s.name)}${s.employee ? ' · #' + esc(s.employee) : ''}${s.last ? ' · ' + number(s.last.value) + ' GB' : ''}</span>`).join('')}</div>` : ''}<button class="pd-resize" aria-label="Cambiar tamaño de ${esc(chart.title)}">↘</button>`;
    el.querySelector('[data-pd-before]').onclick = () => reorder(id, -1); el.querySelector('[data-pd-after]').onclick = () => reorder(id, 1);
    bindPointer(el, id); return el;
  }
  function bindPointer(el, id) {
    const grip = el.querySelector('.pd-grip'), resize = el.querySelector('.pd-resize');
    grip.onkeydown = event => { if (['ArrowUp', 'ArrowDown'].includes(event.key)) { event.preventDefault(); reorder(id, event.key === 'ArrowUp' ? -1 : 1); } };
    resize.onkeydown = event => {
      if (!['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault(); const next = { ...settings.sizes[id] };
      if (event.key.includes('Up') || event.key.includes('Down')) next.height += event.key === 'ArrowDown' ? 10 : -10;
      else next.span = event.key === 'ArrowRight' ? 12 : 6;
      update({ ...settings, sizes: { ...settings.sizes, [id]: next } });
    };
    for (const [handle, kind] of [[grip, 'move'], [resize, 'resize']]) handle.onpointerdown = event => {
      if (event.button !== 0) return; event.preventDefault(); handle.setPointerCapture(event.pointerId);
      const startX = event.clientX, startY = event.clientY, initial = { ...settings.sizes[id] }; let target = null, moved = false, size = { ...initial };
      const move = e => {
        if (Math.hypot(e.clientX - startX, e.clientY - startY) < 5) return; moved = true;
        if (kind === 'move') {
          target?.classList.remove('pd-drop');
          target = document.elementsFromPoint(e.clientX, e.clientY).map(node => node.closest?.('.pd-chart')).find(node => node && node !== el) || null;
          target?.classList.add('pd-drop');
        } else {
          size.height = Math.max(240, Math.min(500, Math.round((initial.height + (e.clientY - startY) / scale) / 10) * 10));
          const pageWidth = el.closest('.pd-page-body').clientWidth;
          size.span = el.clientWidth + (e.clientX - startX) / scale > pageWidth * .72 ? 12 : 6;
          el.style.setProperty('--pd-card-height', size.height + 'px');
        }
      };
      const finish = e => {
        handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', finish); handle.removeEventListener('pointercancel', finish); target?.classList.remove('pd-drop');
        if (moved && e.type !== 'pointercancel') {
          if (kind === 'move' && target) update(movePrintItem(settings, id, settings.order.indexOf(target.dataset.reportId)));
          if (kind === 'resize') update({ ...settings, sizes: { ...settings.sizes, [id]: size } });
        } else if (kind === 'resize') el.style.setProperty('--pd-card-height', initial.height + 'px');
      };
      handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', finish); handle.addEventListener('pointercancel', finish);
    };
  }
  function renderPages() {
    cleanups.forEach(fn => fn()); cleanups = []; pages.replaceChildren();
    const landscape = settings.orientation === 'landscape', width = landscape ? '297mm' : '210mm', height = landscape ? '210mm' : '297mm';
    root.style.setProperty('--pd-width', width); root.style.setProperty('--pd-height', height);
    style.textContent = `@media print { @page { size: A4 ${settings.orientation}; margin: 0; } }`;
    let page, used = 0;
    function newPage() {
      const wrap = document.createElement('div'); wrap.className = 'pd-paper-wrap';
      const sheet = document.createElement('section'); sheet.className = 'pd-sheet';
      sheet.innerHTML = `<header class="pd-page-header"><p>ARTRON · CONTROL DE CONSUMO</p><h1>${esc(settings.title || 'Reporte de consumo')}</h1><p>${esc(model.context)}</p><small>${esc(model.note)}</small></header><div class="pd-page-body"></div><footer class="pd-page-footer"><span>1 GB = 1,000 MB · Pendientes excluidos del consumo validado</span><span class="pd-page-number"></span></footer>`;
      wrap.append(sheet); pages.append(wrap); page = sheet.querySelector('.pd-page-body'); used = 0; return page;
    }
    newPage();
    function append(node) {
      page.append(node); const height = node.offsetHeight;
      if (used && used + 10 + height > page.clientHeight + 1) { node.remove(); newPage(); page.append(node); }
      used += (used ? 10 : 0) + height;
    }
    if (settings.summary) {
      const summary = document.createElement('div'); summary.className = 'pd-summary';
      summary.innerHTML = `<div><span>Consumo validado</span><strong>${model.summary.valid.length ? number(model.summary.total) + ' GB' : 'Sin lectura'}</strong><small>${model.summary.valid.length} capturas validadas</small></div><div><span>Capturas seleccionadas</span><strong>${model.rowCount}</strong></div><div><span>Pendientes excluidos</span><strong>${model.summary.pending.length}</strong></div>`;
      append(summary);
    }
    function addTable(title, data) {
      if (!data) return;
      let index = 0, continued = false;
      const rows = data.rows.length ? data.rows : [data.headers.map((_, i) => i === 0 ? 'Sin lecturas para esta selección' : '')];
      while (index < rows.length) {
        const block = document.createElement('section'); block.className = 'pd-table-block';
        block.innerHTML = `<h3>${esc(title)}${continued ? ' · continuación' : ''}</h3><table class="pd-table"><thead><tr>${data.headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody></tbody></table>`;
        page.append(block); const tbody = block.querySelector('tbody'); let count = 0;
        while (index < rows.length) {
          const row = document.createElement('tr'); row.innerHTML = rows[index].map(value => `<td>${esc(value === null || value === undefined ? 'Sin lectura' : value)}</td>`).join(''); tbody.append(row);
          const candidate = (used ? used + 10 : 0) + block.offsetHeight;
          if (candidate > page.clientHeight + 1 && (used || count)) { row.remove(); break; }
          count++; index++;
        }
        if (!count) { block.remove(); newPage(); continue; }
        used += (used ? 10 : 0) + block.offsetHeight;
        if (index < rows.length) { continued = true; newPage(); }
      }
    }
    let pendingRow = [], rowTables = [];
    const flush = () => {
      if (pendingRow.length) { const row = document.createElement('div'); row.className = 'pd-chart-row'; pendingRow.forEach(id => row.append(card(id))); append(row); pendingRow = []; }
      for (const id of rowTables) addTable(byId[id].title, byId[id].table); rowTables = [];
    };
    for (const id of settings.order.filter(id => settings.visible.includes(id))) {
      const mode = settings.sizes[id].mode === 'inherit' ? settings.mode : settings.sizes[id].mode;
      if (mode === 'tables') { flush(); addTable(byId[id].title, byId[id].table); continue; }
      const span = settings.sizes[id].span;
      if (pendingRow.length && (span === 12 || settings.sizes[pendingRow[0]].span === 12)) flush();
      pendingRow.push(id); if (mode === 'both') rowTables.push(id);
      if (span === 12 || pendingRow.length === 2) flush();
    }
    flush(); if (settings.captures) addTable('Detalle de capturas', model.captures);
    root.querySelectorAll('.pd-page-number').forEach((el, i, all) => el.textContent = `Página ${i + 1} de ${all.length}`);
    for (const container of pages.querySelectorAll('.pd-chart .history-plot')) {
      const chart = byId[container.closest('.pd-chart').dataset.reportId];
      if (chart.history) cleanups.push(drawHistory(container, chart.history, chart.id === 'period-total' ? { type: 'bars' } : {}));
    }
    const count = pages.children.length; root.querySelector('#pd-status').textContent = `${count} página${count === 1 ? '' : 's'} · ${settings.orientation === 'landscape' ? 'A4 horizontal' : 'A4 vertical'} · Arrastra o usa los controles para acomodar.`;
    const empty = !settings.visible.length && !settings.captures && !settings.summary;
    root.querySelector('[data-print-confirm]').disabled = empty;
    sidebar.querySelector('.pd-error').textContent = empty ? 'Elige al menos una gráfica, tabla o el resumen.' : '';
    zoom();
  }
  function zoom() {
    const sheet = pages.querySelector('.pd-sheet'); if (!sheet) return;
    scale = Math.min(1, Math.max(.16, (stage.clientWidth - 48) / sheet.offsetWidth));
    for (const wrap of pages.children) { wrap.style.width = sheet.offsetWidth * scale + 'px'; wrap.style.height = sheet.offsetHeight * scale + 'px'; wrap.firstElementChild.style.transform = `scale(${scale})`; }
  }
  function render() { const scroll = stage.scrollTop; controls(); renderPages(); stage.scrollTop = scroll; }
  function close() {
    if (closed) return; closed = true; cleanups.forEach(fn => fn()); observer.disconnect(); root.remove(); if (app) app.inert = appWasInert; document.body.classList.remove('pd-printing'); document.removeEventListener('keydown', keys); focus?.focus();
  }
  const keys = event => { if (event.key === 'Escape') close(); };
  document.addEventListener('keydown', keys);
  root.querySelector('[data-print-close]').onclick = close;
  root.querySelector('[data-print-confirm]').onclick = async () => {
    await document.fonts.ready; await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))); window.print();
  };
  const observer = new ResizeObserver(zoom); observer.observe(stage);
  render(); root.querySelector('[data-print-confirm]').focus();
  return { close };
}
