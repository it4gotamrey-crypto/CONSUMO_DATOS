export const LAYOUT_KEY = 'artron.consumo.layout.v1';
export const HISTORY_KEY = 'artron.consumo.history.v1';
export const ANALYTICS_KEY = 'artron.consumo.analytics.v1';
export const CHART_IDS = ['history', 'applications', 'users', 'departments', 'states', 'period-total', 'app-history'];
export const DEFAULT_VISIBLE = ['period-total', 'app-history'];
export const isHistoricalChart = id => ['history', 'period-total', 'app-history'].includes(id);
export const defaultHeight = id => ['period-total', 'app-history'].includes(id) ? 680 : id === 'history' ? 580 : ['departments', 'states'].includes(id) ? 560 : 480;
export const minimumHeight = id => isHistoricalChart(id) ? 500 : 320;
export const limitHeight = (id, height) => Math.max(minimumHeight(id), Math.min(840, Number(height) || minimumHeight(id)));

export function normalizeLayout(value) {
  const ordered = Array.isArray(value?.order) ? value.order.filter(id => CHART_IDS.includes(id)) : [];
  const order = [...new Set([...ordered, ...CHART_IDS])];
  const sizes = Object.fromEntries(CHART_IDS.map(id => [id, { span: value?.sizes?.[id]?.span === 12 ? 12 : value?.sizes?.[id]?.span === 6 ? 6 : id === 'history' ? 12 : 6, height: limitHeight(id, value?.sizes?.[id]?.height || defaultHeight(id)) }]));
  const selected = Array.isArray(value?.visible) ? [...new Set(value.visible)].filter(id => CHART_IDS.includes(id)) : DEFAULT_VISIBLE;
  return { version: 1, order, sizes, visible: selected.length ? [...selected] : [...DEFAULT_VISIBLE] };
}
export function moveChart(layout, id, targetIndex) {
  const next = normalizeLayout(layout), oldIndex = next.order.indexOf(id);
  if (oldIndex < 0) return next;
  next.order.splice(oldIndex, 1);
  next.order.splice(Math.max(0, Math.min(next.order.length, targetIndex)), 0, id);
  return next;
}
export function loadLayout() {
  try { return normalizeLayout(JSON.parse(localStorage.getItem(LAYOUT_KEY))); } catch { return normalizeLayout(); }
}
export function loadHistoryPreferences() {
  try {
    const raw = JSON.parse(localStorage.getItem(HISTORY_KEY));
    return { from: /^\d{4}-(0[1-9]|1[0-2])$/.test(raw?.from) ? raw.from : '', to: /^\d{4}-(0[1-9]|1[0-2])$/.test(raw?.to) ? raw.to : '', metric: typeof raw?.metric === 'string' ? raw.metric.slice(0, 200) : 'total', users: Array.isArray(raw?.users) ? raw.users.filter(id => typeof id === 'string').slice(0, 6) : null };
  } catch { return { from: '', to: '', metric: 'total', users: null }; }
}

export function loadAnalyticsPreferences() {
  try {
    const raw = JSON.parse(localStorage.getItem(ANALYTICS_KEY));
    const clean = value => ({ from: /^\d{4}-(0[1-9]|1[0-2])$/.test(value?.from) ? value.from : '', to: /^\d{4}-(0[1-9]|1[0-2])$/.test(value?.to) ? value.to : '' });
    return { total: clean(raw?.total), apps: { ...clean(raw?.apps), apps: Array.isArray(raw?.apps?.apps) ? raw.apps.apps.filter(n => typeof n === 'string').slice(0, 6) : null } };
  } catch { return { total: { from: '', to: '' }, apps: { from: '', to: '', apps: null } }; }
}

// Each handle supports mouse/touch; equivalent buttons and selects support keyboard input.
export function bindReportEditor(grid, layout, onChange) {
  if (!grid) return;
  grid.querySelectorAll('[data-move]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.move;
    const shown = layout.order.filter(chart => layout.visible.includes(chart));
    const target = shown[shown.indexOf(id) + Number(button.dataset.step)];
    if (target) onChange(moveChart(layout, id, layout.order.indexOf(target)));
  }));
  grid.querySelectorAll('[data-width]').forEach(select => select.addEventListener('change', () => {
    const next = normalizeLayout(layout); next.sizes[select.dataset.width].span = Number(select.value); onChange(next);
  }));
  grid.querySelectorAll('[data-height]').forEach(select => select.addEventListener('change', () => {
    const next = normalizeLayout(layout); next.sizes[select.dataset.height].height = limitHeight(select.dataset.height, select.value); onChange(next);
  }));
  grid.querySelectorAll('.drag-handle').forEach(handle => handle.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    event.preventDefault();
    const card = handle.closest('[data-chart]'), id = card.dataset.chart;
    const startX = event.clientX, startY = event.clientY;
    let target = null, ghost = null, scrollFrame, pointerX = event.clientX, pointerY = event.clientY;
    handle.setPointerCapture(event.pointerId);
    const findTarget = () => {
      const hovered = document.elementFromPoint(pointerX, pointerY)?.closest('[data-chart]');
      target?.classList.remove('drop-target');
      target = hovered && hovered !== card && grid.contains(hovered) ? hovered : null;
      target?.classList.add('drop-target');
    };
    const scroll = () => {
      const delta = pointerY > innerHeight - 65 ? 12 : pointerY < 65 ? -12 : 0;
      if (delta) { window.scrollBy(0, delta); findTarget(); }
      scrollFrame = requestAnimationFrame(scroll);
    };
    const move = e => {
      if (!ghost && Math.hypot(e.clientX - startX, e.clientY - startY) < 5) return;
      if (!ghost) {
        ghost = document.createElement('div'); ghost.className = 'drag-ghost'; ghost.textContent = card.querySelector('h2').textContent;
        document.body.append(ghost); card.classList.add('dragging');
        scrollFrame = requestAnimationFrame(scroll);
      }
      pointerX = e.clientX; pointerY = e.clientY;
      ghost.style.left = `${e.clientX + 15}px`; ghost.style.top = `${e.clientY + 15}px`;
      findTarget();
    };
    const finish = e => {
      handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', finish); handle.removeEventListener('pointercancel', finish);
      cancelAnimationFrame(scrollFrame);
      ghost?.remove(); card.classList.remove('dragging'); target?.classList.remove('drop-target');
      if (e.type !== 'pointercancel' && target && ghost) onChange(moveChart(layout, id, layout.order.indexOf(target.dataset.chart)));
    };
    handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', finish); handle.addEventListener('pointercancel', finish);
  }));
  grid.querySelectorAll('.resize-handle').forEach(handle => {
    const card = handle.closest('[data-chart]'), id = card.dataset.chart;
    handle.addEventListener('keydown', event => {
      if (!['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault(); const next = normalizeLayout(layout);
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') next.sizes[id].span = event.key === 'ArrowRight' ? 12 : 6;
      else next.sizes[id].height = limitHeight(id, next.sizes[id].height + (event.key === 'ArrowDown' ? 32 : -32));
      onChange(next);
    });
    handle.addEventListener('pointerdown', event => {
      if (event.button !== 0) return;
      event.preventDefault(); handle.setPointerCapture(event.pointerId);
      const startX = event.clientX, startY = event.clientY, bounds = card.getBoundingClientRect(), next = normalizeLayout(layout);
      card.classList.add('resizing');
      const move = e => {
        const height = limitHeight(id, Math.round(bounds.height + e.clientY - startY));
        const span = matchMedia('(min-width: 981px)').matches ? bounds.width + e.clientX - startX > grid.clientWidth * .72 ? 12 : 6 : layout.sizes[id].span;
        next.sizes[id] = { span, height }; card.style.setProperty('--chart-span', span); card.style.setProperty('--chart-height', `${height}px`);
      };
      const finish = e => {
        handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', finish); handle.removeEventListener('pointercancel', finish);
        card.classList.remove('resizing'); onChange(e.type === 'pointercancel' ? layout : next);
      };
      handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', finish); handle.addEventListener('pointercancel', finish);
    });
  });
}
