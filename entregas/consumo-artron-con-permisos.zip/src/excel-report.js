import writeExcelFile from 'write-excel-file/universal';
import { issuesFor, summarize, round } from './domain.js';

function table(sheet, headers, rows, widths = []) {
  return {
    sheet, stickyRowsCount: 1,
    columns: headers.map((header, index) => ({ width: widths[index] || Math.min(38, Math.max(18, header.length + 3)) })),
    data: [headers.map(value => ({ value, type: String, fontWeight: 'bold', textColor: '#ffffff', backgroundColor: '#2563eb', wrap: true, height: 32 })),
      ...rows.map(row => row.map((value, index) => {
        if (value === null || value === undefined) return { value: null };
        if (typeof value === 'number') return { value, type: Number, ...(headers[index]?.includes('(GB)') ? { format: '0.000###' } : {}) };
        const text = String(value);
        if (text.length > 32767) throw new Error('Una celda supera el límite de texto de Excel. Reduce las notas de esa captura.');
        // Explicit text cells keep IMEI/employee zeroes and never execute user text as formulas.
        return { value: text, type: String, format: '@', wrap: true, alignVertical: 'top' };
      }))],
  };
}

export function reportSheets(rows, all = rows, filters = {}) {
  const summary = summarize(rows, all);
  const checked = rows.map(record => ({ record, issues: issuesFor(record, all) }));
  const total = summary.valid.length ? summary.total : null;
  const users = new Map();
  for (const r of summary.valid) {
    const key = JSON.stringify([r.user, r.employee]);
    const group = users.get(key) || { user: r.user, employee: r.employee, gb: 0, readings: 0 };
    group.gb = round(group.gb + r.totalGb); group.readings++; users.set(key, group);
  }
  const periods = [...new Set(rows.map(r => r.period))].sort();
  return [
    table('Resumen', ['Concepto', 'Valor'], [
      ['Período seleccionado', filters.period || 'Todos los períodos'],
      ['Departamento seleccionado', filters.department || 'Todos los departamentos'],
      ['Búsqueda aplicada', filters.search || 'Sin búsqueda'],
      ['Capturas exportadas', rows.length], ['Capturas validadas', summary.valid.length],
      ['Capturas pendientes', summary.pending.length], ['Consumo total validado (GB)', total],
      ['Consumo identificado por apps (GB)', summary.valid.length ? summary.identified : null],
      ['Consumo sin desglose (GB)', summary.valid.length ? summary.unattributed : null],
      ['Unidad', '1 GB = 1,000 MB. Todos los consumos del archivo están normalizados a GB.'],
      ['Datos pendientes', 'Se conservan en Capturas y Detalle apps; se excluyen de los totales validados y los resúmenes.'],
      ['Datos faltantes', 'Una celda vacía significa sin lectura; cero es un consumo explícito de cero. Las apps ausentes no se consideran consumo cero.'],
      ['Desglose', 'Las aplicaciones forman parte del total del dispositivo: no deben sumarse otra vez al consumo total.'],
      ['Alcance', 'Exporta los datos de la selección actual de período, departamento y búsqueda. La elección de gráficas solo afecta la pantalla y la impresión.'],
    ], [42, 100]),
    table('Capturas', ['Período', 'Usuario', 'Empleado', 'Departamento', 'Equipo', 'Descripción original', 'Marca', 'Modelo', 'Serie', 'IMEI 1', 'IMEI 2', 'Teléfono', 'Estado equipo', 'Consumo capturado (GB)', 'Consumo validado (GB)', 'Revisión', 'Motivos de revisión', 'Comentarios', 'Nota de revisión', 'Origen hoja', 'Origen fila'],
      checked.map(({ record: r, issues }) => [r.period, r.user, r.employee, r.department, r.device, r.deviceDescription, r.brand, r.model, r.serial, r.imei1, r.imei2, r.phone, r.status, r.totalGb, issues.length ? null : r.totalGb, issues.length ? 'Pendiente' : 'Validado', issues.join(' | '), r.comments, r.reviewNote, r.source?.sheet, r.source?.row]),
      [16, 32, 18, 22, 20, 30, 18, 22, 25, 23, 23, 20, 18, 24, 24, 18, 60, 45, 45, 20, 18]),
    table('Detalle apps', ['Período', 'Usuario', 'Empleado', 'Departamento', 'Serie', 'Aplicación', 'Consumo capturado (GB)', 'Consumo validado (GB)', 'Revisión captura'],
      checked.flatMap(({ record: r, issues }) => r.apps.map(app => [r.period, r.user, r.employee, r.department, r.serial, app.name, app.gb, issues.length ? null : app.gb, issues.length ? 'Pendiente' : 'Validado'])),
      [16, 32, 18, 22, 25, 36, 24, 24, 22]),
    table('Por aplicación', ['Aplicación', 'Consumo validado (GB)'], summary.applications.map(app => [app.name, app.value]), [40, 26]),
    table('Por usuario', ['Usuario', 'Empleado', 'Consumo validado (GB)', 'Capturas validadas'], [...users.values()].sort((a, b) => b.gb - a.gb).map(user => [user.user, user.employee, user.gb, user.readings]), [36, 20, 26, 24]),
    table('Por departamento', ['Departamento', 'Consumo validado (GB)'], summary.departments.map(department => [department.name, department.value]), [32, 26]),
    table('Por período', ['Período', 'Consumo validado (GB)', 'Capturas validadas', 'Capturas pendientes'], periods.map(period => {
      const result = summarize(rows.filter(r => r.period === period), all);
      return [period, result.valid.length ? result.total : null, result.valid.length, result.pending.length];
    }), [18, 26, 24, 24]),
    table('Estado equipos', ['Estado equipo', 'Capturas (incluye pendientes)'], summary.states.map(state => [state.name, state.value]), [28, 35]),
  ];
}

export async function excelReport(rows, all = rows, filters = {}) {
  return writeExcelFile(reportSheets(rows, all, filters), { fontFamily: 'Calibri', fontSize: 11 }).toBlob();
}
