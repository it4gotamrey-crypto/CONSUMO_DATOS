import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { STORAGE_KEY } from '../src/storage.js';
import { LAYOUT_KEY, HISTORY_KEY } from '../src/report-layout.js';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:5173';
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
const errors = [];
await mkdir('test-results', { recursive: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
await context.addInitScript(key => { if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify({ visible: ['history', 'applications', 'users', 'departments', 'states'] })); }, LAYOUT_KEY);
const page = await context.newPage(); page.on('pageerror', e => errors.push(e.message));
const order = () => page.locator('[data-chart]').evaluateAll(cards => cards.map(c => c.dataset.chart));
const layout = () => page.evaluate(key => JSON.parse(localStorage.getItem(key)), LAYOUT_KEY);
try {
  await page.goto(base); await page.waitForSelector('[data-chart=history]');
  assert.equal(await page.locator('[data-chart]').count(), 5);
  const originalData = await page.evaluate(key => localStorage.getItem(key), STORAGE_KEY);
  if (originalData) {
    assert.equal(await page.locator('.history-point').count(), 3);
    assert.match(await page.locator('.single-month-note').textContent(), /Solo hay un mes/);
    assert.equal(await page.locator('#history-plot path').evaluateAll(paths => paths.every(p => !p.getAttribute('d').includes('L'))), true, 'Julio solo tiene puntos, no tendencias inventadas');
  }
  await page.locator('[data-action=edit-layout]').click();
  await page.locator('[data-width=applications]').selectOption('12');
  await page.locator('[data-height=applications]').selectOption('680');
  assert.equal((await layout()).sizes.applications.span, 12);
  assert.equal((await layout()).sizes.applications.height, 680);
  await page.locator('[data-move=applications][data-step="-1"]').click();
  assert.equal((await order())[0], 'applications');
  await page.reload(); await page.waitForSelector('[data-chart=history]');
  assert.equal((await order())[0], 'applications');
  assert.equal(Math.round((await page.locator('[data-chart=applications]').boundingBox()).height), 680);
  await page.locator('[data-action=edit-layout]').click();
  await page.locator('[data-action=reset-layout]').click();
  // Place two half-width charts together at the top, then reorder with an actual pointer drag.
  await page.locator('[data-move=applications][data-step="-1"]').click();
  await page.locator('[data-move=users][data-step="-1"]').click();
  await page.locator('[data-chart=applications]').scrollIntoViewIfNeeded();
  await page.evaluate(() => window.scrollBy(0, -180));
  const a = await page.locator('[data-chart=applications] .drag-handle').boundingBox();
  const b = await page.locator('[data-chart=users] .card-title').boundingBox();
  await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2); await page.mouse.down();
  await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2, { steps: 15 }); await page.mouse.up();
  assert.deepEqual((await order()).slice(0, 2), ['users', 'applications']);
  // Resize with the actual bottom-right corner, then use the same handle with keyboard arrows.
  const card = page.locator('[data-chart=applications]');
  await card.locator('.resize-handle').scrollIntoViewIfNeeded();
  const handle = await card.locator('.resize-handle').boundingBox();
  const before = (await layout()).sizes.applications.height;
  await page.mouse.move(handle.x + 12, handle.y + 12); await page.mouse.down();
  await page.mouse.move(handle.x + 12, handle.y + 92, { steps: 12 }); await page.mouse.up();
  assert.equal((await layout()).sizes.applications.height, before + 80);
  await card.locator('.resize-handle').focus(); await page.keyboard.press('ArrowRight');
  assert.equal((await layout()).sizes.applications.span, 12);
  await page.keyboard.press('ArrowDown');
  assert.equal((await layout()).sizes.applications.height, before + 112, 'El foco se conserva para ajustes repetidos con teclado');
  const chosenOrder = await order();
  assert.equal(await page.evaluate(key => localStorage.getItem(key), STORAGE_KEY), originalData, 'Modificar el reporte nunca modifica las capturas');
  await page.emulateMedia({ media: 'print' });
  assert.equal(await page.locator('.drag-handle').first().isVisible(), false);
  assert.equal(await page.locator('.history-controls').isVisible(), false);
  assert.deepEqual(await order(), chosenOrder);
  await page.pdf({ path: 'test-results/reporte-personalizado.pdf', format: 'A4', landscape: true, printBackground: true });
  await page.emulateMedia({ media: 'screen' });
  await page.locator('[data-print-close]').click();
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  assert.equal(Math.round((await card.boundingBox()).width) < 390, true);

  // Isolated fictional records exercise multi-month curves without changing the JULIO seed.
  const sample = await browser.newContext({ viewport: { width: 1440, height: 1080 } });
  await sample.addInitScript(key => { if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify({ visible: ['history'] })); }, LAYOUT_KEY);
  const history = await sample.newPage(); history.on('pageerror', e => errors.push(e.message));
  await history.route('**/reference.json', route => route.fulfill({ status: 404 }));
  await history.goto(base); await history.waitForSelector('.metrics');
  const fixture = [];
  const names = ['Andrea Demo', 'Bruno Demo', 'Carla Demo'];
  const values = [[2, 3.2, 4.4, null, 6.2], [1.2, 2.7, 1.8, 2.1, 3.4], [0.8, 1.4, 2.5, 3.9, 4.7]];
  for (let user = 0; user < 3; user++) for (let month = 0; month < 5; month++) {
    const period = `2026-${String(month + 6).padStart(2, '0')}`, total = values[user][month];
    fixture.push({ id: `DEMO-${user}-${month}`, employee: `DEMO-${user + 1}`, user: names[user], period, totalGb: total, apps: user === 1 && month === 3 ? [] : [{ name: 'WhatsApp', gb: total === null ? null : Math.round(total * 600) / 1000 }], department: 'Operaciones', device: 'Dispositivo ficticio', serial: `DEMO-SERIE-${user}`, status: 'Bueno' });
  }
  await history.evaluate(({ records, storageKey, historyKey }) => {
    localStorage.setItem(storageKey, JSON.stringify({ schemaVersion: 1, records, savedAt: '2026-10-13T00:00:00Z' }));
    localStorage.setItem(historyKey, JSON.stringify({ from: '2026-06', to: '2026-10', metric: 'total', users: ['demo-1', 'demo-2', 'demo-3'] }));
  }, { records: fixture, storageKey: STORAGE_KEY, historyKey: HISTORY_KEY });
  await history.reload(); await history.waitForSelector('.history-point');
  assert.equal(await history.locator('.history-point').count(), 14);
  assert.equal(await history.locator('[data-series="demo-1"] path').evaluate(path => (path.getAttribute('d').match(/M/g) || []).length), 2, 'No une una línea a través de un mes sin lectura');
  await history.locator('.history-point').first().hover(); assert.equal(await history.locator('.chart-tooltip.visible').count(), 1);
  await history.locator('#history-metric').selectOption('WhatsApp');
  assert.equal(await history.locator('.history-point').count(), 13, 'Aplicación no registrada se queda sin punto');
  await history.locator('#history-metric').selectOption('total');
  await history.locator('[data-action=compare-users]').click();
  await history.locator('[name=compare-user][value="demo-3"]').uncheck();
  await history.locator('#compare-users-form button[type=submit]').click();
  assert.equal(await history.locator('#history-plot [data-series]').count(), 2);
  await history.reload(); await history.waitForSelector('.history-point');
  assert.equal(await history.locator('#history-plot [data-series]').count(), 2);
  await history.locator('#history-from').fill('2026-08'); await history.locator('#history-from').dispatchEvent('change');
  assert.equal(await history.locator('[data-user="demo-1"]').count(), 2);
  await history.locator('#history-from').fill('2026-11'); await history.locator('#history-from').dispatchEvent('change');
  assert.match(await history.locator('[data-chart=history] .form-errors').textContent(), /inicial/);
  await history.locator('#history-from').fill('2026-06'); await history.locator('#history-from').dispatchEvent('change');
  await history.locator('[data-action=compare-users]').click();
  await history.locator('[name=compare-user][value="demo-3"]').check(); await history.locator('#compare-users-form button[type=submit]').click();
  await history.locator('[data-chart=history]').evaluate(card => card.querySelector('.eyebrow').textContent = 'DEMOSTRACIÓN · DATOS FICTICIOS');
  await history.locator('[data-chart=history]').screenshot({ path: 'test-results/historico-demostracion.png' });
  await history.emulateMedia({ media: 'print' });
  await history.pdf({ path: 'test-results/historico-demostracion.pdf', format: 'A4', landscape: true, printBackground: true });
  assert.deepEqual(errors, []);
  console.log('OK: selección, arrastre, ancho, altura, teclado, persistencia, integridad de capturas, impresión, móvil, usuarios, curvas históricas, huecos, unidades, tooltip y filtros de fechas.');
  await sample.close();
} finally { await browser.close(); }
