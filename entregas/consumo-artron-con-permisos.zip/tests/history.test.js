import test from 'node:test';
import assert from 'node:assert/strict';
import { buildHistory, calendarMonths } from '../src/history.js';
import { moveChart, normalizeLayout, limitHeight, CHART_IDS } from '../src/report-layout.js';

const record = (id, period, employee, totalGb, overrides = {}) => ({ id, period, employee, user: `Usuario ${employee}`, device: 'Teléfono', serial: `SERIE-${employee}`, department: 'Operaciones', status: 'Bueno', apps: [], totalGb, ...overrides });

test('histórico suma equipos por empleado y conserva identidad cuando cambia la escritura del nombre', () => {
  const records = [record('1', '2026-06', '001', 1), record('2', '2026-07', '001', 2, { user: 'Nombre actualizado' }), record('3', '2026-07', '001', 0.5, { serial: 'SEGUNDA-SERIE' }), record('4', '2026-07', '002', 3)];
  const h = buildHistory(records, { users: ['001', '002'] });
  assert.deepEqual(h.months, ['2026-06', '2026-07']);
  assert.deepEqual(h.series[0].points.map(p => p.value), [1, 2.5]);
  assert.equal(h.series[0].name, 'Usuario 001');
  assert.equal(h.series[0].change, 1.5);
  assert.equal(h.series[1].points[0].value, null);
});

test('meses ausentes no se convierten en ceros y una lectura cero sí es un punto real', () => {
  const h = buildHistory([record('1', '2026-06', '1', 1), record('2', '2026-08', '1', 0)], { users: ['1'] });
  assert.deepEqual(h.months, ['2026-06', '2026-07', '2026-08']);
  assert.deepEqual(h.series[0].points.map(p => p.value), [1, null, 0]);
  assert.equal(h.series[0].change, -1);
});

test('pendientes se excluyen y se señalan al comparar múltiples equipos', () => {
  const h = buildHistory([record('1', '2026-07', '1', 2), record('2', '2026-07', '1', null, { serial: 'OTHER' }), record('3', '2026-08', '1', 0.1, { apps: [{ name: 'WhatsApp', gb: 10 }] })], { users: ['1'] });
  assert.equal(h.pendingCount, 2);
  assert.equal(h.series[0].points[0].value, 2);
  assert.equal(h.series[0].points[0].pending, 1);
  assert.equal(h.series[0].points[1].value, null);
});

test('una aplicación no registrada es desconocida, no cero', () => {
  const h = buildHistory([record('1', '2026-06', '1', 1, { apps: [{ name: 'WhatsApp', gb: 0.825 }] }), record('2', '2026-07', '1', 2), record('3', '2026-08', '1', 1, { apps: [{ name: 'WhatsApp', gb: 0 }] })], { users: ['1'], metric: 'WhatsApp' });
  assert.deepEqual(h.series[0].points.map(p => p.value), [0.825, null, 0]);
  assert.equal(h.series[0].points[1].unlisted, 1);
});

test('selección explícita, intervalo, búsqueda y departamento filtran el histórico', () => {
  const rows = [record('1', '2026-06', '1', 1), record('2', '2026-07', '1', 2), record('3', '2026-07', '2', 3, { department: 'Ventas' })];
  assert.equal(buildHistory(rows, { from: '2026-07', to: '2026-07', department: 'Operaciones' }).series.length, 1);
  assert.equal(buildHistory(rows, { users: [] }).series.length, 0);
  assert.equal(buildHistory(rows, { query: 'usuario 2' }).series[0].id, '2');
  assert.throws(() => calendarMonths('2026-08', '2026-07'), /inicial/);
  assert.throws(() => calendarMonths('2000-01', '2026-07'), /120/);
});

test('un solo mes no inventa tendencia ni cambio', () => {
  const h = buildHistory([record('1', '2026-07', '1', 1)]);
  assert.equal(h.series[0].points.length, 1);
  assert.equal(h.series[0].change, null);
});

test('distribución inválida se normaliza sin perder ninguna gráfica', () => {
  const layout = normalizeLayout({ order: ['states', 'states', 'invented'], sizes: { history: { span: 100, height: Infinity }, users: { span: 12, height: 1 } } });
  assert.equal(layout.order.length, CHART_IDS.length); assert.deepEqual(new Set(layout.order), new Set(CHART_IDS));
  assert.equal(layout.sizes.history.span, 12); assert.equal(layout.sizes.history.height, 840);
  assert.equal(layout.sizes.users.height, 320); assert.equal(limitHeight('history', 100), 500);
});

test('mover gráficos conserva tamaños y no modifica la configuración anterior', () => {
  const original = normalizeLayout(); const moved = moveChart(original, 'history', CHART_IDS.length - 1);
  assert.equal(moved.order.at(-1), 'history'); assert.equal(original.order[0], 'history');
  assert.deepEqual(moved.sizes, original.sizes);
});
