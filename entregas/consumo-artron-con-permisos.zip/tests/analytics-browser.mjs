import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { STORAGE_KEY } from '../src/storage.js';
import { LAYOUT_KEY, ANALYTICS_KEY } from '../src/report-layout.js';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:5173';
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
const context = await browser.newContext({ locale: 'es-MX', viewport: { width: 1440, height: 1120 } });
const page = await context.newPage(), errors = [];
page.on('pageerror', e => errors.push(e.message));
await mkdir('test-results', { recursive: true });
const shown = () => page.locator('[data-chart]').evaluateAll(cards => cards.map(card => card.dataset.chart));
async function choose(ids) {
  await page.locator('[data-action=choose-charts]').click();
  for (const input of await page.locator('[name=chart-choice]').all()) await input.setChecked(ids.includes(await input.getAttribute('value')));
  await page.locator('#choose-charts-form button[type=submit]').click();
  await page.waitForSelector('#dialog', { state: 'detached' });
}
try {
  await page.goto(base); await page.waitForSelector('[data-chart=period-total]');
  assert.deepEqual(await shown(), ['period-total', 'app-history']);
  const original = await page.evaluate(key => localStorage.getItem(key), STORAGE_KEY);
  if (original) assert.equal(await page.locator('#period-total-plot .history-point').first().getAttribute('data-value'), '169.346');
  await page.locator('[data-visibility=one]').click(); assert.deepEqual(await shown(), ['period-total']);
  const cardWidth = (await page.locator('[data-chart=period-total]').boundingBox()).width;
  const gridWidth = (await page.locator('#report-grid').boundingBox()).width; assert.ok(Math.abs(cardWidth - gridWidth) < 3);
  await page.locator('[data-visibility=all]').click(); assert.equal((await shown()).length, 7);
  await choose(['history', 'app-history']); assert.deepEqual(await shown(), ['history', 'app-history']);
  await page.reload(); await page.waitForSelector('[data-chart=history]'); assert.deepEqual(await shown(), ['history', 'app-history']);
  assert.equal(await page.evaluate(key => localStorage.getItem(key), STORAGE_KEY), original);
  await page.evaluate(() => {
    window.printCalls = [];
    window.print = () => window.printCalls.push({
      charts: [...document.querySelectorAll('[data-chart]')].map(card => card.dataset.chart),
      plotsReady: [...document.querySelectorAll('.history-plot')].every(plot => plot.querySelector('svg') || plot.textContent.trim()),
      editing: document.querySelector('#report-grid').classList.contains('editing'),
    });
  });
  await page.locator('[data-action=edit-layout]').click();
  await page.locator('.report-toolbar [data-action=print]').click();
  await page.waitForFunction(() => window.printCalls.length === 1);
  assert.deepEqual(await page.evaluate(() => window.printCalls[0]), { charts: ['history', 'app-history'], plotsReady: true, editing: false });
  await page.locator('nav [data-action=records]').click();
  await page.locator('.heading-actions [data-action=print]').click();
  await page.waitForFunction(() => window.printCalls.length === 2);
  assert.deepEqual(await shown(), ['history', 'app-history']);
  assert.equal(await page.evaluate(key => localStorage.getItem(key), STORAGE_KEY), original);
  await page.emulateMedia({ media: 'print' }); assert.equal(await page.locator('.chart-visibility-bar').isVisible(), false);
  assert.equal(await page.locator('[data-chart=period-total]').count(), 0); assert.deepEqual(await shown(), ['history', 'app-history']);
  await page.pdf({ path: 'test-results/reporte-dos-graficas.pdf', format: 'A4', landscape: true, printBackground: true });
  await page.emulateMedia({ media: 'screen' }); await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  // A custom choice cannot accidentally hide everything.
  await page.locator('[data-action=choose-charts]').click();
  for (const input of await page.locator('[name=chart-choice]').all()) await input.uncheck();
  await page.locator('#choose-charts-form button[type=submit]').click(); assert.match(await page.locator('#chart-choice-error').textContent(), /al menos una/);
  await page.locator('[data-close]').click();

  const sampleContext = await browser.newContext({ locale: 'es-MX', viewport: { width: 1440, height: 1100 } });
  const sample = await sampleContext.newPage(); sample.on('pageerror', e => errors.push(e.message));
  await sample.route('**/reference.json', r => r.fulfill({ status: 404 }));
  await sample.goto(base); await sample.waitForSelector('.metrics');
  const r = (id, period, employee, totalGb, apps) => ({ id, period, employee, user: `Usuario ficticio ${employee}`, device: 'Móvil', serial: `DEMO-SERIE-${employee}`, department: 'Operaciones', status: 'Bueno', totalGb, apps });
  const data = [
    r('1', '2026-06', 'DEMO-1', 2, [{ name: 'WhatsApp', gb: .825 }, { name: 'Facebook', gb: .4 }]),
    r('2', '2026-06', 'DEMO-2', 3, [{ name: 'WhatsApp', gb: 1 }, { name: 'Facebook', gb: .9 }]),
    r('3', '2026-07', 'DEMO-1', 1, [{ name: 'WhatsApp', gb: .3 }]),
    r('4', '2026-07', 'DEMO-2', 4, [{ name: 'Facebook', gb: 2 }]),
    r('5', '2026-08', 'DEMO-1', 0, [{ name: 'WhatsApp', gb: 0 }]),
    r('6', '2026-08', 'DEMO-2', null, [{ name: 'Facebook', gb: null }]),
  ];
  await sample.evaluate(({ data, key }) => localStorage.setItem(key, JSON.stringify({ schemaVersion: 1, records: data, savedAt: '2026-10-13T00:00:00Z' })), { data, key: STORAGE_KEY });
  await sample.reload(); await sample.waitForSelector('#period-total-plot .history-point');
  assert.deepEqual(await sample.locator('#period-total-plot .history-point').evaluateAll(points => points.map(p => Number(p.dataset.value))), [5, 5, 0]);
  await sample.locator('[data-aggregate=total][data-field=to]').fill('2026-09'); await sample.locator('[data-aggregate=total][data-field=to]').dispatchEvent('change');
  assert.equal(await sample.locator('#period-total-plot [data-period="2026-09"]').count(), 0);
  await sample.locator('[data-action=compare-apps]').click();
  await sample.locator('[name=compare-app][value=Facebook]').uncheck(); await sample.locator('#compare-apps-form button[type=submit]').click();
  assert.deepEqual(await sample.locator('#app-history-plot .history-point').evaluateAll(points => points.map(p => Number(p.dataset.value))), [1.825, .3, 0]);
  await sample.reload(); await sample.waitForSelector('#app-history-plot .history-point');
  assert.equal(await sample.locator('#app-history-plot [data-series]').count(), 1);
  assert.deepEqual(await sample.evaluate(key => JSON.parse(localStorage.getItem(key)).apps.apps, ANALYTICS_KEY), ['WhatsApp']);
  await sample.locator('[data-action=compare-apps]').click(); await sample.locator('[name=compare-app][value=Facebook]').check();
  await sample.locator('#compare-apps-form button[type=submit]').click();
  assert.equal(await sample.locator('#app-history-plot [data-user=Facebook][data-period="2026-08"]').count(), 0);
  await sample.locator('#app-history-plot [data-user=Facebook]').first().hover(); assert.equal(await sample.locator('#app-history-plot .chart-tooltip.visible').count(), 1);
  await sample.locator('[data-aggregate=apps][data-field=from]').fill('2026-07'); await sample.locator('[data-aggregate=apps][data-field=from]').dispatchEvent('change');
  assert.deepEqual(await sample.locator('#app-history-plot [data-user=WhatsApp]').evaluateAll(points => points.map(p => Number(p.dataset.value))), [.3, 0]);
  await sample.locator('[data-aggregate=apps][data-field=from]').fill('2026-06'); await sample.locator('[data-aggregate=apps][data-field=from]').dispatchEvent('change');
  // Demonstration screenshot is explicitly labelled, kept separate from the real JULIO seed.
  await sample.locator('[data-chart]').evaluateAll(cards => cards.forEach(card => card.querySelector('.eyebrow').textContent = 'DEMOSTRACIÓN · DATOS FICTICIOS'));
  await sample.locator('#report-grid').screenshot({ path: 'test-results/analytics-demostracion.png' });
  const fixtureBefore = await sample.evaluate(key => localStorage.getItem(key), STORAGE_KEY);
  await sample.locator('[data-action=edit-layout]').click();
  await sample.locator('[data-move=period-total][data-step="1"]').click();
  assert.deepEqual(await sample.locator('[data-chart]').evaluateAll(cards => cards.map(c => c.dataset.chart)), ['app-history', 'period-total']);
  assert.equal(await sample.evaluate(key => localStorage.getItem(key), STORAGE_KEY), fixtureBefore);
  assert.deepEqual(await sample.evaluate(key => JSON.parse(localStorage.getItem(key)).visible, LAYOUT_KEY), ['period-total', 'app-history']);
  assert.deepEqual(errors, []);
  console.log('OK: una/dos/todas, selección personalizada, persistencia, móvil, PDF, total mensual sin doble conteo, apps agregadas entre usuarios, filtros, ausencia frente a cero, pendientes, selección de apps y reordenación con gráficas ocultas.');
  await sampleContext.close();
} finally { await browser.close(); }
