import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir, readFile } from 'node:fs/promises';
import { STORAGE_KEY } from '../src/storage.js';
import { validateBackup } from '../src/domain.js';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:4185/consumo-descargable/';
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
await mkdir('test-results', { recursive: true });
const errors = [];
const fixture = validateBackup({ schemaVersion: 1, records: [{ id: 'demo-export', period: '2026-07', employee: 'DEMO-1', user: 'Demostración descarga', device: 'Móvil', serial: 'SERIE-DEMO', department: 'Operaciones', status: 'Bueno', totalGb: .825, apps: [{ name: 'WhatsApp', gb: .825 }], comments: '</script><script>window.unwanted=true</script>' }] });
try {
  for (const entry of ['web/', 'consumo-local.html']) {
    const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1440, height: 1100 } });
    const page = await context.newPage(); page.on('pageerror', e => errors.push(e.message));
    await page.goto(new URL(entry, base).href); await page.waitForSelector('.metrics');
    await page.evaluate(({ key, records }) => localStorage.setItem(key, JSON.stringify({ schemaVersion: 1, records, savedAt: '2026-10-13T00:00:00Z' })), { key: STORAGE_KEY, records: fixture });
    await page.reload(); await page.waitForSelector('#period-total-plot .history-point');
    if (entry.endsWith('.html')) await context.setOffline(true);
    await page.locator('.heading-actions [data-action=save-panel]').click();
    const manualHtml = await page.locator('#panel-html').inputValue();
    await page.evaluate(() => Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: () => Promise.reject(new Error('Blocked by host')) } }));
    await page.locator('#copy-panel-html').click();
    await page.waitForFunction(() => document.querySelector('#panel-copy-status').textContent.includes('Ctrl+C'));
    assert.equal(await page.locator('#panel-html').evaluate(el => el.selectionEnd - el.selectionStart), manualHtml.length);
    const pending = page.waitForEvent('download');
    await page.locator('#save-panel-download').click();
    const downloaded = await pending;
    assert.equal(downloaded.suggestedFilename(), 'consumo-local.html');
    const path = `test-results/download-${entry === 'web/' ? 'web' : 'local'}.html`;
    await downloaded.saveAs(path); const html = await readFile(path, 'utf8');
    assert.equal(html, manualHtml);
    assert.ok(html.startsWith('<!doctype html>'));
    assert.ok(html.includes('\\u003c/script>'));
    const fresh = await browser.newContext({ acceptDownloads: true });
    const reopened = await fresh.newPage(); reopened.on('pageerror', e => errors.push(e.message));
    const roundtrip = new URL('roundtrip-export.html', base).href;
    await reopened.route(roundtrip, route => route.fulfill({ contentType: 'text/html', body: html }));
    await reopened.goto(roundtrip); await reopened.waitForSelector('#period-total-plot .history-point');
    assert.equal(await reopened.locator('#period-total-plot .history-point').first().getAttribute('data-value'), '0.825');
    assert.deepEqual(await reopened.evaluate(key => JSON.parse(localStorage.getItem(key)).records, STORAGE_KEY), fixture);
    assert.equal(await reopened.evaluate(() => window.unwanted), undefined);
    assert.equal(await reopened.locator('script[src], link[rel=stylesheet]').count(), 0);
    await fresh.setOffline(true);
    const again = reopened.waitForEvent('download');
    await reopened.locator('[data-action=backup]').first().click();
    await reopened.locator('#download-panel').click();
    await reopened.locator('#save-panel-download').click();
    assert.equal((await again).suggestedFilename(), 'consumo-local.html');
    await reopened.locator('[data-close]').click();
    await reopened.setViewportSize({ width: 390, height: 844 });
    assert.equal(await reopened.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
    await fresh.close(); await context.close();
  }
  assert.deepEqual(errors, []);
  console.log('OK: descarga desde versión web y HTML sin conexión, archivo autónomo, capturas actuales incluidas, reapertura en navegador nuevo, notas seguras y móvil sin desbordamiento.');
} finally { await browser.close(); }
