import test from 'node:test';
import assert from 'node:assert/strict';
import { DEVICE_TYPES, canonicalDeviceType, deviceLabel, sameDevice, issuesFor, summarize, validateBackup, rowsToRecords, csvReport } from '../src/domain.js';

const base = { id: 'device-1', period: '2026-07', user: 'Usuario de prueba', employee: 'TEST-01', device: 'Móvil', brand: 'Marca de prueba', model: 'Modelo de prueba', serial: 'SERIE-01', imei1: '012345678901234', imei2: '012345678901235', status: 'Bueno', department: 'Operaciones', totalGb: 1.23, apps: [{ name: 'WhatsApp', gb: 0.825 }] };

test('tipos admitidos y descripción del equipo', () => {
  assert.deepEqual(DEVICE_TYPES, ['Móvil', 'Laptop', 'PC']);
  assert.equal(canonicalDeviceType('MOVIL'), 'Móvil');
  assert.equal(canonicalDeviceType('celular'), 'Móvil');
  assert.equal(canonicalDeviceType('portátil'), 'Laptop');
  assert.equal(canonicalDeviceType('Redmi 9T'), '');
  assert.equal(deviceLabel(base), 'Móvil · Marca de prueba Modelo de prueba');
});
test('cero, uno o dos IMEI; un equipo con dos IMEI no duplica el consumo', () => {
  assert.equal(issuesFor(base).length, 0);
  assert.equal(issuesFor({ ...base, imei2: '' }).length, 0);
  assert.equal(issuesFor({ ...base, device: 'PC', imei1: '', imei2: '' }).length, 0);
  const summary = summarize([base]);
  assert.equal(summary.valid.length, 1);
  assert.equal(summary.total, 1.23);
});
test('rechaza formato incorrecto y los dos IMEI idénticos', () => {
  assert.ok(issuesFor({ ...base, imei1: '1234567890' }).some(i => i.includes('15 dígitos')));
  assert.ok(issuesFor({ ...base, imei1: '01234567890123A' }).some(i => i.includes('15 dígitos')));
  assert.ok(issuesFor({ ...base, imei2: base.imei1 }).some(i => i.includes('diferentes')));
});
test('duplicados se detectan por cualquier IMEI, incluso al intercambiar las ranuras', () => {
  const other = { ...base, id: 'device-2', serial: 'OTRA-SERIE', imei1: base.imei2, imei2: '' };
  assert.equal(sameDevice(base, other), true);
  assert.ok(issuesFor(other, [base]).some(i => i.includes('mismo mes')));
  assert.equal(issuesFor({ ...other, period: '2026-08' }, [base]).length, 0);
  assert.equal(sameDevice(base, { ...other, imei1: '012345678901236' }), false);
});
test('equipos sin identificadores de tipos distintos no se confunden', () => {
  const a = { ...base, serial: '', imei1: '', imei2: '', device: 'Laptop' };
  assert.equal(sameDevice(a, { ...a, device: 'PC' }), false);
});
test('respaldo mantiene serie, IMEI, ceros iniciales y descripción original', () => {
  const [restored] = validateBackup({ schemaVersion: 1, records: [{ ...base, deviceDescription: 'Nombre antiguo' }] });
  assert.equal(restored.serial, 'SERIE-01');
  assert.equal(restored.imei1, '012345678901234');
  assert.equal(restored.imei2, '012345678901235');
  assert.equal(restored.deviceDescription, 'Nombre antiguo');
});
test('capturas anteriores se conservan y sus series numéricas no se reinterpretan como IMEI', () => {
  const [old] = validateBackup({ schemaVersion: 1, records: [{ ...base, device: 'Redmi 9T', serial: '012345678901234', imei1: undefined, imei2: undefined }] });
  assert.equal(old.device, 'Redmi 9T');
  assert.equal(old.serial, '012345678901234');
  assert.equal(old.imei1, '');
  assert.equal(old.imei2, '');
  assert.equal(issuesFor(old).length, 0);
});
test('Excel importa tipo e IMEI separados y conserva el nombre anterior', () => {
  const headers = ['NOMBRE', 'N. EMPLEADO', 'EQUIPO', 'TIPO DE EQUIPO', 'N. SERIE', 'IMEI1', 'IMEI2', 'DEPARTAMENTO', 'ESTADO', 'TOTAL CONSUMO'];
  const [r] = rowsToRecords([headers, ['Prueba', 'T1', 'Galaxy A07', 'Móvil', 'SERIE-X1', base.imei1, base.imei2, 'Operaciones', 'BUENO', 1.23]], '2026-07', 'CAPTURAS', 'GB');
  assert.equal(r.device, 'Móvil'); assert.equal(r.deviceDescription, 'Galaxy A07');
  assert.equal(r.serial, 'SERIE-X1'); assert.equal(r.imei1, base.imei1); assert.equal(r.imei2, base.imei2);
  assert.equal(issuesFor(r).length, 0);
  const csv = csvReport([r]);
  assert.ok(csv.includes('"IMEI 1","IMEI 2"'));
  assert.ok(csv.includes(base.imei2)); assert.ok(csv.includes('Galaxy A07'));
});
