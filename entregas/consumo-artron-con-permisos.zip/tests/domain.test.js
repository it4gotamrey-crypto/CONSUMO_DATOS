import test from 'node:test';
import assert from 'node:assert/strict';
import { parseUsage, issuesFor, summarize, rowsToRecords, validateBackup, csvReport, deviceKey } from '../src/domain.js';

const record = (overrides = {}) => ({ id: 'test1', period: '2026-07', employee: '001', user: 'Usuario de prueba', device: 'Equipo de prueba', serial: 'SERIE-1', department: 'Operaciones', status: 'Bueno', totalGb: 1.23, apps: [{ name: 'WhatsApp', gb: 0.825 }], ...overrides });

test('825 MB es 0.825 GB, 1.23 GB permanece 1.23; conserva precisión de MB', () => {
  assert.equal(parseUsage('825', 'MB'), 0.825);
  assert.equal(parseUsage('1.23', 'GB'), 1.23);
  assert.equal(parseUsage('1,23', 'GB'), 1.23);
  assert.equal(parseUsage('.825', 'GB'), 0.825);
  assert.equal(parseUsage('1.23', 'MB'), 0.00123);
  assert.equal(parseUsage('0', 'MB'), 0);
});

test('exige unidad y rechaza negativos, texto, exponentes y separadores ambiguos', () => {
  for (const value of ['-2', '1,234.56', '825 MB', '1e3', '', '1.2345', '2.4B', Infinity, NaN]) assert.throws(() => parseUsage(value, 'GB'));
  assert.throws(() => parseUsage('825', ''));
});

test('excluye captura inconsistente sin modificarla; desglose parcial no duplica consumo', () => {
  const good = record(), bad = record({ id: 'bad', serial: 'OTHER', totalGb: 0.8 });
  const summary = summarize([good, bad]);
  assert.equal(summary.total, 1.23);
  assert.equal(summary.identified, 0.825);
  assert.equal(summary.unattributed, 0.405);
  assert.equal(summary.valid.length, 1);
  assert.equal(summary.pending.length, 1);
  assert.equal(bad.totalGb, 0.8);
});

test('rechaza duplicados de equipo y mes; mismo equipo en otro mes sí es válido', () => {
  const original = record();
  assert.ok(issuesFor(record({ id: 'new' }), [original]).some(i => i.includes('mismo mes')));
  assert.equal(issuesFor(record({ id: 'new', period: '2026-08' }), [original]).length, 0);
  assert.equal(deviceKey(record({ serial: '', device: ' Redmi 9T ' })), deviceKey(record({ serial: '', device: 'redmi 9t' })));
});

test('valores altos y aumentos extraordinarios requieren revisión explícita', () => {
  const high = record({ totalGb: 825 });
  assert.ok(issuesFor(high).some(i => i.includes('100 GB')));
  assert.equal(issuesFor({ ...high, reviewedHigh: true, reviewNote: 'Lectura verificada en el dispositivo.' }).length, 0);
  const previous = record({ id: 'previous', period: '2026-06', totalGb: 1 });
  assert.ok(issuesFor(record({ totalGb: 10 }), [previous]).some(i => i.includes('3 veces')));
});

test('faltantes y apps duplicadas no producen indicadores falsos', () => {
  assert.ok(issuesFor(record({ totalGb: null })).length);
  assert.ok(issuesFor(record({ apps: [{ name: 'WhatsApp', gb: 0.2 }, { name: 'whatsapp', gb: 0.1 }] })).some(i => i.includes('repetida')));
  assert.equal(summarize([record({ totalGb: null })]).total, 0);
  assert.equal(summarize([record({ totalGb: null })]).states[0].value, 1);
});

const headers = ['ID ', 'FECHA HORA', 'NOMBRE', 'N. EMPLEADO', 'DEPARTAMENTO ', 'EQUIPO ', 'N. SERIE', 'ESTADO', ' APP1', 'APP1 CONSUMO', 'APP1 UNIDAD', 'APP2', 'APP2 CONSUMO', 'APP2 UNIDAD', 'TOTAL CONSUMO', 'TOTAL UNIDAD'];
const excelRow = ['excel1', new Date('2026-08-01T12:00:00Z'), 'Prueba Excel', '012', 'Operaciones', 'Celular', 'EX-1', 'BUENO', 'WhatsApp', 825, 'MB', 'Facebook', '0.1', 'GB', '1.23', 'GB'];

test('Excel con unidades por celda convierte sin inferir ni cambiar el período', () => {
  const [r] = rowsToRecords([headers, excelRow], '2026-07', 'JULIO');
  assert.equal(r.apps[0].gb, 0.825);
  assert.equal(r.totalGb, 1.23);
  assert.equal(r.period, '2026-07');
  assert.equal(r.source.capturedAt, '2026-08-01T12:00:00.000Z');
  assert.equal(r.source.rawReadings.apps[0].amount, '825');
  assert.equal(issuesFor(r).length, 0);
});

test('Excel sin unidades queda pendiente; textos explícitos MB y GB sí se reconocen', () => {
  const row = [...excelRow]; row[10] = ''; row[13] = ''; row[15] = '';
  const [unknown] = rowsToRecords([headers, row], '2026-07', 'JULIO');
  assert.equal(unknown.totalGb, null);
  assert.ok(unknown.importErrors.some(i => i.includes('unidad')));
  row[9] = '825 MB'; row[12] = '0.1 GB'; row[14] = '1.23 GB';
  const [explicit] = rowsToRecords([headers, row], '2026-07', 'JULIO');
  assert.equal(issuesFor(explicit).length, 0);
  assert.throws(() => rowsToRecords([['Estado', 'Cantidad']], '2026-07', 'Gráfica'));
});

test('backup conserva pendientes, origen e historial y valida estructura', () => {
  const r = record({ reviewHistory: [{ at: '2026-07-01', note: 'Verificado', previousTotalGb: 4 }], totalGb: null });
  const [restored] = validateBackup({ schemaVersion: 1, records: [r] });
  assert.equal(restored.totalGb, null);
  assert.equal(restored.reviewHistory[0].note, 'Verificado');
  assert.throws(() => validateBackup({ schemaVersion: 2, records: [] }));
  assert.throws(() => validateBackup({ schemaVersion: 1, records: [r, r] }));
  assert.throws(() => validateBackup({ schemaVersion: 1, records: [record({ apps: [{ name: 'WhatsApp', gb: '825' }] })] }));
});

test('CSV indica pendientes y neutraliza fórmulas de Excel', () => {
  const csv = csvReport([record({ user: '=HYPERLINK("test")', totalGb: null })]);
  assert.ok(csv.includes("'=HYPERLINK"));
  assert.ok(csv.includes('Falta una lectura válida'));
  assert.ok(csv.startsWith('\ufeff'));
});
