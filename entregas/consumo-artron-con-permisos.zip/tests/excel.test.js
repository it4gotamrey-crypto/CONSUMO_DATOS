import test from 'node:test';
import assert from 'node:assert/strict';
import readExcel from 'read-excel-file/node';
import { excelReport } from '../src/excel-report.js';
import { validateBackup } from '../src/domain.js';
const fixture = validateBackup({ schemaVersion: 1, records: [
  { id: 'a', period: '2026-07', user: '=1+1', employee: '00001', department: 'Operaciones', device: 'Móvil', serial: '000100', imei1: '012345678901234', imei2: '012345678901235', status: 'Bueno', totalGb: 1.23, apps: [{ name: 'WhatsApp', gb: .825 }, { name: 'Facebook', gb: .1 }], comments: '=HYPERLINK("https://example.invalid","texto")' },
  { id: 'b', period: '2026-07', user: 'Usuario cero ficticio', employee: '00002', department: 'Ventas', device: 'PC', serial: 'SERIE-CERO', status: 'Bueno', totalGb: 0, apps: [{ name: 'WhatsApp', gb: 0 }] },
  { id: 'c', period: '2026-07', user: 'Pendiente ficticio', employee: '00003', department: 'Operaciones', device: 'Móvil', serial: 'SERIE-PENDIENTE', status: 'Bueno', totalGb: 1, apps: [{ name: 'WhatsApp', gb: 2 }] },
  { id: 'd', period: '2026-08', user: '=1+1', employee: '00001', department: 'Operaciones', device: 'Móvil', serial: '000100', status: 'Bueno', totalGb: 2, apps: [{ name: 'WhatsApp', gb: 1 }] },
  { id: 'e', period: '2026-09', user: 'Sin lectura ficticio', employee: '00004', department: 'Operaciones', device: 'PC', serial: 'SERIE-SIN-LECTURA', status: 'Bueno', totalGb: null, apps: [{ name: 'WhatsApp', gb: null }] },
] });
async function workbook(rows = fixture, all = fixture, filters) {
  const blob = await excelReport(rows, all, filters);
  return readExcel(Buffer.from(await blob.arrayBuffer()));
}
const sheet = (book, name) => book.find(s => s.sheet === name).data;
test('Excel real con ocho hojas, consumos numéricos e identificadores/texto sin interpretar', async () => {
  const book = await workbook();
  assert.equal(book.length, 8);
  const captures = sheet(book, 'Capturas'), first = captures[1];
  assert.equal(first[1], '=1+1'); assert.equal(first[2], '00001'); assert.equal(first[8], '000100');
  assert.equal(first[9], '012345678901234'); assert.equal(first[10], '012345678901235');
  assert.equal(first[13], 1.23); assert.equal(first[14], 1.23);
  assert.equal(first[17], '=HYPERLINK("https://example.invalid","texto")');
  assert.deepEqual(sheet(book, 'Por aplicación').slice(1), [['WhatsApp', 1.825], ['Facebook', .1]]);
  assert.equal(sheet(book, 'Por usuario')[1][2], 3.23);
});
test('pendientes se preservan en detalle y se excluyen de sumas; cero y ausencia son distintos', async () => {
  const book = await workbook(), rows = sheet(book, 'Capturas');
  const pending = rows.find(r => r[1] === 'Pendiente ficticio');
  assert.equal(pending[13], 1); assert.equal(pending[14], null); assert.equal(pending[15], 'Pendiente');
  assert.match(pending[16], /superan el total/);
  const empty = rows.find(r => r[1] === 'Sin lectura ficticio'); assert.equal(empty[13], null); assert.equal(empty[14], null);
  const zero = rows.find(r => r[1] === 'Usuario cero ficticio'); assert.equal(zero[13], 0); assert.equal(zero[14], 0);
  const metrics = new Map(sheet(book, 'Resumen').slice(1));
  assert.equal(metrics.get('Consumo total validado (GB)'), 3.23);
  assert.equal(metrics.get('Capturas pendientes'), 2);
  assert.deepEqual(sheet(book, 'Por período').slice(1), [['2026-07', 1.23, 2, 1], ['2026-08', 2, 1, 0], ['2026-09', null, 0, 1]]);
});
test('la selección limita el Excel y el resumen identifica los filtros', async () => {
  const book = await workbook([fixture[0]], fixture, { period: '2026-07', department: 'Operaciones', search: '00001' });
  assert.equal(sheet(book, 'Capturas').length, 2);
  assert.deepEqual(sheet(book, 'Por período').slice(1), [['2026-07', 1.23, 1, 0]]);
  const metrics = new Map(sheet(book, 'Resumen').slice(1));
  assert.equal(metrics.get('Período seleccionado'), '2026-07'); assert.equal(metrics.get('Departamento seleccionado'), 'Operaciones'); assert.equal(metrics.get('Búsqueda aplicada'), '00001');
});
test('un duplicado fuera del filtro sigue invalidando la captura seleccionada', async () => {
  const book = await workbook([fixture[0]], [fixture[0], { ...fixture[0], id: 'duplicado' }]);
  assert.equal(sheet(book, 'Capturas')[1][15], 'Pendiente');
  assert.equal(sheet(book, 'Capturas')[1][14], null);
  assert.equal(sheet(book, 'Por aplicación').length, 1);
});
test('selección vacía exporta encabezados sin inventar lecturas cero', async () => {
  const book = await workbook([], []), metrics = new Map(sheet(book, 'Resumen').slice(1));
  assert.equal(book.length, 8); assert.equal(sheet(book, 'Capturas').length, 1);
  assert.equal(metrics.get('Capturas exportadas'), 0); assert.equal(metrics.get('Consumo total validado (GB)'), null);
});
