import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { STORAGE_KEY } from '../src/storage.js';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:5173';
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
const context = await browser.newContext({ locale: 'es-MX', viewport: { width: 1360, height: 1180 } });
const page = await context.newPage(), errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.route('**/reference.json', r => r.fulfill({ status: 404 }));
await mkdir('test-results', { recursive: true });
const imei1 = '012345678901234', imei2 = '012345678901235';
const store = () => page.evaluate(key => JSON.parse(localStorage.getItem(key)), STORAGE_KEY);

async function openCapture(type, employee, serial) {
  await page.locator('[data-action=new]').first().click();
  const form = page.locator('#capture-form');
  for (const [name, value] of Object.entries({ period: '2026-08', employee, user: `Usuario de prueba ${employee}`, serial, brand: 'Marca de prueba', model: `Modelo ${employee}`, total: '1.23' })) await form.locator(`[name="${name}"]`).fill(value);
  await form.locator('[name=department]').selectOption('Operaciones');
  await form.locator('[name=device]').selectOption(type);
  await form.locator('[name=totalUnit]').selectOption('GB');
  return form;
}
async function save(form) { await form.locator('button[type=submit]').click(); await page.waitForSelector('#dialog', { state: 'detached' }); }

try {
  await page.goto(base); await page.waitForSelector('.metrics');
  let form = await openCapture('Móvil', 'E01', 'SERIE-MOVIL');
  assert.deepEqual(await form.locator('[name=device] option').evaluateAll(options => options.map(o => o.value)), ['', 'Móvil', 'Laptop', 'PC']);
  assert.equal(await form.locator('[name=imei2]').evaluate(el => el.required), false);
  await form.locator('[name=imei1]').fill(imei1); await form.locator('[name=imei2]').fill(imei1);
  await form.locator('button[type=submit]').click(); assert.match(await form.locator('#form-errors').textContent(), /diferentes/);
  assert.equal(await store(), null);
  await form.locator('[name=imei2]').fill('123'); await form.locator('button[type=submit]').click();
  assert.equal(await form.locator('[name=imei2]').evaluate(el => el.validity.patternMismatch), true); assert.equal(await store(), null);
  await form.locator('[name=imei2]').fill(imei2);
  await form.locator('#form-errors').evaluate(el => el.textContent = '');
  await form.locator('[name=device]').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'test-results/captura-dos-imei.png' });
  await save(form);
  assert.equal((await store()).records[0].imei1, imei1); assert.equal((await store()).records[0].imei2, imei2);
  assert.equal((await store()).records[0].serial, 'SERIE-MOVIL');
  form = await openCapture('Laptop', 'E02', 'SERIE-LAPTOP'); await save(form);
  form = await openCapture('PC', 'E03', 'SERIE-PC'); await save(form);
  assert.deepEqual((await store()).records.map(r => r.device), ['Móvil', 'Laptop', 'PC']);
  assert.equal((await store()).records[1].imei1, ''); assert.equal((await store()).records[2].imei2, '');
  form = await openCapture('Móvil', 'E04', 'OTRA-SERIE');
  await form.locator('[name=imei1]').fill(imei2); await form.locator('button[type=submit]').click();
  assert.match(await form.locator('#form-errors').textContent(), /mismo mes/); assert.equal((await store()).records.length, 3);
  await page.locator('[data-close]').click();
  await page.reload(); await page.waitForSelector('.metrics');
  await page.locator('[data-action=records]').first().click();
  assert.equal(await page.locator('.device-identification').filter({ hasText: imei2 }).count(), 1);
  await page.locator('[data-edit]').first().click();
  assert.equal(await page.locator('[name=imei1]').inputValue(), imei1); assert.equal(await page.locator('[name=imei2]').inputValue(), imei2);
  await page.locator('[data-close]').click();
  await page.locator('#search').fill(imei2); assert.equal(await page.locator('tbody tr').count(), 1);
  await page.locator('[data-action=clear]').first().click();
  // Legacy values stay unchanged on loading and are shown while selecting a type during review.
  await page.evaluate(key => {
    const data = JSON.parse(localStorage.getItem(key)); data.records[1].device = 'Descripción antigua de laptop';
    localStorage.setItem(key, JSON.stringify(data));
  }, STORAGE_KEY);
  await page.reload(); await page.waitForSelector('.metrics'); await page.locator('[data-action=records]').first().click();
  await page.locator('[data-edit]').nth(1).click(); assert.equal(await page.locator('[name=device]').inputValue(), '');
  assert.match(await page.locator('.legacy-equipment').textContent(), /Descripción antigua/);
  await page.locator('[name=device]').selectOption('Laptop'); await page.locator('[name=reviewNote]').fill('Tipo de equipo confirmado al revisar su etiqueta.');
  await save(page.locator('#capture-form'));
  assert.equal((await store()).records[1].deviceDescription, 'Descripción antigua de laptop');
  assert.equal((await store()).records[1].serial, 'SERIE-LAPTOP');
  await page.locator('[data-action=dashboard]').first().click(); await page.emulateMedia({ media: 'print' });
  await page.pdf({ path: 'test-results/equipos-imei.pdf', format: 'A4', landscape: true, printBackground: true });
  assert.deepEqual(errors, []);
  console.log('OK: selector Móvil/Laptop/PC, serie y dos IMEI independientes, campos opcionales, formato, duplicados entre ranuras, persistencia, búsqueda, revisión de datos anteriores e impresión.');
} finally { await browser.close(); }
