import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { request } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server/app.mjs';
import { createUser, verifyPassword, readState } from '../server/database.mjs';
const password = 'Prueba-temporal-2026!';
const record = (id = 'r1', serial = 'DEMO-S1') => ({ id, period: '2026-07', user: 'Usuario ficticio', employee: 'DEMO-1', department: 'Operaciones', device: 'Móvil', serial, imei1: '', imei2: '', status: 'Bueno', totalGb: .825, apps: [{ name: 'WhatsApp', gb: .825 }] });
async function fixture(t, options = {}) {
  const dir = await mkdtemp(join(tmpdir(), 'consumo-access-'));
  const app = createApp({ databasePath: join(dir, 'db.sqlite'), origin: 'http://consumo.test', basePath: '/modulos/consumo', ...options });
  app.server.listen(0, '127.0.0.1'); await once(app.server, 'listening');
  t.after(async () => { await new Promise(resolve => app.server.close(resolve)); await rm(dir, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${app.server.address().port}/modulos/consumo`;
  const users = {};
  for (const role of ['admin', 'capture', 'viewer']) users[role] = await createUser(app.db, { username: role, name: role, role, password });
  async function call(path, { method = 'GET', data, session, origin = 'http://consumo.test', csrf } = {}) {
    const response = await fetch(base + path, { method, headers: { ...(method === 'GET' ? {} : { Origin: origin, 'Content-Type': 'application/json', 'X-CSRF-Token': csrf ?? session?.csrf ?? '' }), ...(session ? { Cookie: session.cookie } : {}) }, ...(data !== undefined ? { body: JSON.stringify(data) } : {}) });
    const result = await response.json(); return { status: response.status, result, headers: response.headers };
  }
  async function login(role) {
    const response = await call('/api/login', { method: 'POST', data: { username: role, password } });
    assert.equal(response.status, 200);
    return { cookie: response.headers.get('set-cookie').split(';')[0], csrf: response.result.csrf, headers: response.headers };
  }
  return { ...app, users, call, login, base };
}
test('se requiere sesión: API, archivos privados y cookies protegidas', async t => {
  const { call, login, base, db } = await fixture(t);
  assert.equal((await call('/api/records')).status, 401);
  for (const file of ['/reference.json', '/consumo-local.html', '/server/database.mjs', '/assets/../reference.json']) assert.equal((await fetch(base + file)).status, 404);
  const session = await login('viewer');
  assert.match(session.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
  const info = await call('/api/session', { session });
  assert.equal(info.result.user.role, 'viewer'); assert.equal(info.result.user.password_hash, undefined);
  assert.ok(db.prepare('SELECT password_hash FROM users LIMIT 1').get().password_hash.startsWith('scrypt:'));
  assert.equal(await verifyPassword('incorrecta', db.prepare('SELECT password_hash FROM users LIMIT 1').get().password_hash), false);
  const page = await fetch(base + '/'); assert.match(await page.text(), /name="consumo-mode" content="server"/);
});
test('Consulta no puede guardar, crear usuarios ni leer auditoría, aunque envíe un rol falso', async t => {
  const { call, login } = await fixture(t), session = await login('viewer');
  assert.equal((await call('/api/records', { session })).status, 200);
  assert.equal((await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 0, records: [record()], role: 'admin' } })).status, 403);
  assert.equal((await call('/api/users', { method: 'POST', session, data: { username: 'intruso', name: 'Intruso', role: 'admin', password } })).status, 403);
  assert.equal((await call('/api/audit', { session })).status, 403);
});
test('Capturista crea lecturas válidas pero no corrige, elimina, importa pendientes ni aprueba picos', async t => {
  const { call, login } = await fixture(t), session = await login('capture');
  let result = await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 0, records: [record()] } });
  assert.equal(result.status, 200); assert.equal(result.result.records[0].totalGb, .825);
  const rows = result.result.records;
  for (const next of [[], [{ ...rows[0], totalGb: 1 }]]) assert.equal((await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 1, records: next } })).status, 403);
  assert.equal((await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 1, records: rows, allowPending: true } })).status, 403);
  const high = { ...record('r2', 'DEMO-S2'), totalGb: 150, reviewedHigh: true, reviewNote: 'Lectura revisada por alguien' };
  assert.equal((await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 1, records: [...rows, high] } })).status, 403);
});
test('El servidor rechaza números inválidos, meses inválidos, apps mayores al total y duplicados IMEI', async t => {
  const { call, login } = await fixture(t), session = await login('admin');
  for (const r of [{ ...record(), totalGb: -1 }, { ...record(), totalGb: '825' }, { ...record(), totalGb: .1 }, { ...record(), period: '2026-99' }, { ...record(), imei1: '123' }, { ...record(), device: 'Otro no admitido' }, { ...record(), totalGb: 1000000001, reviewedHigh: true, reviewNote: 'Confirmado en una prueba ficticia' }]) {
    assert.equal((await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 0, records: [r] } })).status, 422);
  }
  const first = { ...record(), imei1: '123456789012345' }, second = { ...record('r2', 'OTHER'), imei2: '123456789012345' };
  assert.equal((await call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision: 0, records: [first, second], allowPending: true } })).status, 422);
});
test('Administrador corrige y elimina con historial; la versión evita sobrescribir capturas de otra sesión', async t => {
  const { call, login, db } = await fixture(t), session = await login('admin');
  const put = (revision, records, allowPending = false) => call('/api/records', { method: 'PUT', session, data: { schemaVersion: 1, revision, records, allowPending } });
  let result = await put(0, [record()]); assert.equal(result.status, 200);
  const updated = { ...result.result.records[0], totalGb: 1, reviewNote: 'Corrección verificada en la prueba' };
  assert.equal((await put(1, [updated])).status, 200);
  assert.equal((await put(1, [])).status, 409);
  assert.equal(readState(db).records[0].totalGb, 1);
  assert.equal((await put(2, [])).status, 200);
  assert.equal((await put(3, [{ ...record(), totalGb: null }], true)).status, 200);
  const entries = (await call('/api/audit', { session })).result.entries;
  assert.ok(entries.some(e => e.action === 'record.create' && e.actor_name === 'admin'));
  assert.ok(entries.some(e => e.action === 'record.update'));
  assert.ok(entries.some(e => e.action === 'record.delete'));
});
test('Origen y CSRF son obligatorios; cerrar sesión revoca la cookie', async t => {
  const { call, login } = await fixture(t), session = await login('admin');
  const data = { schemaVersion: 1, revision: 0, records: [record()] };
  assert.equal((await call('/api/records', { method: 'PUT', session, data, csrf: 'falso' })).status, 403);
  assert.equal((await call('/api/records', { method: 'PUT', session, data, origin: 'https://otro-sitio.example' })).status, 403);
  assert.equal((await call('/api/login', { method: 'POST', data: { username: 'admin', password }, origin: 'https://otro-sitio.example' })).status, 403);
  assert.equal((await call('/api/logout', { method: 'POST', session, data: {} })).status, 200);
  assert.equal((await call('/api/records', { session })).status, 401);
});
test('Los cambios de rol, baja y contraseña revocan las sesiones; no se elimina el último administrador', async t => {
  const { call, login, users } = await fixture(t), admin = await login('admin'), capture = await login('capture');
  let result = await call(`/api/users/${users.capture.id}`, { method: 'PATCH', session: admin, data: { role: 'viewer' } }); assert.equal(result.status, 200);
  assert.equal((await call('/api/records', { session: capture })).status, 401);
  const viewer = await login('capture'); assert.equal((await call('/api/session', { session: viewer })).result.user.role, 'viewer');
  result = await call(`/api/users/${users.capture.id}`, { method: 'PATCH', session: admin, data: { active: false } }); assert.equal(result.status, 200);
  assert.equal((await call('/api/records', { session: viewer })).status, 401);
  assert.equal((await call(`/api/users/${users.admin.id}`, { method: 'PATCH', session: admin, data: { active: false } })).status, 422);
  const otherViewer = await login('viewer');
  assert.equal((await call(`/api/users/${users.viewer.id}`, { method: 'PATCH', session: admin, data: { password: 'Nueva-contraseña-segura-26!' } })).status, 200);
  assert.equal((await call('/api/records', { session: otherViewer })).status, 401);
});
test('No hay contraseña inicial pública y se limitan los intentos de acceso', async t => {
  const { call, login } = await fixture(t);
  assert.equal((await call('/api/users', { method: 'POST', session: await login('admin'), data: { username: 'nuevo', name: 'Nuevo', role: 'viewer', password: 'corta' } })).status, 422);
  for (let i = 0; i < 5; i++) assert.equal((await call('/api/login', { method: 'POST', data: { username: 'desconocido', password: 'incorrecta' } })).status, 401);
  assert.equal((await call('/api/login', { method: 'POST', data: { username: 'desconocido', password: 'incorrecta' } })).status, 429);
});
test('La sesión caduca y HTTPS exige cookie Secure', async t => {
  const { call, login } = await fixture(t, { origin: 'https://consumo.test', sessionTtlMs: 1 });
  // HTTPS affects the cookie; the local test transport still uses HTTP directly.
  const result = await call('/api/login', { method: 'POST', origin: 'https://consumo.test', data: { username: 'admin', password } });
  assert.equal(result.status, 200); assert.match(result.headers.get('set-cookie'), /__Host-consumo_session=.*; Secure$/);
  const session = { cookie: result.headers.get('set-cookie').split(';')[0], csrf: result.result.csrf };
  assert.equal((await call('/api/session', { session })).status, 401);
});

test('Una solicitud en curso pierde permiso si se revoca la sesión antes de terminar el envío', async t => {
  const { call, login, users, server, base, db } = await fixture(t);
  const admin = await login('admin'), capture = await login('capture');
  const payload = JSON.stringify({ schemaVersion: 1, revision: 0, records: [record()] });
  const received = once(server, 'request');
  const req = request(base + '/api/records', { method: 'PUT', headers: { Cookie: capture.cookie, Origin: 'http://consumo.test', 'Content-Type': 'application/json', 'X-CSRF-Token': capture.csrf, 'Content-Length': Buffer.byteLength(payload) } });
  const result = new Promise((resolve, reject) => { req.on('response', response => { response.resume(); response.on('end', () => resolve(response.statusCode)); }); req.on('error', reject); });
  req.write(payload.slice(0, 10)); await received;
  assert.equal((await call(`/api/users/${users.capture.id}`, { method: 'PATCH', session: admin, data: { active: false } })).status, 200);
  req.end(payload.slice(10)); assert.equal(await result, 401);
  assert.equal(readState(db).records.length, 0);
});
