import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir, readFile } from 'node:fs/promises';
import { STORAGE_KEY } from '../src/storage.js';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:5173';
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
const errors = [];
await mkdir('test-results', { recursive: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
async function pageFor(empty = false) {
  const page = await context.newPage(); page.on('pageerror', e => errors.push(e.message));
  if (empty) await page.route('**/reference.json', r => r.fulfill({ status: 404 }));
  await page.goto(base); await page.waitForSelector('.metrics'); return page;
}
const store = page => page.evaluate(key => JSON.parse(localStorage.getItem(key)), STORAGE_KEY);
const clickAction = async (page, action) => page.locator(`[data-action="${action}"]`).first().click();

try {
  const page = await pageFor();
  const seeded = await store(page);
  if (seeded) {
    assert.equal(seeded.records.length, 41); assert.ok(seeded.records.every(r => r.source.sheet === 'JULIO'));
    assert.match(await page.locator('.metrics').textContent(), /169\.346/);
    assert.match(await page.locator('.warning-metric').textContent(), /11/);
  }
  await page.screenshot({ path: 'test-results/dashboard.png', fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'La página móvil no debe desbordarse');
  await page.screenshot({ path: 'test-results/mobile.png', fullPage: true });
  // Print stylesheet and full details must be present, not just visible dashboard rows.
  await page.emulateMedia({ media: 'print' });
  assert.equal(await page.locator('.sidebar').isVisible(), false);
  assert.equal(await page.locator('.print-details').isVisible(), true);
  await page.pdf({ path: 'test-results/reporte.pdf', format: 'A4', landscape: true, printBackground: true });
  await page.close();

  await context.clearCookies();
  const capture = await pageFor(true);
  await capture.evaluate(() => localStorage.clear()); await capture.reload(); await capture.waitForSelector('.metrics');
  await clickAction(capture, 'new');
  const form = capture.locator('#capture-form');
  for (const [name, value] of Object.entries({ period: '2026-08', employee: 'T999', user: 'Usuario de prueba', serial: 'TEST-999', imei1: '012345678901234', imei2: '012345678901235', total: '1.23' })) await form.locator(`[name="${name}"]`).fill(value);
  await form.locator('[name="department"]').selectOption('Operaciones');
  await form.locator('[name="device"]').selectOption('Móvil');
  await form.locator('[name="appName"]').selectOption('WhatsApp');
  await form.locator('[name="appAmount"]').fill('825');
  await form.locator('button[type="submit"]').click();
  assert.equal(await form.isVisible(), true); assert.equal(await store(capture), null, 'La unidad obligatoria impide guardar');
  await form.locator('[name="totalUnit"]').selectOption('GB');
  await form.locator('button[type="submit"]').click();
  assert.match(await form.locator('#form-errors').textContent(), /Elige MB o GB/);
  await form.locator('[name="appUnit"]').selectOption('MB');
  assert.match(await form.locator('.unit-preview').textContent(), /0\.825 GB/);
  await form.locator('button[type="submit"]').click();
  await capture.waitForSelector('#dialog', { state: 'detached' });
  let data = await store(capture); assert.equal(data.records.length, 1); assert.equal(data.records[0].totalGb, 1.23); assert.equal(data.records[0].apps[0].gb, 0.825); assert.equal(data.records[0].imei1, '012345678901234'); assert.equal(data.records[0].imei2, '012345678901235');
  await capture.reload(); await capture.waitForSelector('.metrics'); assert.equal((await store(capture)).records[0].apps[0].gb, 0.825);
  await clickAction(capture, 'records'); await capture.locator('[data-edit]').first().click();
  await capture.locator('[name="appUnit"]').selectOption('GB');
  await capture.locator('[name="appAmount"]').fill('825');
  await capture.locator('[name="reviewNote"]').fill('Verificada la unidad en pantalla.');
  await capture.locator('#capture-form button[type="submit"]').click();
  assert.match(await capture.locator('#form-errors').textContent(), /superan el total/);
  assert.equal((await store(capture)).records[0].apps[0].gb, 0.825, 'Rechazo conserva la captura original');
  await capture.locator('[name="appUnit"]').selectOption('MB');
  await capture.locator('[name="appAmount"]').fill('825');
  await capture.locator('[name="total"]').fill('1.5');
  await capture.locator('#capture-form button[type="submit"]').click();
  await capture.waitForSelector('#dialog', { state: 'detached' });
  assert.equal((await store(capture)).records[0].totalGb, 1.5);

  await clickAction(capture, 'backup');
  const pendingDownload = capture.waitForEvent('download'); await capture.locator('#download-backup').click();
  const backup = await pendingDownload; await backup.saveAs('test-results/respaldo.json');
  const json = JSON.parse(await readFile('test-results/respaldo.json', 'utf8'));
  assert.equal(json.records[0].reviewHistory.length, 1); assert.equal(json.records[0].imei2, '012345678901235');
  await capture.locator('[data-close]').click();

  // Start a separate storage context for restoration and Excel import.
  const fresh = await browser.newContext(); const restore = await fresh.newPage();
  restore.on('pageerror', e => errors.push(e.message)); await restore.route('**/reference.json', r => r.fulfill({ status: 404 }));
  await restore.goto(base); await restore.waitForSelector('.metrics'); await clickAction(restore, 'backup');
  await restore.locator('#backup-file').setInputFiles('test-results/respaldo.json');
  await restore.waitForSelector('.import-summary'); await restore.locator('#confirm-import').click();
  await restore.waitForSelector('#dialog', { state: 'detached' });
  assert.equal((await store(restore)).records[0].totalGb, 1.5); assert.equal((await store(restore)).records[0].reviewHistory.length, 1); assert.equal((await store(restore)).records[0].imei1, '012345678901234');
  await clickAction(restore, 'import'); await restore.locator('#excel-file').setInputFiles('tests/fixtures/import.xlsx');
  await restore.waitForSelector('#import-options:not([hidden])');
  await restore.locator('#import-period').fill('2026-07');
  await restore.locator('#preview-import').click(); await restore.waitForSelector('.import-summary');
  assert.match(await restore.locator('.import-summary').textContent(), /2capturas nuevas1por revisar1duplicados omitidos/);
  await restore.locator('#confirm-import').click(); await restore.waitForSelector('#dialog', { state: 'detached' });
  data = await store(restore); assert.equal(data.records.length, 3); assert.equal(data.records.filter(r => r.period === '2026-07').length, 2);
  assert.equal(data.records.find(r => r.employee === 'T001').apps[0].gb, 0.825);
  assert.equal(data.records.find(r => r.employee === 'T002').apps[0].gb, null);
  assert.match(await restore.locator('.metrics').textContent(), /1\.23/);
  await clickAction(restore, 'quality'); assert.equal(await restore.locator('.quality-card').count(), 1);
  // Reject a chart sheet, and show zero new records on repeat import.
  await clickAction(restore, 'import'); await restore.locator('#excel-file').setInputFiles('tests/fixtures/import.xlsx');
  await restore.waitForSelector('#import-options:not([hidden])'); await restore.locator('#import-period').fill('2026-07');
  await restore.locator('#import-sheet').selectOption('Gráfica'); await restore.locator('#preview-import').click();
  assert.match(await restore.locator('#import-error').textContent(), /columna NOMBRE/);
  await restore.locator('#import-sheet').selectOption('JULIO'); await restore.locator('#preview-import').click();
  assert.equal(await restore.locator('#confirm-import').isDisabled(), true);
  assert.match(await restore.locator('.import-summary').textContent(), /0capturas nuevas0por revisar3duplicados omitidos/);
  await restore.locator('[data-close]').click();
  // Imported markup is displayed literally rather than executed.
  await restore.evaluate(key => {
    const d = JSON.parse(localStorage.getItem(key)); d.records[0].user = '<img src=x onerror="window.injected=true">'; localStorage.setItem(key, JSON.stringify(d));
  }, STORAGE_KEY);
  await restore.reload(); await restore.waitForSelector('.metrics'); assert.equal(await restore.evaluate(() => window.injected), undefined);
  // Corrupted storage must not be silently reset or overwritten.
  await restore.evaluate(key => localStorage.setItem(key, 'invalid-json'), STORAGE_KEY);
  await restore.reload(); await restore.waitForSelector('.error-notice');
  assert.equal(await restore.evaluate(key => localStorage.getItem(key), STORAGE_KEY), 'invalid-json');
  assert.deepEqual(errors, []);
  console.log('OK: referencia JULIO, móvil, PDF, MB/GB obligatorio, captura, persistencia, rechazo de inconsistencias, respaldo/restauración, Excel mixto, duplicados, escape de HTML y conservación de datos dañados.');
  await fresh.close();
} finally { await browser.close(); }
