import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAggregateHistory } from '../src/history.js';
import { normalizeLayout, moveChart, CHART_IDS, DEFAULT_VISIBLE } from '../src/report-layout.js';

const record = (id, period, employee, totalGb, apps = [], overrides = {}) => ({ id, period, employee, user: `Usuario ${employee}`, device: 'Móvil', serial: `SERIE-${employee}`, department: 'Operaciones', status: 'Bueno', totalGb, apps, ...overrides });

test('total por período suma las lecturas de equipos sin sumar el desglose otra vez', () => {
  const rows = [record('1', '2026-06', '1', 2, [{ name: 'WhatsApp', gb: .825 }]), record('2', '2026-06', '2', 3, [{ name: 'WhatsApp', gb: 1 }]), record('3', '2026-07', '1', 4)];
  const data = buildAggregateHistory(rows);
  assert.deepEqual(data.series[0].points.map(p => p.value), [5, 4]);
  assert.equal(data.series[0].total, 9);
  assert.equal(data.series[0].change, -1);
});
test('aplicaciones se agregan entre usuarios por mes y sus faltantes siguen desconocidos', () => {
  const rows = [record('1', '2026-06', '1', 2, [{ name: 'WhatsApp', gb: .825 }]), record('2', '2026-06', '2', 3, [{ name: 'WhatsApp', gb: 1 }]), record('3', '2026-07', '1', 2), record('4', '2026-08', '1', 0, [{ name: 'WhatsApp', gb: 0 }])];
  const data = buildAggregateHistory(rows, { mode: 'apps', apps: ['WhatsApp'] });
  assert.deepEqual(data.series[0].points.map(p => p.value), [1.825, null, 0]);
  assert.equal(data.series[0].points[1].unlisted, 1);
  assert.equal(data.series[0].points[2].readings, 1);
});
test('meses sin lectura y meses con solo pendientes no se convierten en cero', () => {
  const rows = [record('1', '2026-06', '1', 2), record('2', '2026-08', '1', null), record('3', '2026-09', '1', 0)];
  const data = buildAggregateHistory(rows);
  assert.deepEqual(data.months, ['2026-06', '2026-07', '2026-08', '2026-09']);
  assert.deepEqual(data.series[0].points.map(p => p.value), [2, null, null, 0]);
  assert.equal(data.series[0].points[2].pending, 1);
  assert.equal(data.pendingCount, 1);
});
test('filtros de intervalo, departamento y búsqueda afectan el agregado', () => {
  const rows = [record('1', '2026-06', '1', 2), record('2', '2026-07', '1', 3), record('3', '2026-07', '2', 4, [], { department: 'Ventas' })];
  assert.equal(buildAggregateHistory(rows, { from: '2026-07', to: '2026-07', department: 'Operaciones' }).series[0].total, 3);
  assert.equal(buildAggregateHistory(rows, { query: 'usuario 2' }).series[0].total, 4);
});
test('la selección automática incluye apps con consumo cero explícito', () => {
  const data = buildAggregateHistory([record('1', '2026-07', '1', 0, [{ name: 'WhatsApp', gb: 0 }])], { mode: 'apps' });
  assert.equal(data.series[0].name, 'WhatsApp'); assert.equal(data.series[0].points[0].value, 0);
});
test('visibilidad es válida, persiste al mover y no muta las preferencias anteriores', () => {
  const initial = normalizeLayout(); assert.deepEqual(initial.visible, DEFAULT_VISIBLE);
  const chosen = normalizeLayout({ visible: ['history', 'history', 'invented'] }); assert.deepEqual(chosen.visible, ['history']);
  const moved = moveChart(chosen, 'history', CHART_IDS.length - 1); assert.deepEqual(moved.visible, ['history']);
  assert.deepEqual(normalizeLayout({ visible: [] }).visible, DEFAULT_VISIBLE);
  assert.equal(chosen.order[0], 'history');
});
