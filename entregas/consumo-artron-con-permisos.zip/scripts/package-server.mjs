import { mkdir, cp, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
const destination = resolve(process.argv[2] || '.local/servidor-artron');
await mkdir(join(destination, 'dist'), { recursive: true });
// Only public application assets: never ship the private JULIO reference or local HTML.
await cp('dist/index.html', join(destination, 'dist/index.html'));
await cp('dist/assets', join(destination, 'dist/assets'), { recursive: true });
for (const folder of ['server', 'src', 'scripts', 'tests']) await cp(folder, join(destination, folder), { recursive: true });
for (const file of ['package.json', 'package-lock.json', 'index.html', 'vite.config.js', 'INSTALACION_SERVIDOR.md', 'README.md', 'INTEGRACION_ARTRON.md']) await cp(file, join(destination, file));
await writeFile(join(destination, '.gitignore'), 'node_modules/\n.local/\ndist/\n*.sqlite*\n.env\n.env.*\n');
console.log(`Servidor preparado en ${destination}; sin datos privados ni cuentas predeterminadas.`);
