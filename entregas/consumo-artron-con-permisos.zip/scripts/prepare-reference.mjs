// Optional private seed; the source workbook and generated JSON stay outside Git.
import readXlsxFile from 'read-excel-file/node';
import { mkdir, writeFile } from 'node:fs/promises';
import { rowsToRecords, summarize } from '../src/domain.js';

const [file, period, sheetName, unit] = process.argv.slice(2);
if (!file || !/^\d{4}-(0[1-9]|1[0-2])$/.test(period || '') || !sheetName || !['MB', 'GB'].includes(unit)) {
  console.error('Uso: node scripts/prepare-reference.mjs archivo.xlsx AAAA-MM "Pestaña" GB|MB');
  process.exit(1);
}
const sheets = await readXlsxFile(file);
const sheet = sheets.find(sheet => sheet.sheet === sheetName);
if (!sheet) throw new Error('Pestaña no encontrada.');
const records = rowsToRecords(sheet.data, period, sheet.sheet, unit);
await mkdir('public', { recursive: true });
await writeFile('public/reference.json', JSON.stringify({ schemaVersion: 1, records }, null, 2));
const summary = summarize(records);
console.log(`${records.length} registros de ${sheetName}: ${summary.valid.length} validados, ${summary.pending.length} pendientes, ${summary.total} GB validados.`);
