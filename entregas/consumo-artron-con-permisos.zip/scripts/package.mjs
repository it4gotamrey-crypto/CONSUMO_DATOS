import { readFile, writeFile, mkdir, cp } from 'node:fs/promises';
import { resolve, join } from 'node:path';

const destination = resolve(process.argv[2] || '.local/entregables');
await mkdir(destination, { recursive: true });
await cp('dist', join(destination, 'web'), { recursive: true });
let html = await readFile('dist/index.html', 'utf8');
const script = html.match(/<script[^>]+src="\.\/([^\"]+)"[^>]*><\/script>/);
const style = html.match(/<link[^>]+href="\.\/([^\"]+\.css)"[^>]*>/);
if (!script || !style) throw new Error('Primero ejecuta npm run build.');
const js = (await readFile(join('dist', script[1]), 'utf8')).replace(/<\/script/gi, '<\\/script');
const css = await readFile(join('dist', style[1]), 'utf8');
html = html.replace(script[0], () => `<script type="module">${js}</script>`).replace(style[0], () => `<style>${css}</style>`);
let seed = { schemaVersion: 1, records: [] };
try { seed = JSON.parse(await readFile('dist/reference.json', 'utf8')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
html = html.replace('</body>', () => `<script type="application/json" id="consumo-reference">${JSON.stringify(seed).replaceAll('<', '\\u003c')}</script></body>`);
await writeFile(join(destination, 'consumo-local.html'), html);
await writeFile(join(destination, 'web', 'consumo-local.html'), html);
await cp('README.md', join(destination, 'LEEME.md'));
await cp('INTEGRACION_ARTRON.md', join(destination, 'INTEGRACION_ARTRON.md'));
console.log(`Paquete web y archivo local generados en ${destination}. La referencia privada se incluye si existe en dist/.`);
