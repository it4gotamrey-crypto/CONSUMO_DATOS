# Integración de Consumo con Artron · v1.5

La versión con usuarios, permisos y datos oficiales compartidos se instala siguiendo [INSTALACION_SERVIDOR.md](INSTALACION_SERVIDOR.md). Incluye un servidor Node.js 24, SQLite, acceso propio y roles Administrador/Capturista/Consulta. No se ha desplegado todavía en Artron.

Para esa versión usar `npm run package:server`, mantener la base fuera de las rutas públicas y servir pantalla/API con el proceso Node detrás de HTTPS. El paquete de servidor no contiene las referencias privadas de JULIO, un HTML local descargable ni contraseñas iniciales. El administrador importa las capturas actuales desde un respaldo JSON después de revisar la vista previa.

El código del navegador es visible para quien lo utiliza; los permisos se hacen cumplir en el servidor. El sistema rechaza escrituras no autorizadas aunque se modifique la interfaz o se falsifique un rol. Un Capturista crea lecturas válidas; solo Administrador corrige, elimina, importa pendientes o administra cuentas. Consulta ve e imprime.

Los datos personales de la versión local anterior siguen en cada navegador. Esa versión autónoma sirve para uso personal y no ofrece control de acceso fiable. A continuación se conserva su guía de entrega como referencia; sus instrucciones de publicación estática **no activan** la protección de v1.5.

---

# Entrega para el equipo de Artron — Consumo de datos v1.4

Este módulo está desarrollado en **HTML, CSS y JavaScript**. La interfaz azul incluye captura mensual, validaciones MB/GB, importación de Excel, revisión de datos, siete gráficas ajustables y seleccionables, comparación histórica por usuario, respaldos y reporte imprimible.

## Archivos de entrega

- `web/`: versión compilada para alojar dentro de Artron. Su entrada es `web/index.html`; debe copiarse la carpeta completa, incluidos `assets/` y la referencia opcional.
- `consumo-local.html`: la misma interfaz en un único HTML con CSS y JavaScript incorporados. Para demostraciones y uso local en un navegador que permita abrir archivos HTML.
- `codigo-fuente.zip`: código editable, manifiesto y lockfile, documentación y pruebas con datos ficticios. No contiene las capturas privadas de JULIO.
- `LEEME.md`: guía de captura, unidades, importación, respaldos y personalización.

## Integración como módulo web

1. Publicar el contenido de `web/` bajo una ruta del sistema, por ejemplo `/modulos/consumo/`.
2. Agregar al menú de Artron un enlace a `/modulos/consumo/index.html`.
3. Aplicar el acceso de usuarios que ya usa Artron a esa ruta y sus archivos de referencia.
4. Abrir la ruta y comprobar captura, conversión de `825 MB` a `0.825 GB`, edición del reporte, exportación e impresión.

Los recursos tienen rutas relativas. El build puede alojarse en un subdirectorio y no necesita Node.js en producción, una API externa ni CDNs. Node.js solo se utiliza para desarrollar y construir.

También puede mostrarse en un iframe:

```html
<iframe
  src="/modulos/consumo/index.html"
  title="Control de consumo de datos"
  style="width:100%; height:1100px; border:0;"
></iframe>
```

Si el sistema añade `sandbox` al iframe, este debe permitir `allow-scripts allow-same-origin allow-downloads allow-modals`. El acceso y los encabezados de contenido del sistema deberán permitir el módulo. No es necesario poner credenciales en el HTML.

## Datos actuales y almacenamiento

La entrega para este usuario incorpora `web/reference.json` y una referencia embebida en el HTML autónomo con **41 capturas de JULIO / 2026-07**. Se cargan únicamente cuando el navegador no tiene capturas guardadas. **11 necesitan revisión** y se excluyen de los indicadores. Las referencias contienen datos reales de usuarios y equipos; esta entrega corresponde al uso interno autorizado del equipo de Artron.

El subtotal de lecturas que pasan las reglas es 169.346 GB; no es el total definitivo de julio. El histórico real tiene solo ese mes: no se generan otros meses ni lecturas ficticias. Las demostraciones y las pruebas históricas usan contextos independientes y registros ficticios.

Los datos se almacenan en `localStorage`, por origen y perfil de navegador. Las claves actuales son:

- `artron.consumo.v1`: capturas y fecha de guardado.
- `artron.consumo.layout.v1`: orden, ancho y alto de las gráficas.
- `artron.consumo.history.v1`: intervalo, métrica y usuarios de la comparación.

Esta versión no integra la base de datos, el inicio de sesión ni la API de Artron. Las capturas de diferentes navegadores son independientes. Para un uso compartido, el equipo debe conectar la lectura y escritura a su servidor y validar allí también las reglas de consumo. Los respaldos JSON permiten trasladar capturas manualmente.

Para distribuir el panel vacío, construir desde el código fuente, que no incluye la referencia privada, o quitar la referencia local antes de ejecutar el build. Nunca sustituir las capturas del navegador automáticamente al cargar una referencia.

## Código y contrato para conectar al servidor

- `src/main.js`: interfaz, formularios y flujos de importación/exportación.
- `src/domain.js`: conversión de unidades, validación de capturas, identidad de equipos y cálculos.
- `src/storage.js`: lectura y escritura local, punto de partida para un adaptador de persistencia.
- `src/history.js` y `src/history-chart.js`: agregación por empleado, períodos, aplicación y gráfica histórica.
- `src/report-layout.js`: distribución guardada y controles de movimiento/tamaño.
- `src/report.css`: diseño y colores azules; `src/style.css`: estilos base.

El respaldo tiene `schemaVersion: 1` y `records`. Cada captura incluye `id`, `period` (AAAA-MM), `employee`, `user`, `department`, `device` (Móvil/Laptop/PC en capturas nuevas), `deviceDescription` (nombre anterior, cuando existe), `brand`, `model`, `serial`, `imei1`, `imei2`, `status`, `totalGb`, `apps: [{name, gb}]`, datos del equipo, notas e información de origen.

Todos los consumos persistidos se normalizan a GB, usando 1 GB = 1,000 MB. `null` significa lectura pendiente; un cero significa una lectura explícita de cero. Las aplicaciones son un desglose del total, no se suman otra vez. Un mes sin lectura no se convierte en cero ni se conecta con una línea en el histórico. Para una aplicación ausente del desglose, su consumo es desconocido.

Al conectar el servidor, conservar los identificadores, las unidades, el período mensual, las notas de revisión y la prevención de capturas duplicadas por equipo y mes. Validar estas reglas también en el servidor para que los datos compartidos sigan siendo coherentes.

## Desarrollo y comprobación

Requisitos: Node.js 22.12+ o 24, npm; Chromium para las pruebas de navegador.

```bash
npm ci --cache /tmp/consumo-npm-cache
npm run dev -- --port 5173 --strictPort
```

En otra terminal, desde la misma carpeta:

```bash
npm test
npm run test:browser
npm run test:report
npm run test:equipment
npm run test:analytics
npm run build
```

`npm run build` produce `dist/`. `npm run package` produce una carpeta local de entrega con la versión web y el HTML autónomo. Las pruebas funcionales usan Chromium en `/usr/bin/chromium`; se puede configurar con `CHROMIUM_PATH`, y la URL del servidor con `TEST_BASE_URL`.


## Identificación de equipos en v1.3

Serie, IMEI 1 e IMEI 2 son campos distintos. `imei1` e `imei2` son cadenas de 15 dígitos o cadenas vacías si no aplican; el servidor debe conservar sus ceros iniciales. No convertirlos a números ni concatenarlos en `serial`. Se admite uno o dos IMEI y también equipos sin IMEI, como PC o laptops sin módem celular. Un dispositivo con dos IMEI conserva una sola captura mensual y un solo total.

La identidad física se compara usando la serie o la coincidencia de cualquiera de los dos IMEI. La validación bloquea una segunda captura del mismo equipo y mes aunque los IMEI cambien de ranura. Estos controles también deben aplicarse en el servidor si se conectan datos compartidos.

Las nuevas capturas usan `device: "Móvil"`, `"Laptop"` o `"PC"`, con marca y modelo separados. Las capturas antiguas pueden contener nombres libres en `device`; se conservan hasta su revisión. Al confirmar el tipo se conserva el nombre antiguo en `deviceDescription`. Los respaldos anteriores siguen siendo compatibles y las series históricas no se reasignan automáticamente a un IMEI.


## Selección y agregados en v1.4

El panel muestra dos gráficas al iniciar para evitar una vista saturada. El usuario puede mostrar una, dos, todas o elegir una combinación personalizada; la impresión usa la misma selección. Son siete opciones: total mensual, histórico de apps, histórico de usuarios, clasificaciones de apps/usuarios, departamentos y estado de equipos. La selección `visible` se almacena junto con el orden y tamaño en `artron.consumo.layout.v1`.

`artron.consumo.analytics.v1` guarda los intervalos del total mensual y las apps, y las aplicaciones elegidas. Estas preferencias son locales y no afectan las capturas ni sus respaldos. Los cálculos agregados están en `buildAggregateHistory` en `src/history.js`. El total mensual suma `totalGb` de capturas validadas; el histórico de una app suma sus `apps[].gb` registrados. No sumar las apps otra vez al total ni rellenar meses o desgloses faltantes con cero.

El botón **Descargar panel** de la versión web requiere mantener `consumo-local.html` junto a `web/index.html`; el empaquetador ya lo genera ahí. La descarga contiene la aplicación autónoma y las capturas actuales. No necesita archivos JS/CSS externos.
