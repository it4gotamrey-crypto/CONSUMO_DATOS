# Novedad v1.6: descargar Excel sin conexión

El HTML local incluye **Descargar Excel (.xlsx)** en **Respaldo y exportación** y en **Capturas mensuales**. Exporta la selección actual en ocho hojas, con detalles y resúmenes; distingue pendientes y ceros, y conserva las series/IMEI como texto. No requiere red ni un servidor. Antes de actualizar el archivo HTML, conserva un respaldo JSON de tus capturas.

# Uso actual: HTML sin internet y sin usuarios propios

Para probar ahora en un dispositivo compatible, usar **consumo-sin-internet.html**. No requiere servidor ni inicio de sesión. Instrucciones: [USO_SIN_INTERNET.md](USO_SIN_INTERNET.md).

La integración final reutilizará el login y los permisos existentes de Artron: [INTEGRACION_LOGIN_ARTRON.md](INTEGRACION_LOGIN_ARTRON.md). La API y el almacenamiento de Artron aún no están conectados. El servidor con cuentas propias descrito más abajo queda como alternativa anterior, no como requisito para la prueba local.

---

# Consumo de datos · v1.5

Panel azul para consumos mensuales, dispositivos, dos IMEI, aplicaciones e históricos. Hay dos modos: HTML local para uso personal y servidor para datos oficiales compartidos con usuarios y permisos.

**Instalación con roles y servidor:** [INSTALACION_SERVIDOR.md](INSTALACION_SERVIDOR.md). Requiere Node.js 24. No hay credenciales predeterminadas. Administrador configura/corrige, Capturista crea capturas y Consulta ve/imprime. La autorización real se aplica en la API. El código del navegador puede verse y copiarse; eso no permite cambiar los datos oficiales sin permiso.

Construir el paquete con `npm run package:server`. El servidor comienza sin capturas; un administrador migra el respaldo JSON desde el panel local. Su instalación en Artron requiere que el equipo del sistema configure la ruta, HTTPS y el proceso servidor.

---

# Consumo · Control mensual de dispositivos

Panel web en español para capturar consumo de datos, revisar errores y reportar aplicaciones, usuarios, departamentos y condiciones de equipos. Preparado para publicarse como archivos estáticos e integrarse a Artron.

La versión 1.4 usa una interfaz azul con accesos directos para importar Excel, revisar capturas y respaldar/exportar. Está desarrollada en HTML, CSS y JavaScript. La entrega para el equipo de integración se explica en [INTEGRACION_ARTRON.md](INTEGRACION_ARTRON.md).

## Iniciar

Requiere Node.js 22.12+ o 24 y npm. En la carpeta del repositorio:

```bash
npm ci --cache /tmp/consumo-npm-cache
npm run dev -- --port 5173 --strictPort
```

La instalación usa el lockfile. No requiere base de datos, credenciales ni servicios externos. La aplicación usa `localStorage` y no envía capturas a un servidor.

## Capturar sin confundir MB y GB

- El período se selecciona explícitamente; puede diferir de la fecha en que se hace la captura.
- **Cada lectura exige su unidad**, tanto el total como cada aplicación. Las capturas nuevas comienzan sin unidad seleccionada.
- `825 MB` se guarda como `0.825 GB`; `1.23 GB` se guarda como `1.23 GB`. Se usa **1 GB = 1,000 MB**. La conversión se ve antes de guardar.
- Se aceptan punto o coma decimal, hasta tres decimales de entrada, sin separadores de miles. Se conservan hasta seis decimales en GB al convertir MB.
- Las aplicaciones se seleccionan de un catálogo; se pueden agregar otras. Alias conocidos de AppSheet se normalizan al importar.
- La suma de aplicaciones debe ser menor o igual al total del dispositivo. Las aplicaciones son un desglose del total: **no se suman otra vez** al consumo del usuario.
- El resto se muestra como **Sin desglose**, porque las tres aplicaciones de la hoja no necesariamente explican todo el consumo.
- Un equipo tiene una captura por mes. Se identifica por la serie o por cualquiera de sus IMEI; si no hay identificadores, se usa empleado y descripción del equipo. Conviene siempre capturar la serie para evitar duplicados con nombres de equipo distintos.
- Un total mayor a 100 GB o superior a tres veces la última lectura disponible (y mayor a 5 GB) requiere confirmación y una nota. Es un control de plausibilidad; el panel no puede comprobar la lectura física del equipo.
- Las correcciones requieren una nota y conservan historial. Los comentarios y datos del equipo también se pueden editar.

## Importar Excel / AppSheet

Usa **Importar Excel**, selecciona la pestaña mensual, su período y revisa la previsualización. Las hojas de gráficas no son fuentes de capturas. No se combinan pestañas automáticamente.

Se reconocen las columnas de la hoja proporcionada: `NOMBRE`, `N. EMPLEADO`, `DEPARTAMENTO`, `EQUIPO`, `N. SERIE`, `IMEI 1`, `IMEI 2`, `ESTADO`, `APP1`, `APP1 CONSUMO`, `APP2`, `APP2 CONSUMO`, `APP3`, `APP3 CONSUMO`, `TOTAL CONSUMO` y la información adicional del equipo. Los espacios en los encabezados se toleran.

Para una hoja con MB y GB mezclados, agrega unidades explícitas:

| APP1 | APP1 CONSUMO | APP1 UNIDAD | TOTAL CONSUMO | TOTAL UNIDAD |
| --- | ---: | --- | ---: | --- |
| WhatsApp | 825 | MB | 1.23 | GB |

También se reconocen `APP2 UNIDAD` y `APP3 UNIDAD`, o celdas con unidad escrita, como `825 MB` o `1.23 GB`. La selección global “Toda la hoja está en GB/MB” solo se debe usar cuando esa unidad está confirmada para todos sus números.

**No se infiere una unidad por el tamaño del número.** Los valores sin unidad confirmada, datos faltantes e inconsistencias quedan en **Calidad de datos**. Se conservan las lecturas originales y estos registros no participan en los indicadores de consumo. El inventario de estados sí incluye todos los registros de la selección. Los duplicados se omiten sin reemplazar los existentes.

La importación es manual; esta versión no sincroniza con AppSheet ni Google Sheets.

## Referencia privada JULIO

En este entorno se preparó una referencia de **JULIO / 2026-07** a petición del usuario. Contiene 41 capturas: 30 pasan las reglas iniciales y 11 necesitan revisión. El subtotal de lecturas que pasan las reglas es 169.346 GB; **no representa el total definitivo de julio**.

La referencia está en `public/reference.json`, excluida de Git. Se carga solo si el navegador no tiene almacenamiento previo. Nunca reemplaza capturas locales existentes. En un checkout limpio, el panel comienza vacío y permite importar Excel.

Para generar otra referencia con una hoja cuya unidad global esté confirmada:

```bash
node scripts/prepare-reference.mjs /ruta/privada/archivo.xlsx 2026-07 JULIO GB
```

El Excel original permanece fuera del repositorio. **Si `public/reference.json` existe, el build lo incorpora**: publica esa copia solo en un sitio interno autorizado. Para distribuir el panel vacío, retira la referencia local antes del build o usa un checkout limpio.

## Respaldar e imprimir

**Respaldo y exportación** descarga un JSON completo (`schemaVersion: 1`) con capturas, aplicaciones, origen y notas. Restaurarlo agrega registros nuevos y omite duplicados; no sobrescribe los actuales. Exporta antes de cambiar de navegador o borrar datos del sitio.

El CSV incluye las capturas de la selección y señala las pendientes. Los textos que puedan interpretarse como fórmulas se neutralizan. **Imprimir** permite guardar PDF: incluye filtros activos, indicadores, condiciones, detalle completo y consumo por aplicación y usuario. Los pendientes están identificados y excluidos de los totales.

El almacenamiento pertenece al perfil del navegador y al origen del sitio. Cambiar de dominio, limpiar datos o usar otro equipo crea un almacenamiento distinto. Varias personas en distintos navegadores no comparten datos automáticamente. Se pueden trasladar respaldos; los registros repetidos deben revisarse manualmente si existen versiones distintas.

## Integración con Artron

```bash
npm run build
```

Copia **todo `dist/`** a una ruta de Artron, por ejemplo `/modulos/consumo/`, y enlaza su `index.html`. Los recursos usan rutas relativas, por lo que funciona en subdirectorios. No requiere CDNs ni un servidor de Node para alojar el build; basta un servidor de archivos estáticos.

También puede embeberse en un iframe. El contenedor debe permitir scripts y almacenamiento del origen. Si usa `sandbox`, necesita `allow-scripts`, `allow-same-origin`, `allow-downloads` y `allow-modals` para captura, almacenamiento, exportación e impresión. Artron debe aplicar su control de acceso habitual, especialmente si se distribuye la referencia privada.

Para datos compartidos entre usuarios hará falta una API y almacenamiento en servidor. El contrato inicial es el JSON de respaldo: `schemaVersion`, `records` y, por registro, `id`, `period`, `employee`, `user`, `device`, `serial`, `department`, `status`, `totalGb`, `apps: [{name, gb}]`, notas y origen. Los consumos normalizados siempre están en GB; `null` significa lectura pendiente, nunca cero implícito. Las reglas están en `src/domain.js`, separadas de la interfaz. Esta versión no implementa autenticación, servidor compartido ni comunicación automática con Artron.

## Verificar

```bash
npm test
npm run build
# Con el servidor de desarrollo iniciado:
npm run test:browser
```

Las pruebas de navegador usan Chromium en `/usr/bin/chromium`; configura `CHROMIUM_PATH` si está en otra ruta y `TEST_BASE_URL` si cambia el puerto. Generan capturas, PDF y un respaldo de prueba en `test-results/` (excluido de Git). La fixture Excel contiene únicamente datos ficticios.

Cada tarea en la nube ya está aislada: utiliza este checkout y no crees un worktree salvo que el usuario lo pida.

## Archivo local para abrir directamente

`npm run package` genera `.local/entregables/consumo-local.html`: incluye CSS, JavaScript y la referencia opcional dentro de un único archivo. Se puede abrir directamente en un navegador moderno y no necesita conexión a Internet para cargar el panel. Permite importar Excel, respaldar e imprimir. Los datos siguen dependiendo de ese perfil de navegador; cambiar de archivo, navegador o sitio puede cambiar el almacenamiento. Usa respaldos JSON para trasladarlos.

El directorio `web/` del paquete contiene la versión estática para Artron. Ambas versiones incluyen la referencia privada si estaba presente al construirlas.

## Personalizar el reporte

El nuevo diseño tiene navegación lateral, indicadores destacados, etiquetas legibles y siete gráficas disponibles. Pulsa **Personalizar reporte** para ajustar la distribución:

- Arrastra el asa de puntos junto al título de una gráfica para cambiar su orden. La página se desplaza automáticamente al acercar el cursor a un borde.
- Arrastra la esquina inferior derecha para ajustar alto y ancho. El ancho se encaja a media página o página completa para mantener una distribución ordenada.
- También puedes usar las flechas para moverla y los selectores **Ancho** y **Alto**. La esquina permite usar flechas del teclado: izquierda/derecha cambian el ancho; arriba/abajo cambian la altura.
- Pulsa **Terminar ajustes** para ocultar los controles, o **Restablecer** para recuperar la distribución original.

Los cambios se guardan automáticamente en este navegador, separados de las capturas. En pantallas pequeñas las gráficas se apilan; la distribución de escritorio se conserva. Al imprimir se respeta el orden y el ancho elegidos; las alturas se adaptan proporcionalmente al papel. Si una gráfica se reduce mucho, su contenido se puede desplazar en pantalla y se muestra completo al imprimir.

## Histórico de líneas y puntos

**Histórico por usuario** compara hasta 6 empleados. Selecciona **Desde**, **Hasta**, **Comparar** (consumo total o una aplicación) y **Usuarios**. Los controles del histórico se guardan en este navegador. Su intervalo es independiente del mes elegido para las otras gráficas; sí respeta el departamento y la búsqueda generales.

La identidad se conserva por número de empleado, aunque cambie la escritura del nombre. Cuando un usuario tiene varios equipos, se suman sus lecturas validadas del mismo mes. Los puntos muestran detalle al pasar el cursor o recibir foco; **Ver valores por mes** permite revisar la tabla.

- Los registros pendientes se excluyen y se indica cuántos faltan en el intervalo y en las lecturas parciales.
- Un mes sin lectura queda vacío: nunca se rellena con cero ni se une una línea a través de ese mes.
- Un consumo cero explícito sí es un punto real.
- Si una aplicación no está en el desglose capturado, su consumo se considera desconocido; no se presume cero. Si otros equipos sí tienen esa aplicación, se muestra su subtotal y se señala el desglose parcial.
- Las diferencias se calculan entre la primera y la última lectura disponible de cada usuario, con el período de referencia indicado.
- La referencia privada contiene solo JULIO: aparece un punto por usuario y una nota de que falta otro mes para mostrar la evolución. El panel nunca inventa meses históricos.

Las preferencias de distribución y comparación son locales; el respaldo JSON de capturas no incluye estas preferencias. El histórico también se incluye en la impresión. Para comprobar todas estas funciones, ejecuta `npm run test:report` con el servidor de desarrollo iniciado. Sus series de varios meses usan datos ficticios y un contexto de navegador separado de los datos de JULIO.


## Tipo de equipo, serie y doble SIM

En nuevas capturas, **Equipo** es un selector obligatorio de **Móvil, Laptop o PC**. Marca y modelo se capturan aparte. **Número de serie del equipo**, **IMEI 1** e **IMEI 2** son tres campos separados. Los IMEI son opcionales: puedes registrar ninguno, uno o dos según el equipo. Cada IMEI capturado debe tener exactamente 15 dígitos y los dos deben ser diferentes. Se guardan como texto para conservar ceros iniciales.

Un móvil con dos IMEI es un solo equipo y una sola captura mensual. La prevención de duplicados compara la serie y ambos IMEI, aunque el mismo número se haya capturado en una ranura distinta. Para equipos sin identificadores, el control usa empleado y descripción; captura la serie para distinguir varios equipos del mismo modelo.

La importación reconoce `IMEI 1`/`IMEI1`/`IMEI`, `IMEI 2`/`IMEI2` y `TIPO EQUIPO`/`TIPO DE EQUIPO`. En Excel, usa formato Texto para las columnas de IMEI, especialmente si tienen ceros iniciales. El número de serie sigue en `N. SERIE`.

Las capturas anteriores conservan su valor original de Equipo y serie. Al editarlas debes confirmar el tipo; el nombre anterior queda en `deviceDescription`. Los valores numéricos de la antigua columna de serie no se reinterpretan como IMEI automáticamente: confirma su significado con la etiqueta del dispositivo y separa los campos al revisarlos. Los respaldos anteriores siguen siendo compatibles con `schemaVersion: 1`. Los nuevos respaldos, CSV, búsqueda y reportes incluyen ambos IMEI y la serie por separado.

`npm run test:equipment` comprueba la captura de los tres tipos, IMEI opcionales, formatos, duplicados entre ranuras, persistencia, revisión de datos anteriores e impresión.


## Elegir gráficas e históricos agregados (v1.4)

El panel abre con **dos gráficas**: **Consumo total por período** y **Histórico por aplicación**. Los accesos **Una**, **Dos** y **Todas** cambian la cantidad de gráficas visibles. **Una** muestra el total mensual; **Dos** muestra total y aplicaciones; **Todas** muestra las siete. **Elegir gráficas** permite una combinación personalizada de al menos una gráfica. La selección se guarda en este navegador y solo las gráficas elegidas se incluyen al imprimir. Los detalles de capturas siguen disponibles en el reporte.

Las siete vistas son total por período, histórico por aplicación, histórico por usuario, clasificación de aplicaciones, clasificación de usuarios, departamentos y estado de equipos. Ocultar una gráfica conserva sus tamaños, posición y opciones. Los controles de movimiento actúan entre las gráficas visibles; restablecer la distribución conserva la selección. Una única gráfica ocupa todo el ancho.

**Consumo total por período** suma las lecturas validadas de los equipos de cada mes. Las aplicaciones son un desglose, por lo que no se vuelven a sumar al total. **Histórico por aplicación** suma el consumo registrado de cada app entre los equipos, por mes, y permite comparar hasta seis apps. Los puntos y la tabla indican pendientes excluidos y equipos que no tienen esa app en su desglose. Una app ausente no implica consumo cero.

Cada histórico tiene su intervalo Desde/Hasta, independiente del mes seleccionado para las clasificaciones. Todos respetan departamento y búsqueda. El **Histórico por usuario** sigue permitiendo elegir una app para comparar su consumo mensual entre usuarios; actívalo desde **Elegir gráficas**.

Los meses sin lectura siguen vacíos y los ceros explícitos se conservan. Las capturas actuales contienen únicamente JULIO; para comparar meses hay que capturar o importar otros períodos. No se inventan meses ni lecturas.

Las preferencias agregadas se guardan en `artron.consumo.analytics.v1`; la selección de gráficas se añade a `artron.consumo.layout.v1`. Estas preferencias están separadas de los registros y no se incluyen en el respaldo JSON de capturas. `npm run test:analytics` comprueba la selección, la impresión y los agregados con datos de prueba aislados.

El botón **Imprimir reporte**, situado junto a **Personalizar reporte** y en la cabecera, abre la impresión del navegador. Permite elegir impresora o **Guardar como PDF** e incluye los indicadores, las gráficas seleccionadas y el detalle de los registros con los filtros actuales.
