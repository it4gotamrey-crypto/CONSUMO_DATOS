import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { openDatabase, verifyPassword, createUser, publicUser, userFields, hashPassword, audit, readState } from './database.mjs';
import { HttpError, writeRecords } from './records.mjs';
const digest = value => createHash('sha256').update(value).digest('hex');
const safeEqual = (a, b) => typeof a === 'string' && typeof b === 'string' && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
export function createApp({ databasePath, origin, basePath = '', staticDir = resolve('dist'), sessionTtlMs = 8 * 60 * 60 * 1000 }) {
  const db = openDatabase(databasePath), allowedOrigin = new URL(origin).origin;
  const secure = allowedOrigin.startsWith('https:');
  basePath = '/' + basePath.split('/').filter(Boolean).join('/'); if (basePath === '/') basePath = '';
  const cookieName = secure ? '__Host-consumo_session' : 'consumo_session';
  const attempts = new Map(); let activeLogins = 0;
  function send(res, status, data) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); }
  async function body(req, max = 10 * 1024 * 1024) {
    let size = 0; const chunks = [];
    for await (const chunk of req) { size += chunk.length; if (size > max) throw new HttpError(413, 'La solicitud supera el tamaño permitido.'); chunks.push(chunk); }
    try { const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8')); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error(); return parsed; }
    catch { throw new HttpError(400, 'JSON no válido.'); }
  }
  function session(req) {
    const raw = (req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith(cookieName + '='))?.slice(cookieName.length + 1);
    if (!raw || !/^[a-f0-9]{64}$/.test(raw)) return null;
    return db.prepare(`SELECT u.*,s.csrf,s.token_hash FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).get(digest(raw), Date.now());
  }
  function requireAdmin(user) { if (user.role !== 'admin') throw new HttpError(403, 'Esta acción requiere acceso de administrador.'); }
  function currentUser(req) { const user = session(req); if (!user) throw new HttpError(401, 'Tu sesión terminó. Inicia sesión de nuevo.'); return user; }
  const server = createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
    try {
      const url = new URL(req.url, allowedOrigin);
      if (basePath && url.pathname === basePath) { res.writeHead(302, { Location: basePath + '/' }); res.end(); return; }
      if (!url.pathname.startsWith(basePath + '/')) throw new HttpError(404, 'Ruta no encontrada.');
      const path = url.pathname.slice(basePath.length);
      if (path.startsWith('/api/')) {
        if (!['GET', 'POST', 'PUT', 'PATCH'].includes(req.method)) throw new HttpError(405, 'Método no permitido.');
        if (req.method !== 'GET') {
          if (req.headers.origin !== allowedOrigin) throw new HttpError(403, 'Origen de la solicitud no permitido.');
          if (!(req.headers['content-type'] || '').startsWith('application/json')) throw new HttpError(415, 'Envía la solicitud como JSON.');
        }
        if (path === '/api/login' && req.method === 'POST') {
          const input = await body(req, 4096), username = typeof input.username === 'string' ? input.username.trim().toLowerCase().slice(0, 64) : '';
          const key = req.socket.remoteAddress || 'unknown', now = Date.now();
          for (const [k, v] of attempts) if (v.until <= now) attempts.delete(k);
          if (attempts.size >= 10000 || (attempts.get(key)?.count || 0) >= 50 || (attempts.get('u:' + username)?.count || 0) >= 5 || activeLogins >= 8) throw new HttpError(429, 'Demasiados intentos. Espera 15 minutos antes de volver a intentar.');
          const user = db.prepare('SELECT * FROM users WHERE username=?').get(username);
          activeLogins++; let valid;
          try { valid = await verifyPassword(input.password, user?.password_hash); } finally { activeLogins--; }
          if (!valid || !user?.active) {
            for (const k of [key, 'u:' + username]) attempts.set(k, { count: (attempts.get(k)?.count || 0) + 1, until: attempts.get(k)?.until || now + 15 * 60 * 1000 });
            throw new HttpError(401, 'Usuario o contraseña incorrectos.');
          }
          attempts.delete('u:' + username);
          db.prepare('DELETE FROM sessions WHERE expires_at<=?').run(now);
          const token = randomBytes(32).toString('hex'), csrf = randomBytes(32).toString('hex');
          db.prepare('INSERT INTO sessions(token_hash,user_id,csrf,expires_at) VALUES(?,?,?,?)').run(digest(token), user.id, csrf, now + sessionTtlMs);
          res.setHeader('Set-Cookie', `${cookieName}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${Math.floor(sessionTtlMs / 1000)}${secure ? '; Secure' : ''}`);
          audit(db, user, 'session.login', user.id);
          send(res, 200, { user: publicUser(user), csrf }); return;
        }
        const user = session(req);
        if (!user) throw new HttpError(401, 'Inicia sesión para acceder a los datos oficiales.');
        if (req.method !== 'GET' && !safeEqual(req.headers['x-csrf-token'], user.csrf)) throw new HttpError(403, 'La sesión de seguridad cambió. Vuelve a iniciar sesión.');
        if (path === '/api/session' && req.method === 'GET') { send(res, 200, { user: publicUser(user), csrf: user.csrf }); return; }
        if (path === '/api/logout' && req.method === 'POST') {
          db.prepare('DELETE FROM sessions WHERE token_hash=?').run(user.token_hash);
          res.setHeader('Set-Cookie', `${cookieName}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure ? '; Secure' : ''}`);
          send(res, 200, { ok: true }); return;
        }
        if (path === '/api/records' && req.method === 'GET') { send(res, 200, readState(db)); return; }
        if (path === '/api/records' && req.method === 'PUT') { const input = await body(req); send(res, 200, writeRecords(db, currentUser(req), input)); return; }
        if (path === '/api/users' && req.method === 'GET') {
          requireAdmin(user); send(res, 200, { users: db.prepare('SELECT * FROM users ORDER BY name').all().map(publicUser) }); return;
        }
        if (path === '/api/users' && req.method === 'POST') {
          requireAdmin(user); const input = await body(req, 8192);
          let created; try { created = await createUser(db, input, () => requireAdmin(currentUser(req))); } catch (e) { if (e.status) throw e; throw new HttpError(422, e.message.includes('UNIQUE') ? 'Ese usuario ya existe.' : e.message); }
          audit(db, user, 'user.create', created.id, created); send(res, 201, { user: created }); return;
        }
        if (/^\/api\/users\/[^/]+$/.test(path) && req.method === 'PATCH') {
          requireAdmin(user); const id = path.split('/').at(-1), input = await body(req, 8192);
          const old = db.prepare('SELECT * FROM users WHERE id=?').get(id);
          if (!old) throw new HttpError(404, 'Usuario no encontrado.');
          let fields, passwordHash;
          try { fields = userFields({ ...old, ...input, username: old.username }); if (input.password) passwordHash = await hashPassword(input.password); }
          catch (e) { throw new HttpError(422, e.message); }
          requireAdmin(currentUser(req));
          if (input.active !== undefined && typeof input.active !== 'boolean') throw new HttpError(422, 'Estado de usuario no válido.');
          const active = input.active === undefined ? old.active : Number(input.active);
          db.exec('BEGIN IMMEDIATE');
          try {
            const latest = db.prepare('SELECT * FROM users WHERE id=?').get(id);
            if (latest.role === 'admin' && latest.active && (fields.role !== 'admin' || !active) && db.prepare("SELECT COUNT(*) AS n FROM users WHERE active=1 AND role='admin'").get().n <= 1) throw new HttpError(422, 'Debe permanecer al menos un administrador activo.');
            if (id === user.id && (fields.role !== 'admin' || !active)) throw new HttpError(422, 'Usa otro administrador para cambiar tu propio acceso.');
            db.prepare('UPDATE users SET name=?,role=?,active=?,password_hash=? WHERE id=?').run(fields.name, fields.role, active, passwordHash || latest.password_hash, id);
            db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
            audit(db, user, 'user.update', id, { before: publicUser(latest), after: { ...publicUser(latest), ...fields, active: Boolean(active) }, passwordReset: Boolean(passwordHash) });
            db.exec('COMMIT');
          } catch (e) { db.exec('ROLLBACK'); throw e; }
          send(res, 200, { user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(id)) }); return;
        }
        if (path === '/api/audit' && req.method === 'GET') {
          requireAdmin(user); send(res, 200, { entries: db.prepare('SELECT id,at,actor_name,action,target FROM audit ORDER BY id DESC LIMIT 200').all() }); return;
        }
        throw new HttpError(404, 'Ruta no encontrada.');
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Método no permitido.');
      if (path === '/' || path === '/index.html') {
        const index = (await readFile(resolve(staticDir, 'index.html'), 'utf8')).replace('<head>', '<head><meta name="consumo-mode" content="server">');
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(req.method === 'HEAD' ? undefined : index); return;
      }
      if (!/^\/assets\/[a-zA-Z0-9_.-]+\.(js|css)$/.test(path)) throw new HttpError(404, 'Ruta no encontrada.');
      const content = await readFile(resolve(staticDir, '.' + path));
      res.writeHead(200, { 'Content-Type': extname(path) === '.js' ? 'text/javascript; charset=utf-8' : 'text/css; charset=utf-8' }); res.end(req.method === 'HEAD' ? undefined : content);
    } catch (e) {
      if (res.headersSent) { res.end(); return; }
      const status = e.status || (e.code === 'ENOENT' ? 404 : 500);
      send(res, status, { error: status === 500 ? 'No se pudo completar la operación en el servidor.' : e.message });
    }
  });
  server.requestTimeout = 30000; server.headersTimeout = 15000;
  server.on('close', () => db.close());
  return { server, db };
}
