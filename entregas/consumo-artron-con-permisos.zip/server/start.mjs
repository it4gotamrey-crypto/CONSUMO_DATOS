import { resolve } from 'node:path';
import { createApp } from './app.mjs';
const port = Number(process.env.PORT || 8080), host = process.env.HOST || '127.0.0.1';
const origin = process.env.CONSUMO_ORIGIN || `http://localhost:${port}`;
if (process.env.NODE_ENV === 'production' && !origin.startsWith('https://')) throw new Error('Configura CONSUMO_ORIGIN con la dirección HTTPS pública de Artron.');
const { server } = createApp({ databasePath: resolve(process.env.CONSUMO_DB || '.local/server/consumo.sqlite'), origin, basePath: process.env.CONSUMO_BASE_PATH || '', staticDir: resolve(process.env.CONSUMO_STATIC || 'dist') });
server.listen(port, host, () => console.log(`Servidor de consumo iniciado en puerto ${port}. Los datos oficiales se guardan en SQLite.`));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => server.close(() => process.exit(0)));
