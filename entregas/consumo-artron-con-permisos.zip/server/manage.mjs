import { openDatabase, createUser } from './database.mjs';
import { resolve } from 'node:path';
import { Writable } from 'node:stream';
import { createInterface } from 'node:readline/promises';
const [command, username, name] = process.argv.slice(2);
if (command !== 'create-admin' || !username || !name || !process.stdin.isTTY) {
  console.error('Uso en terminal interactiva: npm run admin:create -- usuario "Nombre completo"'); process.exit(1);
}
let hidden = false;
const output = new Writable({ write(chunk, encoding, done) { if (!hidden) process.stdout.write(chunk, encoding); done(); } });
const reader = createInterface({ input: process.stdin, output, terminal: true });
async function secret(label) { process.stdout.write(label); hidden = true; const answer = await reader.question(''); hidden = false; process.stdout.write('\n'); return answer; }
try {
  const password = await secret('Contraseña (mínimo 12 caracteres): '), confirmation = await secret('Repite la contraseña: ');
  if (password !== confirmation) throw new Error('Las contraseñas no coinciden.');
  const db = openDatabase(resolve(process.env.CONSUMO_DB || '.local/server/consumo.sqlite'));
  try { await createUser(db, { username, name, role: 'admin', password }); console.log('Administrador creado. Ya puede iniciar sesión y dar de alta a los demás usuarios.'); }
  finally { db.close(); }
} catch (e) { console.error(e.message.includes('UNIQUE') ? 'Ese usuario ya existe.' : e.message); process.exitCode = 1; }
finally { reader.close(); }
