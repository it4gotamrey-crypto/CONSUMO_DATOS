import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, chmodSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomBytes, randomUUID, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
const scrypt = promisify(scryptCallback);
export const ROLES = ['admin', 'capture', 'viewer'];
export const roleNames = { admin: 'Administrador', capture: 'Capturista', viewer: 'Consulta' };
export function openDatabase(path) {
  if (path !== ':memory:') mkdirSync(dirname(resolve(path)), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','capture','viewer')), password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), csrf TEXT NOT NULL, expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL DEFAULT 0, records TEXT NOT NULL DEFAULT '[]', saved_at TEXT);
    INSERT OR IGNORE INTO state(id) VALUES(1);
    CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, actor_id TEXT NOT NULL, actor_name TEXT NOT NULL, action TEXT NOT NULL, target TEXT NOT NULL, details TEXT NOT NULL);`);
  if (path !== ':memory:') chmodSync(path, 0o600);
  return db;
}
export async function hashPassword(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) throw new Error('La contraseña debe tener entre 12 y 256 caracteres.');
  const salt = randomBytes(16).toString('hex');
  const hash = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${hash.toString('hex')}`;
}
const dummyHash = await hashPassword(randomBytes(32).toString('hex'));
export async function verifyPassword(password, hash = dummyHash) {
  if (typeof password !== 'string' || password.length > 256) return false;
  const [, salt, digest] = hash.split(':');
  const candidate = await scrypt(password, salt, 64);
  return timingSafeEqual(candidate, Buffer.from(digest, 'hex'));
}
export function publicUser(user) { return { id: user.id, username: user.username, name: user.name, role: user.role, active: Boolean(user.active) }; }
export function userFields(input) {
  const username = typeof input.username === 'string' ? input.username.trim().toLowerCase() : '';
  if (!/^[a-z0-9][a-z0-9._-]{2,63}$/.test(username)) throw new Error('Usa un usuario de 3 a 64 letras, números, punto, guion o guion bajo.');
  const name = typeof input.name === 'string' ? input.name.trim() : '';
  if (!name || name.length > 120) throw new Error('Escribe un nombre de hasta 120 caracteres.');
  if (!ROLES.includes(input.role)) throw new Error('Selecciona un rol válido.');
  return { username, name, role: input.role };
}
export async function createUser(db, input, beforeInsert = () => {}) {
  const fields = userFields(input), passwordHash = await hashPassword(input.password);
  const user = { id: randomUUID(), ...fields, active: 1 };
  beforeInsert();
  db.prepare('INSERT INTO users(id,username,name,role,password_hash,created_at) VALUES(?,?,?,?,?,?)').run(user.id, user.username, user.name, user.role, passwordHash, new Date().toISOString());
  return publicUser(user);
}
export function audit(db, actor, action, target, details = {}) {
  db.prepare('INSERT INTO audit(at,actor_id,actor_name,action,target,details) VALUES(?,?,?,?,?,?)').run(new Date().toISOString(), actor.id, actor.username, action, target, JSON.stringify(details));
}
export function readState(db) {
  const row = db.prepare('SELECT * FROM state WHERE id=1').get();
  return { schemaVersion: 1, revision: row.revision, records: JSON.parse(row.records), savedAt: row.saved_at };
}
