import { validateBackup, issuesFor, sameDevice, DEVICE_TYPES } from '../src/domain.js';
import { readState, audit } from './database.mjs';
export class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
export function writeRecords(db, actor, input) {
  if (!['admin', 'capture'].includes(actor.role)) throw new HttpError(403, 'Tu acceso es de consulta. No puedes guardar capturas.');
  if (!Number.isSafeInteger(input.revision)) throw new HttpError(400, 'Falta la versión de los datos.');
  let next;
  try { next = validateBackup(input); } catch (e) { throw new HttpError(422, e.message); }
  if (input.allowPending === true && actor.role !== 'admin') throw new HttpError(403, 'Solo un administrador puede importar capturas pendientes.');
  db.exec('BEGIN IMMEDIATE');
  try {
    const current = readState(db);
    if (input.revision !== current.revision) throw new HttpError(409, 'Los datos cambiaron. Actualiza el panel antes de guardar.');
    const before = new Map(current.records.map(r => [r.id, r]));
    const after = new Map(next.map(r => [r.id, r]));
    const changes = [];
    for (const old of current.records) {
      const updated = after.get(old.id);
      if (!updated || JSON.stringify(old) !== JSON.stringify(updated)) {
        if (actor.role !== 'admin') throw new HttpError(403, 'Solo un administrador puede corregir o eliminar capturas existentes.');
        changes.push({ action: updated ? 'record.update' : 'record.delete', id: old.id, before: old, after: updated || null });
      }
    }
    for (const record of next) if (!before.has(record.id)) changes.push({ action: 'record.create', id: record.id, before: null, after: record });
    for (const change of changes) {
      const record = change.after; if (!record) continue;
      if (!record.id || record.id.length > 128 || !/^\d{4}-(0[1-9]|1[0-2])$/.test(record.period)) throw new HttpError(422, 'La captura requiere un identificador y un período mensual válidos.');
      if ([record.totalGb, ...record.apps.map(app => app.gb)].some(value => value !== null && value > 1000000000)) throw new HttpError(422, 'Consumo fuera de rango.');
      if (input.allowPending !== true && !DEVICE_TYPES.includes(record.device)) throw new HttpError(422, 'Selecciona Móvil, Laptop o PC en Equipo.');
      if (change.action === 'record.update' && !record.reviewNote) throw new HttpError(422, 'Agrega una nota que explique la corrección.');
      if (actor.role === 'capture' && (record.reviewedHigh || record.reviewNote || record.reviewHistory.length)) throw new HttpError(403, 'Las confirmaciones de consumos atípicos corresponden al administrador.');
      if (next.some(other => other.id !== record.id && other.period === record.period && sameDevice(other, record))) throw new HttpError(422, 'Este equipo ya tiene una captura en el mismo mes (serie o IMEI coincidente).');
      const issues = issuesFor(record, next);
      if (issues.length && input.allowPending !== true) throw new HttpError(422, issues.join(' '));
    }
    if (changes.length) {
      const savedAt = new Date().toISOString();
      db.prepare('UPDATE state SET records=?,revision=revision+1,saved_at=? WHERE id=1').run(JSON.stringify(next), savedAt);
      for (const change of changes) audit(db, actor, change.action, change.id, { before: change.before, after: change.after });
    }
    const result = readState(db); db.exec('COMMIT'); return result;
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}
